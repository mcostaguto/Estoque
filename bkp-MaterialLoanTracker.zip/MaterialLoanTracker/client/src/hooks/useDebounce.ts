import { useState, useEffect } from 'react';

/**
 * Hook personalizado para "debouncing" de valores.
 * Retorna um valor que só é atualizado após um determinado atraso (delay)
 * desde a última vez que o valor original mudou.
 * Útil para otimizar funções que não devem ser chamadas com muita frequência,
 * como buscas em tempo real ou validações.
 *
 * @param value O valor a ser "debounced".
 * @param delay O atraso em milissegundos antes de atualizar o valor "debounced".
 * @returns O valor "debounced".
 */
export function useDebounce<T>(value: T, delay: number): T {
  // Estado para armazenar o valor debounced
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    // Configura um timer que atualiza o debouncedValue após o delay
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    // Limpa o timer se o valor (value) mudar ou se o componente for desmontado.
    // Isso garante que o timer anterior seja cancelado e um novo seja iniciado.
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]); // Apenas re-executa o efeito se o valor ou o delay mudarem

  return debouncedValue;
}
import { type ClassValue, clsx } from "clsx"; // Para combinar classes CSS
import { twMerge } from "tailwind-merge"; // Para mesclar classes Tailwind

// Função utilitária para combinar classes CSS, especialmente útil com Tailwind
// Resolve conflitos de classes (ex: "p-4" e "p-2" resulta em "p-2")
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Safely formats dates with comprehensive error handling
 * Handles Date objects, ISO strings, and invalid dates
 */
export function formatDate(date: Date | string | null | undefined): string {
  if (!date || date === '' || date === 'null' || date === 'undefined') {
    return '-';
  }

  try {
    let dateObj: Date;

    if (date instanceof Date) {
      dateObj = date;
    } else if (typeof date === 'string') {
      dateObj = new Date(date);
    } else {
      console.warn('formatDate: Unsupported date type:', typeof date, date);
      return '-';
    }

    // Validate the date object before accessing getTime
    if (!dateObj || typeof dateObj.getTime !== 'function' || isNaN(dateObj.getTime())) {
      console.warn('formatDate: Invalid date object:', date, 'resulted in:', dateObj);
      return '-';
    }

    return new Intl.DateTimeFormat('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(dateObj);
  } catch (error) {
    console.error('formatDate: Error formatting date:', date, error);
    return '-';
  }
}

/**
 * Safely access date methods with error handling
 * Prevents "getTime is not a function" errors
 */
export function safeDateMethod(obj: any, property: string, method: string): any {
  try {
    if (!obj || !obj[property]) return null;

    const dateValue = obj[property];

    if (!(dateValue instanceof Date)) {
      console.warn(`safeDateMethod: ${property} is not a Date object:`, dateValue);
      return null;
    }

    if (typeof dateValue[method] !== 'function') {
      console.warn(`safeDateMethod: ${property}.${method} is not a function:`, dateValue);
      return null;
    }

    return dateValue[method]();
  } catch (error) {
    console.error(`safeDateMethod: Error accessing ${property}.${method}:`, error);
    return null;
  }
}

/**
 * Validate if an object has a valid date property
 */
export function hasValidDateProperty(obj: any, property: string): boolean {
  try {
    return obj &&
           obj[property] &&
           obj[property] instanceof Date &&
           typeof obj[property].getTime === 'function' &&
           !isNaN(obj[property].getTime());
  } catch (error) {
    return false;
  }
}

// Função utilitária para gerar IDs simples (usada no use-toast, por exemplo)
// Não deve ser usada para IDs de banco de dados
export function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
}
import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    let message = text;
    try {
        const json = JSON.parse(text);
        if (json && json.message) {
            message = json.message;
        }
    } catch (e) {
        // Ignora erro de parse se não for JSON
    }
    throw new Error(`${res.status}: ${message}`);
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
  queryParams?: Record<string, any>,
): Promise<Response> {
  let requestUrl = url;
  if (queryParams) {
    const cleanedParams = Object.fromEntries(
      Object.entries(queryParams).filter(([, value]) => value !== undefined && value !== null)
    );
    const queryString = new URLSearchParams(cleanedParams).toString();
    requestUrl = `${url}?${queryString}`;
  }

  // CORREÇÃO AQUI: Inicialize headers como Record<string, string>
  const headers: Record<string, string> = {};

  // Adiciona Content-Type se houver dados
  if (data) {
    headers["Content-Type"] = "application/json";
  }

  // Adiciona o token JWT ao cabeçalho Authorization se ele existir no localStorage
  const token = localStorage.getItem('token');
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(requestUrl, {
    method,
    headers: headers, // Usa os cabeçalhos construídos
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include", // Inclui cookies, importante se você usar sessões também
  });

  await throwIfResNotOk(res);
  return res;
}
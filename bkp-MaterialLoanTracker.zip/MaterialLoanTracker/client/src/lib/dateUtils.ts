
/**
 * Centralized date parsing utilities to handle ISO strings from API
 */

export const parseDate = (dateInput: string | number | Date | null | undefined): Date | null => {
  // Handle null/undefined/empty cases
  if (!dateInput || dateInput === '' || dateInput === 'null' || dateInput === 'undefined') {
    return null;
  }

  try {
    let date: Date;

    // Handle different input types
    if (dateInput instanceof Date) {
      // Already a Date object
      date = dateInput;
    } else if (typeof dateInput === 'string') {
      // Handle string dates
      if (dateInput.trim() === '') return null;
      date = new Date(dateInput);
    } else if (typeof dateInput === 'number') {
      // Handle timestamps
      date = new Date(dateInput);
    } else {
      console.warn(`⚠️ Unsupported date type: ${typeof dateInput}`, dateInput);
      return null;
    }

    // Validate the resulting date
    if (!date || typeof date.getTime !== 'function' || isNaN(date.getTime())) {
      console.warn(`⚠️ Invalid date result:`, dateInput, '→', date);
      return null;
    }

    return date;
  } catch (error) {
    console.error(`❌ Error parsing date:`, dateInput, error);
    return null;
  }
};

/**
 * Parse loan object from API response, converting ISO string dates to Date objects
 */
export const parseLoanFromAPI = (loanData: any): any => {
  if (!loanData) return null;

  try {
    // Parse dates with fallbacks for required fields
    const loanDate = parseDate(loanData.loanDate) || new Date();
    const dueDate = parseDate(loanData.dueDate);
    const returnDate = parseDate(loanData.returnDate);
    const createdAt = parseDate(loanData.createdAt) || new Date();
    const updatedAt = parseDate(loanData.updatedAt) || new Date();

    // Validate all Date objects have getTime method
    if (!(loanDate instanceof Date) || typeof loanDate.getTime !== 'function') {
      throw new Error(`Invalid loanDate for loan ${loanData.id}`);
    }
    if (dueDate && (!(dueDate instanceof Date) || typeof dueDate.getTime !== 'function')) {
      throw new Error(`Invalid dueDate for loan ${loanData.id}`);
    }
    if (returnDate && (!(returnDate instanceof Date) || typeof returnDate.getTime !== 'function')) {
      throw new Error(`Invalid returnDate for loan ${loanData.id}`);
    }
    if (!(createdAt instanceof Date) || typeof createdAt.getTime !== 'function') {
      throw new Error(`Invalid createdAt for loan ${loanData.id}`);
    }
    if (!(updatedAt instanceof Date) || typeof updatedAt.getTime !== 'function') {
      throw new Error(`Invalid updatedAt for loan ${loanData.id}`);
    }

    const loan = {
      id: Number(loanData.id) || 0,
      itemId: Number(loanData.itemId) || 0,
      personId: Number(loanData.personId) || 0,
      isIndefinite: Boolean(loanData.isIndefinite) || false,
      notes: loanData.notes || null,
      loanDate,
      dueDate,
      returnDate,
      createdAt,
      updatedAt
    };

    return loan;
  } catch (error) {
    console.error(`❌ Error parsing loan ${loanData?.id}:`, error);
    
    // Return safe fallback
    return {
      id: Number(loanData?.id) || 0,
      itemId: Number(loanData?.itemId) || 0,
      personId: Number(loanData?.personId) || 0,
      isIndefinite: Boolean(loanData?.isIndefinite) || false,
      notes: loanData?.notes || null,
      loanDate: new Date(),
      dueDate: null,
      returnDate: null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
  }
};

/**
 * Parse item object from API response
 */
export const parseItemFromAPI = (itemData: any): any => {
  if (!itemData) return null;

  try {
    const createdAt = parseDate(itemData.createdAt) || new Date();
    const updatedAt = parseDate(itemData.updatedAt) || new Date();
    const acquisitionDate = parseDate(itemData.acquisitionDate);

    // Validate required Date objects
    if (!(createdAt instanceof Date) || typeof createdAt.getTime !== 'function') {
      throw new Error(`Invalid createdAt for item ${itemData.id}`);
    }
    if (!(updatedAt instanceof Date) || typeof updatedAt.getTime !== 'function') {
      throw new Error(`Invalid updatedAt for item ${itemData.id}`);
    }
    if (acquisitionDate && (!(acquisitionDate instanceof Date) || typeof acquisitionDate.getTime !== 'function')) {
      throw new Error(`Invalid acquisitionDate for item ${itemData.id}`);
    }

    return {
      ...itemData,
      id: Number(itemData.id) || 0,
      createdAt,
      updatedAt,
      acquisitionDate
    };
  } catch (error) {
    console.error(`❌ Error parsing item ${itemData?.id}:`, error);
    
    // Return safe fallback
    return {
      ...itemData,
      id: Number(itemData?.id) || 0,
      createdAt: new Date(),
      updatedAt: new Date(),
      acquisitionDate: null
    };
  }
};

/**
 * Parse person object from API response
 */
export const parsePersonFromAPI = (personData: any): any => {
  if (!personData) return null;

  return {
    ...personData,
    id: Number(personData.id) || 0,
    createdAt: parseDate(personData.createdAt) || new Date(),
    updatedAt: parseDate(personData.updatedAt) || new Date()
  };
};

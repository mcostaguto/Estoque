
// Comprehensive global error handler for getTime errors
window.addEventListener('error', (event) => {
  if (event.message && event.message.includes('getTime is not a function')) {
    console.error('🚨 GLOBAL getTime ERROR CAUGHT:', {
      message: event.message,
      filename: event.filename,
      lineno: event.lineno,
      colno: event.colno,
      stack: event.error?.stack
    });
    
    // Prevent the error from propagating and breaking the UI
    event.preventDefault();
    event.stopPropagation();
    return true;
  }
  return false;
});

// Additional unhandled promise rejection handler
window.addEventListener('unhandledrejection', (event) => {
  if (event.reason && 
      (event.reason.message?.includes('getTime is not a function') || 
       String(event.reason).includes('getTime is not a function'))) {
    console.error('🚨 UNHANDLED PROMISE getTime ERROR:', event.reason);
    event.preventDefault();
  }
});

// Global property interceptor for date properties
const datePropertyNames = ['loanDate', 'dueDate', 'returnDate', 'createdAt', 'updatedAt', 'acquisitionDate'];

const originalDefineProperty = Object.defineProperty;
const originalGetOwnPropertyDescriptor = Object.getOwnPropertyDescriptor;

// Function to safely convert any value to a Date
const ensureValidDate = (value: any, propertyName: string): Date | null => {
  if (!value || value === 'null' || value === 'undefined' || value === '') {
    return null;
  }

  try {
    if (value instanceof Date) {
      return isNaN(value.getTime()) ? null : value;
    }
    
    if (typeof value === 'string' || typeof value === 'number') {
      const date = new Date(value);
      return isNaN(date.getTime()) ? null : date;
    }

    console.warn(`⚠️ Cannot convert ${propertyName} to Date:`, value);
    return null;
  } catch (error) {
    console.error(`❌ Error converting ${propertyName} to Date:`, value, error);
    return null;
  }
};

// Override Object property access for date properties
Object.defineProperty = function(obj: any, prop: string | symbol, descriptor: PropertyDescriptor) {
  if (typeof prop === 'string' && datePropertyNames.includes(prop)) {
    const originalDescriptor = { ...descriptor };
    
    if (descriptor.value !== undefined) {
      // Direct value assignment
      descriptor.value = ensureValidDate(descriptor.value, prop);
    }
    
    if (descriptor.get || descriptor.set) {
      const originalGet = descriptor.get;
      const originalSet = descriptor.set;
      
      descriptor.get = function() {
        const value = originalGet ? originalGet.call(this) : this[`_${prop}`];
        return ensureValidDate(value, prop);
      };
      
      descriptor.set = function(newValue: any) {
        const validDate = ensureValidDate(newValue, prop);
        if (originalSet) {
          originalSet.call(this, validDate);
        } else {
          this[`_${prop}`] = validDate;
        }
      };
    }
  }
  
  return originalDefineProperty.call(this, obj, prop, descriptor);
};

// Intercept property access for existing objects
const createPropertyInterceptor = (obj: any, propertyName: string) => {
  let internalValue = obj[propertyName];
  
  Object.defineProperty(obj, propertyName, {
    get() {
      const validDate = ensureValidDate(internalValue, propertyName);
      if (validDate !== internalValue) {
        console.log(`🔧 Auto-corrected ${propertyName}:`, internalValue, '→', validDate);
        internalValue = validDate;
      }
      return validDate;
    },
    set(newValue: any) {
      internalValue = ensureValidDate(newValue, propertyName);
    },
    enumerable: true,
    configurable: true
  });
};

// Monkey patch common object methods to intercept date properties
const originalCreate = Object.create;
Object.create = function(proto: any, propertiesObject?: PropertyDescriptorMap) {
  const obj = originalCreate.call(this, proto, propertiesObject);
  
  // Add property interceptors for date properties
  datePropertyNames.forEach(propName => {
    if (obj.hasOwnProperty(propName)) {
      createPropertyInterceptor(obj, propName);
    }
  });
  
  return obj;
};

// Monkey patch JSON.parse to automatically fix date properties
const originalJSONParse = JSON.parse;
JSON.parse = function(text: string, reviver?: (this: any, key: string, value: any) => any): any {
  const result = originalJSONParse.call(this, text, (key, value) => {
    // Apply custom reviver first
    const revivedValue = reviver ? reviver.call(this, key, value) : value;
    
    // Convert date properties
    if (datePropertyNames.includes(key) && revivedValue) {
      const validDate = ensureValidDate(revivedValue, key);
      if (validDate) {
        console.log(`🔧 JSON.parse auto-converted ${key}:`, revivedValue, '→', validDate);
        return validDate;
      }
    }
    
    return revivedValue;
  });
  
  return result;
};

// Monkey patch Date prototype to add debugging
const originalGetTime = Date.prototype.getTime;
Date.prototype.getTime = function() {
  try {
    if (this === null || this === undefined || !(this instanceof Date)) {
      console.error('🚨 getTime called on invalid object:', this, typeof this, 'Stack:', new Error().stack);
      throw new TypeError('getTime is not a function - invalid Date object');
    }
    return originalGetTime.call(this);
  } catch (error) {
    console.error('🚨 getTime error:', error, 'on object:', this, 'Stack:', new Error().stack);
    throw error;
  }
};

// Override Object.prototype to catch property access on invalid objects
const originalValueOf = Object.prototype.valueOf;
Object.prototype.valueOf = function() {
  try {
    return originalValueOf.call(this);
  } catch (error) {
    console.error('🚨 valueOf error on object:', this, error);
    throw error;
  }
};


import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add specific styles for this app
const style = document.createElement('style');
style.innerHTML = `
  :root {
    --primary: 216 90% 54%;
    --secondary: 245 75% 59%;
    --accent: 265 83% 58%;
  }
`;
document.head.appendChild(style);

createRoot(document.getElementById("root")!).render(<App />);
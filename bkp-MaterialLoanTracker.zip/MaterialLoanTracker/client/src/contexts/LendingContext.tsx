//lendingContext.tsx

import React, { createContext, useContext, useState, useEffect, ReactNode, useMemo, useCallback } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useSocket } from '@/contexts/SocketContext';
import { useToast } from '@/hooks/use-toast';
import {
  Loan,
  Item,
  Person,
  InsertLoan,
  PaginationParams,
  SearchFilterParams,
  LoanStatusFilterParams,
  paginatedLoanResponseSchema,
  paginatedItemResponseSchema,
} from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { parseLoanFromAPI, parseItemFromAPI, parsePersonFromAPI } from '@/lib/dateUtils';
import { z } from 'zod';

// Tipo auxiliar para o payload cru do socket (datas como strings)
interface RawLoanFromSocket {
  id: number;
  itemId: number;
  personId: number;
  loanDate: string;
  dueDate: string | null;
  returnDate: string | null;
  notes: string | null;
  isIndefinite: boolean;
  createdAt: string;
  updatedAt: string;
}

// Simplified date error tracking
const dateErrorTracker = {
  errors: [] as any[],

  logError: (context: string, error: any, loan: any) => {
    const errorInfo = {
      timestamp: new Date().toISOString(),
      context,
      error: error.message || String(error),
      loanId: loan?.id || 'unknown',
      loanData: {
        id: loan?.id,
        loanDate: { value: loan?.loanDate, type: typeof loan?.loanDate, isDate: loan?.loanDate instanceof Date },
        dueDate: { value: loan?.dueDate, type: typeof loan?.dueDate, isDate: loan?.dueDate instanceof Date },
        returnDate: { value: loan?.returnDate, type: typeof loan?.returnDate, isDate: loan?.returnDate instanceof Date },
        createdAt: { value: loan?.createdAt, type: typeof loan?.createdAt, isDate: loan?.createdAt instanceof Date },
        updatedAt: { value: loan?.updatedAt, type: typeof loan?.updatedAt, isDate: loan?.updatedAt instanceof Date }
      },
      stack: new Error().stack?.split('\n').slice(1, 5).join('\n')
    };

    dateErrorTracker.errors.push(errorInfo);

    // Keep only last 20 errors
    if (dateErrorTracker.errors.length > 20) {
      dateErrorTracker.errors.shift();
    }

    console.error(`🚨 DATE ERROR TRACKED:`, errorInfo);
    return errorInfo;
  },

  getReport: () => ({
    totalErrors: dateErrorTracker.errors.length,
    recentErrors: dateErrorTracker.errors.slice(-5),
    allErrors: dateErrorTracker.errors
  })
};

// Debug function to trace date object flow (disabled for production)
const debugDateFlow = (context: string, value: any, stack?: string) => {
  // Debug logging disabled to reduce console noise
  return;
};

// Date property names for validation
const datePropertyNames = ['loanDate', 'dueDate', 'returnDate', 'createdAt', 'updatedAt'];

// Removed duplicate date parsing logic - now using centralized dateUtils

// Use simplified pagination schemas to avoid type issues
type PaginatedLoansResponse = z.infer<typeof paginatedLoanResponseSchema>;
type PaginatedItemsResponse = z.infer<typeof paginatedItemResponseSchema>;

// Definição atualizada do tipo de contexto
interface LendingContextType {
  loans: Loan[];
  items: Item[];
  people: Person[];
  isLoading: boolean;
  error: string | null;
  refreshLoans: (params?: PaginationParams & SearchFilterParams & LoanStatusFilterParams) => Promise<void>;
  refreshItemsAndPeople: () => Promise<void>;
  createLoan: (loanData: InsertLoan) => Promise<void>;
  returnItem: (loanId: number) => Promise<void>;
  getActiveLoansCount: () => number;
  getExpiredLoansCount: () => number;
  getRecentLoans: (count: number) => Loan[];
  getPopularItems: (count: number) => { item: Item, count: number }[];
  getItemById: (itemId: number) => Item | undefined;
  getPersonById: (personId: number) => Person | undefined;
  isLoanExpired: (loan: Loan) => boolean;
  getAvailableItems: () => Item[];
  getItemLoanCount: (itemId: number) => number;
  // Novos campos para paginação
  totalLoans: number;
  loansPage: number;
  loansPageSize: number;
  loansTotalPages: number;
}

const LendingContext = createContext<LendingContextType | undefined>(undefined);

interface LendingProviderProps {
  children: ReactNode;
}

export const LendingProvider: React.FC<LendingProviderProps> = ({ children }) => {
  const [loans, setLoans] = useState<Loan[]>([]);
  const [totalLoans, setTotalLoans] = useState(0);
  const [loansPage, setLoansPage] = useState(1);
  const [loansPageSize, setLoansPageSize] = useState(10);
  const [loansTotalPages, setLoansTotalPages] = useState(1);

  // Error tracking for getTime issues
  useEffect(() => {
    const originalError = window.onerror;

    window.onerror = (message, source, lineno, colno, error) => {
      if (typeof message === 'string' && message.includes('getTime is not a function')) {
        console.error('🚨 CAUGHT,’” getTime ERROR - DETAILED TRACKING:', {
          message,
          source,
          lineno,
          colno,
          error,
          errorReport: dateErrorTracker.getReport(),
          stackTrace: error?.stack
        });

        return true; // Prevent default error handling
      }

      if (originalError) {
        return originalError(message, source, lineno, colno, error);
      }
      return false;
    };

    return () => {
      window.onerror = originalError;
    };
  }, []);

  const [items, setItems] = useState<Item[]>([]);
  const [people, setPeople] = useState<Person[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();
  const { socket } = useSocket();

  // Função para carregar empréstimos (com paginação e filtros)
  const refreshLoans = async (params?: PaginationParams & SearchFilterParams & LoanStatusFilterParams) => {
    if (!user) {
      setLoans([]);
      setTotalLoans(0);
      setLoansPage(1);
      setLoansPageSize(10);
      setLoansTotalPages(1);
      return;
    }

    setError(null);
    try {
      const response = await apiRequest('GET', '/api/loans', undefined, params);

      if (!response.ok) {
        throw new Error(`Failed to fetch loans: ${response.status}`);
      }

      const data = await response.json();

      // Validate and process loans data
      if (!data || !Array.isArray(data.data)) {
        console.warn('Invalid response format from loans API:', data);
        setLoans([]);
        setTotalLoans(0);
        return;
      }

      const validatedLoans = data.data.map((loan: any) => parseLoanFromAPI(loan));

      console.log(`📊 Final validated loans count: ${validatedLoans.length}`);
      setLoans(validatedLoans);
      setTotalLoans(Number(data.total) || 0);
      setLoansPage(Number(data.page) || 1);
      setLoansPageSize(Number(data.pageSize) || 10);
      setLoansTotalPages(Number(data.totalPages) || 1);
      setError(null);
    } catch (err: any) {
      const errorMessage = err.message || 'Erro ao carregar empréstimos';
      setError(errorMessage);
      console.error('Erro ao carregar empréstimos:', err);
      toast({
        title: "Erro ao carregar empréstimos",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  // Função para carregar itens e pessoas
  const refreshItemsAndPeople = async () => {
     if (!user) {
       setItems([]);
       setPeople([]);
       return;
     }

     try {
       // Para itens e pessoas, não estamos usando paginação aqui, então buscamos todos
       const [itemsResponse, peopleResponse] = await Promise.allSettled([
         apiRequest('GET', '/api/inventory/items', undefined, { pageSize: 10000 }),
         apiRequest('GET', '/api/people')
       ]);

       // Handle items response
       if (itemsResponse.status === 'fulfilled' && itemsResponse.value?.ok) {
         try {
           const itemsData = await itemsResponse.value.json();
           if (itemsData && Array.isArray(itemsData.data)) {
             const processedItems = itemsData.data.map((item: any) => {
               try {
                 return parseItemFromAPI(item);
               } catch (error) {
                 console.warn('Error processing item:', item, error);
                 return parseItemFromAPI({
                   id: item.id || 0,
                   name: item.name || 'Item sem nome',
                   type: 'tool',
                   quantity: 0,
                   minQuantity: 0,
                   maxQuantity: 0,
                   unit: 'unit',
                   active: true,
                   location: '',
                   tags: null,
                   notes: null,
                   createdAt: new Date().toISOString(),
                   updatedAt: new Date().toISOString(),
                   acquisitionDate: null,
                   storagePlaceId: null,
                   size: '',
                   manufacturer: '',
                   serialNumber: '',
                   model: '',
                   acquisitionContext: '',
                   description: '',
                   partNumber: '',
                   value: '',
                   footprint: '',
                 });
               }
             });

             setItems(processedItems);
           } else {
             console.warn('Items data não está no formato esperado:', itemsData);
             setItems([]);
           }
         } catch (error) {
           console.error('Erro ao processar resposta de itens:', error);
           setItems([]);
         }
       } else {
         console.warn('Falha ao carregar itens:', itemsResponse);
         setItems([]);
       }

       // Handle people response
       if (peopleResponse.status === 'fulfilled' && peopleResponse.value?.ok) {
         try {
           const peopleData = await peopleResponse.value.json();
           if (Array.isArray(peopleData)) {
             const processedPeople = peopleData.map((person: any) => {
               try {
                 return parsePersonFromAPI(person);
               } catch (error) {
                 console.warn('Error processing person:', person, error);
                 return parsePersonFromAPI({
                   id: person.id || 0,
                   name: person.name || 'Pessoa sem nome',
                   email: '',
                   phone: null,
                   team: '',
                   createdAt: new Date().toISOString(),
                   updatedAt: new Date().toISOString()
                 });
               }
             });
             setPeople(processedPeople);
           } else {
             console.warn('People data não está no formato esperado:', peopleData);
             setPeople([]);
           }
         } catch (error) {
           console.error('Erro ao processar resposta de pessoas:', error);
           toast({
             title: "Erro ao carregar pessoas",
             description: "Falha ao processar dados das pessoas",
             variant: "destructive",
           });
           setPeople([]);
         }
       } else {
         console.warn('Falha ao carregar pessoas:', peopleResponse);
         toast({
           title: "Erro ao carregar pessoas",
           description: "Falha na requisição para carregar pessoas",
           variant: "destructive",
         });
         setPeople([]);
       }

       setError(null);
     } catch (err: any) {
       const errorMessage = err.message || 'Erro ao carregar dados';
       setError(errorMessage);
       console.error('Erro ao carregar itens ou pessoas:', err);
       toast({
         title: "Erro ao carregar dados",
         description: errorMessage,
         variant: "destructive",
       });
     }
  };

  // Efeito para carregar dados iniciais (empréstimos, itens, pessoas) quando o usuário loga
  useEffect(() => {
    const loadData = async () => {
      if (user) {
        setIsLoading(true);
        await Promise.all([refreshLoans(), refreshItemsAndPeople()]);
        setIsLoading(false);
      } else {
        setLoans([]);
        setItems([]);
        setPeople([]);
        setIsLoading(false);
      }
    };
    loadData();
  }, [user]);

  // Efeito para configurar listeners de socket
  useEffect(() => {
    if (!user || !socket) {
      if (socket) {
        socket.off('loans-update');
      }
      return;
    }

    const handleLoansUpdate = (payload: { deletedLoanId: number } | RawLoanFromSocket | RawLoanFromSocket[]) => {
      console.log('Socket: loans-update received', payload);
      // Para atualizações via socket, recarregamos os dados para garantir consistência
      // Isso é mais simples do que tentar manipular o estado paginado localmente
      try {
        refreshLoans({ page: loansPage, pageSize: loansPageSize }).catch((error) => {
          console.error('Error refreshing loans after socket update:', error);
        });
      } catch (error) {
        console.error('Error handling socket loans update:', error);
      }
    };

    socket.on('loans-update', handleLoansUpdate);

    return () => {
      if (socket) {
        socket.off('loans-update', handleLoansUpdate);
      }
    };
  }, [user, socket, loansPage, loansPageSize]);

  // Implementação das funções auxiliares e de ação
  const createLoan = async (loanData: InsertLoan) => {
    if (!user || !user.personId) {
      toast({ title: "Erro", description: "Usuário não autenticado ou sem ID de pessoa associado.", variant: "destructive" });
      throw new Error("User not authenticated or missing personId");
    }
    try {
      setIsLoading(true);
      await apiRequest('POST', '/api/loans', loanData);
      toast({
        title: "Sucesso",
        description: "Empréstimo registrado com sucesso!",
        variant: "success",
      });
      await refreshLoans({ page: loansPage, pageSize: loansPageSize }); // Recarrega a página atual
      await refreshItemsAndPeople(); // Recarrega itens para atualizar disponibilidade
    } catch (error: any) {
      console.error('Error creating loan:', error);
      toast({
        title: "Erro ao registrar empréstimo",
        description: error.message || "Ocorreu um erro ao registrar o empréstimo.",
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const returnItem = async (loanId: number) => {
    if (!user) {
      toast({ title: "Erro", description: "Usuário não autenticado.", variant: "destructive" });
      throw new Error("User not authenticated");
    }
    try {
      setIsLoading(true);
      await apiRequest('PUT', `/api/loans/${loanId}/return`);
      toast({
        title: "Sucesso",
        description: "Empréstimo devolvido com sucesso!",
        variant: "success",
      });
      await refreshLoans({ page: loansPage, pageSize: loansPageSize }); // Recarrega a página atual
      await refreshItemsAndPeople(); // Recarrega itens para atualizar disponibilidade
    } catch (error: any) {
      console.error('Error returning loan:', error);
      toast({
        title: "Erro ao devolver empréstimo",
        description: error.message || "Ocorreu um erro ao devolver o empréstimo.",
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // --- Implementação das funções auxiliares ---
  const getActiveLoansCount = useMemo(() => {
      return () => loans.filter(loan => !loan.returnDate).length;
  }, [loans]);

  const getExpiredLoansCount = useCallback((): number => {
    try {
      return loans.filter(loan => {
        try {
          return isLoanExpired(loan);
        } catch (error) {
          console.error('Error checking expiration for loan:', loan.id, error);
          return false;
        }
      }).length;
    } catch (error) {
      console.error('Error getting expired loans count:', error);
      return 0;
    }
  }, [loans, isLoanExpired]);

  console.log('Dados brutos dos empréstimos:', loans);
  
  const getRecentLoans = useCallback((limit: number = 5): Loan[] => {
    try {
      // 1. Filtra para garantir que 'loanDate' seja um objeto Date válido.
      // A verificação foi simplificada, mas continua robusta.
      const validLoans = loans.filter(loan => 
        loan.loanDate instanceof Date && !isNaN(loan.loanDate.getTime())
      );

      // 2. Cria uma cópia para não mutar o estado original, ordena e pega os itens mais recentes.
      // O try...catch interno foi removido, pois o filtro já garante a validade das datas.
      return validLoans
        .slice() 
        .sort((a, b) => b.loanDate.getTime() - a.loanDate.getTime())
        .slice(0, limit);

    } catch (error) {
      // O catch principal é mantido como uma salvaguarda geral.
      console.error('Error getting recent loans:', error);
      return [];
    }
  }, [loans]);

  const getPopularItems = useMemo(() => {
      return (count: number) => {
          const loanCounts: { [itemId: number]: number } = {};
          loans.forEach(loan => {
              const item = items.find(i => i.id === loan.itemId);
              if (item && item.type !== 'disposable') {
                 loanCounts[loan.itemId] = (loanCounts[loan.itemId] || 0) + 1;
              }
          });

          const sortedPopularItems = Object.entries(loanCounts)
              .map(([itemId, count]) => {
                  const item = items.find(i => i.id === parseInt(itemId));
                  return item ? { item, count } : null;
              })
              .filter(itemCount => itemCount !== null)
              .sort((a, b) => (b?.count || 0) - (a?.count || 0)) as { item: Item, count: number }[];

          return sortedPopularItems.slice(0, count);
      };
  }, [loans, items]);

   const getItemLoanCount = useMemo(() => {
       return (itemId: number) => loans.filter(loan => loan.itemId === itemId).length;
   }, [loans]);

  const getItemById = useMemo(() => {
      return (itemId: number) => items.find(item => item.id === itemId);
  }, [items]);

  const getPersonById = useMemo(() => {
      return (personId: number) => people.find(person => person.id === personId);
  }, [people]);

  const isLoanExpired = useCallback((loan: Loan): boolean => {
    try {
      if (!loan.dueDate || loan.returnDate || loan.isIndefinite) return false;

      // Ensure dueDate is a valid Date object
      if (!(loan.dueDate instanceof Date) || typeof loan.dueDate.getTime !== 'function' || isNaN(loan.dueDate.getTime())) {
        console.warn('Invalid dueDate in isLoanExpired:', loan.dueDate, 'for loan:', loan.id);
        return false;
      }

      return new Date().getTime() > loan.dueDate.getTime();
    } catch (error) {
      console.error('Error checking if loan is expired:', error, loan);
      return false;
    }
  }, []);

  const getAvailableItems = useMemo(() => {
      return () => {
          const borrowedItemIds = new Set(
              loans.filter(loan => !loan.returnDate).map(loan => loan.itemId)
          );

          return items.filter(item =>
              (item.type === 'tool' || item.type === 'equipment') &&
              !borrowedItemIds.has(item.id)
          );
      };
  }, [items, loans]);

  // Final validation for all loans before exposing them
  const validatedLoans = useMemo(() => {
    return loans.map(loan => {
      try {
        // Ensure all date properties are valid Date objects
        const validatedLoan = { ...loan };

        datePropertyNames.forEach(propName => {
          const propValue = (loan as any)[propName];
          if (propValue && !(propValue instanceof Date)) {
            console.warn(`🔧 Fixing invalid ${propName} in loan ${loan.id}:`, propValue);
            const validDate = parseDate(propValue, `final-validation-${loan.id}-${propName}`);
            (validatedLoan as any)[propName] = validDate || (propName === 'loanDate' || propName === 'createdAt' || propName === 'updatedAt' ? new Date() : null);
          }
        });

        return validatedLoan;
      } catch (error) {
        console.error(`❌ Error validating loan ${loan.id}:`, error);
        return loan;
      }
    });
  }, [loans]);

  const contextValue = useMemo(() => ({
    loans: validatedLoans,
    items,
    people,
    isLoading,
    error,
    refreshLoans,
    refreshItemsAndPeople,
    createLoan,
    returnItem,
    getActiveLoansCount,
    getExpiredLoansCount,
    getRecentLoans,
    getPopularItems,
    getItemById,
    getPersonById,
    isLoanExpired,
    getAvailableItems,
    getItemLoanCount,
    totalLoans,
    loansPage,
    loansPageSize,
    loansTotalPages,
  }), [
    validatedLoans,
    items,
    people,
    isLoading,
    error,
    refreshLoans,
    refreshItemsAndPeople,
    createLoan,
    returnItem,
    getActiveLoansCount,
    getExpiredLoansCount,
    getRecentLoans,
    getPopularItems,
    getItemById,
    getPersonById,
    isLoanExpired,
    getAvailableItems,
    getItemLoanCount,
    totalLoans,
    loansPage,
    loansPageSize,
    loansTotalPages,
  ]);

  return <LendingContext.Provider value={contextValue}>{children}</LendingContext.Provider>;
};

export const useLending = () => {
  const context = useContext(LendingContext);
  if (!context) {
    throw new Error('useLending must be used within a LendingProvider');
  }
  return context;
};
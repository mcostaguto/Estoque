import React, { createContext, useState, useEffect, useContext, ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { z } from 'zod';
import { AppUser } from '@shared/schema'; //, LoginPayload

interface AuthContextType {
  user: AppUser | null; // <-- RENOMEADO: user (any) para AppUser | null
  login: (username: string, password: string) => Promise<void>; // <-- RENOMEADO: email para username
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<AppUser | null>(null); // <-- RENOMEADO: user (any) para AppUser | null
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      // É importante garantir que o dado parseado seja do tipo AppUser.
      // O Zod pode ser usado para validar isso se houver dúvida sobre a integridade do localStorage.
      setUser(JSON.parse(storedUser) as AppUser); // <-- Casting para AppUser
    }
    setIsLoading(false);
  }, []);

  // <-- RENOMEADO: email para username nos parâmetros da função
  const login = async (username: string, password: string) => {
    const schema = z.object({
      username: z.string().min(1, "Usuário é obrigatório"), // <-- RENOMEADO: email para username
      password: z.string().min(1, "Senha é obrigatória"),
    });

    schema.parse({ username, password }); // <-- RENOMEADO: email para username

    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      // <-- RENOMEADO: email para username
      body: JSON.stringify({ username, password }),
    });

    if (response.ok) {
      const userData: { appUser: AppUser; token: string } = await response.json(); // <-- NOVO: Tipar a resposta
      setUser(userData.appUser); // <-- NOVO: Usar userData.appUser
      localStorage.setItem('user', JSON.stringify(userData.appUser)); // <-- NOVO: Armazenar apenas userData.appUser
      navigate('/dashboard');
    } else {
      // Melhorar o tratamento de erro para exibir mensagens do backend
      const errorData = await response.json();
      throw new Error(errorData.message || 'Falha no login');
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
    navigate('/login');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth deve ser usado dentro de um AuthProvider');
  }
  return context;
};
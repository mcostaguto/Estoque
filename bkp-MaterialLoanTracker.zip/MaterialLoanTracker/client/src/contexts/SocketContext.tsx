import React, { createContext, useContext, ReactNode } from 'react';

interface SocketContextType {
  socket: null;
  isConnected: boolean;
}

const SocketContext = createContext<SocketContextType | undefined>(undefined);

interface SocketProviderProps {
  children: ReactNode;
}

export const SocketProvider: React.FC<SocketProviderProps> = ({ children }) => {
  // Socket.IO is disabled to prevent connection errors
  // The application will work without real-time updates
  const value: SocketContextType = {
    socket: null,
    isConnected: false,
  };

  return (
    <SocketContext.Provider value={value}>
      {children}
    </SocketContext.Provider>
  );
};

export const useSocket = () => {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error('useSocket must be used within a SocketProvider');
  }
  return context;
};
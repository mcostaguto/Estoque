import React, { createContext, useContext, useState, useEffect, ReactNode, useMemo } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useSocket } from '@/contexts/SocketContext';
import { useToast } from '@/hooks/use-toast';
import {
  Item,
  InventoryMovement,
  InsertInventoryMovement,
  PaginationParams,
  SearchFilterParams,
  InventoryMovementFilterParams,
  paginatedResponseSchema, // Importa o schema de resposta paginada
  itemSchema, // NOVO: Importa o schema Zod para Item
  inventoryMovementSchema // NOVO: Importa o schema Zod para InventoryMovement
} from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { z } from 'zod'; // Importa Zod para validação
import { parseItemFromAPI } from '@/lib/dateUtils'; // Importa a função de parsing de data

// Helper function to ensure we always have a valid Date object for required date fields
const ensureDate = (dateString: any, fallback: Date = new Date()): Date => {
  if (!dateString || dateString === '' || dateString === 'null' || dateString === 'undefined') {
    return fallback;
  }
  try {
    const date = new Date(dateString);
    return isNaN(date.getTime()) ? fallback : date;
  } catch {
    return fallback;
  }
};

// Tipos auxiliares para clareza
type ConsumableItem = Item; // Um item do tipo 'disposable'
type Withdrawal = InventoryMovement; // Uma movimentação de inventário do tipo 'withdrawal'

// NOVO: Define o schema para a resposta paginada de itens
const paginatedItemSchema = paginatedResponseSchema(itemSchema);
type PaginatedItemsResponse = z.infer<typeof paginatedItemSchema>;

// NOVO: Define o schema para a resposta paginada de movimentações de inventário
const paginatedInventoryMovementSchema = paginatedResponseSchema(inventoryMovementSchema);
type PaginatedInventoryMovementsResponse = z.infer<typeof paginatedInventoryMovementSchema>;


// Define a interface do contexto para tipagem forte
interface ConsumablesContextType {
  consumables: ConsumableItem[]; // Lista de insumos
  withdrawals: Withdrawal[]; // Histórico de retiradas
  isLoading: boolean; // Indica se os dados estão sendo carregados
  error: string | null; // Mensagem de erro, se houver
  refreshConsumables: (params?: PaginationParams & SearchFilterParams) => Promise<void>; // Adicionado params
  refreshWithdrawals: (params?: PaginationParams & SearchFilterParams & InventoryMovementFilterParams) => Promise<void>; // Adicionado params
  withdrawItem: (itemId: number, quantity: number, notes?: string) => Promise<void>; // Função para registrar retirada
  restockItem: (itemId: number, quantity: number, notes?: string) => Promise<void>; // Função para registrar reabastecimento
  adjustInventory: (itemId: number, newQuantity: number, notes?: string) => Promise<void>; // Função para ajustar estoque
  getConsumableById: (itemId: number) => ConsumableItem | undefined; // Função para buscar insumo por ID
  // Novos campos para paginação de insumos
  totalConsumables: number;
  consumablesPage: number;
  consumablesPageSize: number;
  consumablesTotalPages: number;
  // Novos campos para paginação de retiradas
  totalWithdrawals: number;
  withdrawalsPage: number;
  withdrawalsPageSize: number;
  withdrawalsTotalPages: number;
}

// Cria o contexto React
const ConsumablesContext = createContext<ConsumablesContextType | undefined>(undefined);

// Define as props para o provedor do contexto
interface ConsumablesProviderProps {
  children: ReactNode;
}

// Componente provedor do contexto
export const ConsumablesProvider: React.FC<ConsumablesProviderProps> = ({ children }) => {
  const [consumables, setConsumables] = useState<ConsumableItem[]>([]);
  const [totalConsumables, setTotalConsumables] = useState(0);
  const [consumablesPage, setConsumablesPage] = useState(1);
  const [consumablesPageSize, setConsumablesPageSize] = useState(10);
  const [consumablesTotalPages, setConsumablesTotalPages] = useState(1);

  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [totalWithdrawals, setTotalWithdrawals] = useState(0);
  const [withdrawalsPage, setWithdrawalsPage] = useState(1);
  const [withdrawalsPageSize, setWithdrawalsPageSize] = useState(10);
  const [withdrawalsTotalPages, setWithdrawalsTotalPages] = useState(1);

  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth(); // Obtém o usuário autenticado do AuthContext
  const { toast } = useToast(); // Hook para exibir notificações toast
  const { socket } = useSocket(); // Obtém a instância do socket do SocketContext

  // Função para carregar insumos (itens do tipo 'disposable') do backend
  const refreshConsumables = async (params?: PaginationParams & SearchFilterParams) => {
    if (!user) { // Se não houver usuário logado, limpa os insumos
      setConsumables([]);
      setTotalConsumables(0);
      setConsumablesPage(1);
      setConsumablesPageSize(10);
      setConsumablesTotalPages(1);
      return;
    }
    try {
      // Faz a requisição para buscar todos os itens, filtrando por tipo 'disposable'
      // Passa os parâmetros de paginação e busca
      const response = await apiRequest('GET', '/api/inventory/items', undefined, {
        ...params,
        itemType: 'disposable' // Filtra apenas insumos
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch consumables: ${response.status}`);
      }

      const data = await response.json();

      // Validate response format
      if (!data || !Array.isArray(data.data)) {
        console.warn('Invalid consumables response format:', data);
        setConsumables([]);
        setTotalConsumables(0);
        return;
      }

      // Processa os dados com parseItemFromAPI para garantir o parsing correto das datas
      const processedConsumables = data.data.map((item: any) => parseItemFromAPI(item));

      setConsumables(processedConsumables);
      setTotalConsumables(Number(data.total) || 0);
      setConsumablesPage(Number(data.page) || 1);
      setConsumablesPageSize(Number(data.pageSize) || 10);
      setConsumablesTotalPages(Number(data.totalPages) || 1);
      setError(null); // Limpa qualquer erro anterior
    } catch (err: any) {
      const errorMessage = err.message || 'Erro ao carregar insumos';
      setError(errorMessage);
      console.error('Erro ao carregar insumos:', err);
      toast({
        title: "Erro ao carregar insumos",
        description: errorMessage,
        variant: "destructive",
      });
    }
  };

  // Função para carregar o histórico de retiradas (movimentações de inventário do tipo 'withdrawal')
  const refreshWithdrawals = async (params?: PaginationParams & SearchFilterParams & InventoryMovementFilterParams) => {
      if (!user) { // Se não houver usuário logado, limpa o histórico
          setWithdrawals([]);
          setTotalWithdrawals(0);
          setWithdrawalsPage(1);
          setWithdrawalsPageSize(10);
          setWithdrawalsTotalPages(1);
          return;
      }
      try {
          // Faz a requisição para buscar todas as movimentações de inventário
          const response = await apiRequest('GET', '/api/inventory/inventory-movements', undefined, {
            ...params,
            movementType: 'withdrawal' // Filtra apenas retiradas
          });
          const data: PaginatedInventoryMovementsResponse = await response.json();

          // Processa os dados com parsing de datas
          const processedWithdrawals = data.data.map((movement: any) => ({
              ...movement,
              id: movement.id || 0,
              itemId: movement.itemId || 0,
              quantity: movement.quantity || 0,
              type: movement.type || 'withdrawal',
              personId: movement.personId || 0,
              notes: movement.notes || null,
              date: ensureDate(movement.date, new Date()),
              createdAt: ensureDate(movement.createdAt, new Date()),
              updatedAt: ensureDate(movement.updatedAt, new Date()),
          }));

          setWithdrawals(processedWithdrawals);
          setTotalWithdrawals(data.total);
          setWithdrawalsPage(data.page);
          setWithdrawalsPageSize(data.pageSize);
          setWithdrawalsTotalPages(data.totalPages);
          setError(null);
      } catch (err: any) {
          setError(err.message);
          console.error('Erro ao carregar histórico de movimentações:', err);
          toast({
              title: "Erro ao carregar histórico",
              description: err.message,
              variant: "destructive",
          });
      }
  };

  // Efeito para carregar dados iniciais (insumos e histórico) quando o usuário loga
  useEffect(() => {
    const loadData = async () => {
      if (user) {
        setIsLoading(true); // Inicia o estado de carregamento
        await Promise.all([refreshConsumables(), refreshWithdrawals()]); // Carrega ambos em paralelo
        setIsLoading(false); // Finaliza o estado de carregamento
      } else {
        setConsumables([]); // Limpa insumos
        setWithdrawals([]); // Limpa histórico
        setIsLoading(false);
      }
    };
    loadData();
  }, [user]); // Este efeito é re-executado quando o objeto 'user' muda

  // Efeito para configurar listeners de socket para atualizações em tempo real
  useEffect(() => {
    if (!user || !socket) { // Se não houver usuário ou socket, remove listeners existentes
      if (socket) {
        socket.off('consumables-update');
        socket.off('inventory-movement-added');
      }
      return;
    }

    // Listener para atualizações de insumos (criação, atualização, exclusão) via socket
    const handleConsumablesUpdate = (payload: ConsumableItem | ConsumableItem[] | { deletedItemId: number }) => {
      console.log('Socket: consumables-update received', payload);
      // Recarrega os insumos para garantir que a lista paginada seja atualizada
      refreshConsumables({ page: consumablesPage, pageSize: consumablesPageSize });
    };

    // Listener para novas movimentações de inventário (retirada, adição, ajuste) via socket
    const handleInventoryMovementAdded = (newMovement: InventoryMovement) => {
      console.log('Socket: inventory-movement-added received', newMovement);
      // Recarrega as retiradas para garantir que a lista paginada seja atualizada
      refreshWithdrawals({ page: withdrawalsPage, pageSize: withdrawalsPageSize, movementType: 'withdrawal' });

      // Exibe um toast de notificação para o usuário
      const item = consumables.find(c => c.id === newMovement.itemId);
      if (item) {
        toast({
          title: newMovement.type === 'addition' ? "Entrada de Estoque" : newMovement.type === 'withdrawal' ? "Retirada de Insumo" : "Ajuste de Estoque",
          description: `${newMovement.quantity} unidade(s) de ${item.name} movimentada(s).`,
          variant: newMovement.type === 'addition' ? "success" : newMovement.type === 'withdrawal' ? "default" : "default", // Ajusta a variante do toast
        });
      }
    };

    // Registra os listeners do socket
    socket.on('consumables-update', handleConsumablesUpdate);
    socket.on('inventory-movement-added', handleInventoryMovementAdded);

    // Função de limpeza: remove os listeners quando o componente é desmontado ou dependências mudam
    return () => {
      if (socket) {
        socket.off('consumables-update', handleConsumablesUpdate);
        socket.off('inventory-movement-added', handleInventoryMovementAdded);
      }
    };
  }, [user, socket, consumables, toast, refreshConsumables, refreshWithdrawals, consumablesPage, consumablesPageSize, withdrawalsPage, withdrawalsPageSize]); // Dependências do efeito

  // Função para registrar retirada de insumo
  const withdrawItem = async (itemId: number, quantity: number, notes: string = '') => {
    if (!user || !user.personId) {
      toast({ title: "Erro", description: "Usuário não autenticado ou sem ID de pessoa associado.", variant: "destructive" });
      throw new Error("User not authenticated or missing personId");
    }
    try {
      setIsLoading(true); // Inicia o carregamento
      // Prepara os dados da movimentação conforme o schema compartilhado
      const movementData: InsertInventoryMovement = {
          itemId,
          quantity,
          type: 'withdrawal', // Tipo de movimentação: retirada
          personId: user.personId, // ID da pessoa que está realizando a ação
          notes,
      };
      // Envia a requisição POST para o backend
      await apiRequest('POST', '/api/inventory-movements', movementData);
      // A atualização do estado e o toast de sucesso virão via socket
      // refreshConsumables e refreshWithdrawals serão chamados pelo listener do socket
    } catch (error: any) {
      console.error('Error withdrawing item:', error);
      toast({
        title: "Erro ao registrar retirada",
        description: error.message || "Ocorreu um erro ao registrar a retirada.",
        variant: "destructive",
      });
      throw error; // Re-lança o erro para ser tratado pelo componente que chamou
    } finally {
      setIsLoading(false); // Finaliza o carregamento
    }
  };

  // Função para registrar reabastecimento de insumo
  const restockItem = async (itemId: number, quantity: number, notes: string = '') => {
    if (!user || !user.personId) {
      toast({ title: "Erro", description: "Usuário não autenticado ou sem ID de pessoa associado.", variant: "destructive" });
      throw new Error("User not authenticated or missing personId");
    }
    try {
      setIsLoading(true);
      const movementData: InsertInventoryMovement = {
          itemId,
          quantity,
          type: 'addition', // Tipo de movimentação: adição
          personId: user.personId,
          notes,
      };
      await apiRequest('POST', '/api/inventory-movements', movementData);
      // refreshConsumables e refreshWithdrawals serão chamados pelo listener do socket
    } catch (error: any) {
      console.error('Error restocking item:', error);
      toast({
        title: "Erro ao registrar reabastecimento",
        description: error.message || "Ocorreu um erro ao registrar o reabastecimento.",
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Função para ajustar estoque de insumo
  const adjustInventory = async (itemId: number, newTotalQuantity: number, notes: string = '') => {
    if (!user || !user.personId) {
      toast({ title: "Erro", description: "Usuário não autenticado ou sem ID de pessoa associado.", variant: "destructive" });
      throw new Error("User not authenticated or missing personId");
    }
    try {
      setIsLoading(true);
      const item = consumables.find(c => c.id === itemId);
      if (!item) {
           throw new Error("Insumo não encontrado para ajuste.");
      }
      const currentQuantity = item.quantity ?? 0;
      const quantityDifference = newTotalQuantity - currentQuantity; // Calcula a diferença para o ajuste

      const movementData: InsertInventoryMovement = {
          itemId,
          quantity: quantityDifference, // A quantidade aqui é a DIFERENÇA (pode ser positiva ou negativa)
          type: 'adjustment', // Tipo de movimentação: ajuste
          personId: user.personId,
          notes: notes || "Ajuste de inventário",
      };
      await apiRequest('POST', '/api/inventory-movements', movementData);
      // refreshConsumables e refreshWithdrawals serão chamados pelo listener do socket
    } catch (error: any) {
      console.error('Error adjusting inventory:', error);
      toast({
        title: "Erro ao ajustar estoque",
        description: error.message || "Ocorreu um erro ao ajustar o estoque.",
        variant: "destructive",
      });
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  // Memoiza a função para buscar insumo por ID para otimização
  const getConsumableById = useMemo(() => {
      return (itemId: number) => consumables.find(item => item.id === itemId);
  }, [consumables]);

  // Objeto de valor do contexto que será fornecido aos componentes filhos
  const value: ConsumablesContextType = {
    consumables,
    withdrawals,
    isLoading,
    error,
    refreshConsumables,
    refreshWithdrawals,
    withdrawItem,
    restockItem,
    adjustInventory,
    getConsumableById,
    totalConsumables,
    consumablesPage,
    consumablesPageSize,
    consumablesTotalPages,
    totalWithdrawals,
    withdrawalsPage,
    withdrawalsPageSize,
    withdrawalsTotalPages,
  };

  return <ConsumablesContext.Provider value={value}>{children}</ConsumablesContext.Provider>;
};

// Hook personalizado para usar o contexto de insumos
export const useConsumables = () => {
  const context = useContext(ConsumablesContext);
  if (!context) {
    throw new Error('useConsumables must be used within a ConsumablesProvider');
  }
  return context;
};
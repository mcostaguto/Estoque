import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { InsertItem, Item, StoragePlace } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { parseItemFromAPI } from '@/lib/dateUtils';


// <--- CORREÇÃO AQUI: Adicionar 'export'
export const InventoryContext = createContext<InventoryContextType | undefined>(undefined);

interface InventoryContextType {
  isLoading: boolean;
  error: string | null;
  addItem: (itemData: Omit<InsertItem, 'performingPersonId'>) => Promise<Item>;
  storagePlaces: StoragePlace[];
  refreshStoragePlaces: () => Promise<void>;
}


interface InventoryProviderProps {
  children: ReactNode;
}

export const InventoryProvider: React.FC<InventoryProviderProps> = ({ children }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [storagePlaces, setStoragePlaces] = useState<StoragePlace[]>([]);
  const { user } = useAuth();

  const refreshStoragePlaces = async () => {
    if (!user) {
      setStoragePlaces([]);
      return;
    }
    try {
      const response = await apiRequest('GET', '/api/storage-places');
      // <--- CORREÇÃO AQUI: Chamar .json() na resposta
      const data = await response.json();
      setStoragePlaces(data.map((place: any) => ({
        ...place,
        createdAt: new Date(place.createdAt)
      })));
      setError(null);
    } catch (err: any) {
      setError(err.message || 'Falha ao carregar locais de armazenamento.');
      useToast().toast({
        title: "Erro ao carregar locais",
        description: err.message,
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    if (user) {
      refreshStoragePlaces();
    } else {
      setStoragePlaces([]);
    }
  }, [user]);


  const addItem = async (itemData: Omit<InsertItem, 'performingPersonId'>): Promise<Item> => {
    setIsLoading(true);
    setError(null);
    try {
      if (!user || !user.personId) {
         throw new Error("Usuário não autenticado ou sem ID de pessoa associado.");
      }

      const dataToSend: InsertItem = {
          ...itemData,
          performingPersonId: user.personId,
      };

      const response = await apiRequest('POST', '/api/items', dataToSend);
      // <--- CORREÇÃO AQUI: Chamar .json() na resposta antes de retornar
      const newItem = await response.json();

      setIsLoading(false);
      return newItem;
    } catch (err: any) {
      console.error('Error adding item:', err);
      setError(err.message || 'Erro ao adicionar item.');
      setIsLoading(false);
      throw err;
    }
  };

  const value: InventoryContextType = {
    isLoading,
    error,
    addItem,
    storagePlaces,
    refreshStoragePlaces,
  };

  return <InventoryContext.Provider value={value}>{children}</InventoryContext.Provider>;
};

export const useInventory = () => {
  const context = useContext(InventoryContext);
  if (!context) {
    throw new Error('useInventory must be used within an InventoryProvider');
  }
  return context;
};
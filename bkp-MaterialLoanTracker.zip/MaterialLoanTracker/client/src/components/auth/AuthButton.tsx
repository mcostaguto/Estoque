// client/src/components/auth/AuthButton.tsx

import React from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";

const AuthButton = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="flex items-center">
      {user && (
        <>
          {/* CORRIGIDO: Acessa o nome da pessoa via user.person?.name */}
          <span className="mr-2 text-sm">Olá, {user.person?.name || user.username}</span>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleLogout}
            className="flex items-center"
          >
            <LogOut className="mr-1" size={16} />
            Sair
          </Button>
        </>
      )}
    </div>
  );
};

export default AuthButton;
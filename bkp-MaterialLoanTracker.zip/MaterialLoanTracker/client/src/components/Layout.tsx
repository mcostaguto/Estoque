import React from 'react';
import { Link, useLocation, Outlet } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button'; // Assumindo o caminho correto para o Button
import { LogOut } from 'lucide-react';

const Layout: React.FC = () => {
  const location = useLocation();
  const { user, logout } = useAuth();

  const navItems = [
    { path: '/dashboard', label: 'Dashboard' },
    { path: '/warehouse-register', label: 'Cadastros' }, // ATUALIZADO: Aponta para a nova página de cadastro do almoxarifado
    { path: '/warehouse', label: 'Almoxarifado' }, // Almoxarifado com abas Empréstimos e Retiradas
    { path: '/relatorios', label: 'Relatórios' }, // Leva para a página com Tabs de relatórios
    // NOVO: Link para a gestão de usuários (visível apenas para admins)
    { path: '/users/management', label: 'Gestão de Usuários', adminOnly: true },
    // NOVO: Link para configurações de conta (visível para todos os usuários logados)
    { path: '/users/account-settings', label: 'Minha Conta' },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-xl font-semibold">Sistema de Controle de Materiais</h1>
          <nav className="flex space-x-4">
            {navItems.map((item) => {
              // Lógica para esconder links baseados em permissões
              // user.type === 'admin' é um exemplo, ajuste conforme seu UserType
              const shouldRender = !item.adminOnly || (user && user.type === 'admin');
              if (!shouldRender) return null;

              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`px-3 py-2 rounded-md text-sm font-medium ${
                    // Verifica se o caminho atual começa com o item.path para destacar a aba
                    location.pathname.startsWith(item.path)
                      ? 'bg-blue-500 text-white' : 'text-gray-700'
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
          {user && (
            <Button variant="ghost" onClick={logout}>
              <LogOut className="mr-1" size={16} />
              Sair
            </Button>
          )}
        </div>
      </header>
      <main className="flex-grow container mx-auto px-4 py-6">
        <Outlet />
      </main>
      <footer className="bg-white border-t py-4">
        <div className="container mx-auto text-center text-sm text-gray-500">
          Sistema de Controle de Materiais &copy; {new Date().getFullYear()}
        </div>
      </footer>
    </div>
  );
};

export default Layout;
import React, { useState, useEffect } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { registerUserSchema, appUserSchema, UserType } from '@shared/schema';
import { z } from 'zod';

// Propriedades do modal
interface appUserFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void; // Chamado após sucesso na criação/edição
  editingUser?: z.infer<typeof appUserSchema> | null; // Usuário a ser editado, se houver
}

const appUserFormModal: React.FC<appUserFormModalProps> = ({ isOpen, onClose, onSuccess, editingUser }) => {
  const { toast } = useToast();
  const [username, setUsername] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [equipe, setEquipe] = useState('');
  const [type, setType] = useState<UserType>('basic');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isActive, setIsActive] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [formErrors, setFormErrors] = useState<Record<string, string | undefined>>({});

  useEffect(() => {
    if (isOpen) {
      setFormErrors({}); // Limpa erros ao abrir o modal
      if (editingUser) {
        setUsername(editingUser.username);
        setName(editingUser.name);
        setEmail(editingUser.email);
        setEquipe(editingUser.equipe);
        setType(editingUser.type);
        setIsActive(editingUser.isActive);
        setPassword(''); // Senha nunca é preenchida para edição
        setConfirmPassword('');
      } else {
        // Reset para criação
        setUsername('');
        setName('');
        setEmail('');
        setEquipe('');
        setType('basic');
        setPassword('');
        setConfirmPassword('');
        setIsActive(true);
      }
    }
  }, [isOpen, editingUser]);

  const handleSubmit = async () => {
    setFormErrors({});
    setIsLoading(true);

    // Schema para validação. Adapta para criação ou edição.
    const schema = editingUser
      ? registerUserSchema.partial().extend({
          type: z.enum(['admin', 'manager', 'user']).optional(), // Permite mudar tipo na edição
          isActive: z.boolean().optional(),
          password: z.string().min(6, "A senha deve ter pelo menos 6 caracteres.").optional(),
        }).refine(data => !data.password || data.password === confirmPassword, {
            message: "As senhas não coincidem.",
            path: ["confirmPassword"],
        })
      : registerUserSchema.extend({
          password: z.string().min(6, "A senha deve ter pelo menos 6 caracteres."),
        }).refine(data => data.password === confirmPassword, {
            message: "As senhas não coincidem.",
            path: ["confirmPassword"],
        });

    try {
      let payload: any = { name, email, equipe, type, isActive };

      if (!editingUser) { // Campos específicos para criação
        payload = { username, password, ...payload };
      } else { // Campos específicos para edição
        if (password) { // Se a senha foi preenchida, inclui no payload de edição
            payload.password = password;
        }
      }

      schema.parse(payload); // Valida o payload final

      if (editingUser) {
        await apiRequest('PUT', `/api/users/${editingUser.userId}`, payload);
        toast({ title: "Sucesso", description: "Usuário atualizado com sucesso.", variant: "success" });
      } else {
        await apiRequest('POST', '/api/users', payload);
        toast({ title: "Sucesso", description: "Usuário criado com sucesso.", variant: "success" });
      }
      onSuccess(); // Chama a função de sucesso para o componente pai recarregar os dados
      onClose(); // Fecha o modal
    } catch (error: any) {
      console.error('Erro ao salvar usuário:', error);
      if (error instanceof z.ZodError) {
        const newErrors: Record<string, string | undefined> = {};
        error.errors.forEach((err: any) => {
          if (err.path && err.path.length > 0) {
            newErrors[err.path[0]] = err.message;
          }
        });

        setFormErrors(newErrors);
        toast({ title: "Erro de Validação", description: "Por favor, corrija os campos indicados.", variant: "destructive" });
      } else {
        toast({ title: "Erro ao salvar usuário", description: error.message || "Ocorreu um erro.", variant: "destructive" });
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{editingUser ? 'Editar Usuário' : 'Criar Novo Usuário'}</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="username" className="text-right">Usuário</Label>
            <Input
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="col-span-3"
              disabled={!!editingUser} // Não permite mudar username na edição
            />
            {formErrors.username && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.username}</p>}
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="name" className="text-right">Nome</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} className="col-span-3" />
            {formErrors.name && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.name}</p>}
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="email" className="text-right">Email</Label>
            <Input id="email" value={email} onChange={(e) => setEmail(e.target.value)} className="col-span-3" />
            {formErrors.email && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.email}</p>}
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="equipe" className="text-right">Equipe</Label>
            <Input id="equipe" value={equipe} onChange={(e) => setEquipe(e.target.value)} className="col-span-3" />
            {formErrors.equipe && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.equipe}</p>}
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="type" className="text-right">Tipo</Label>
            <Select onValueChange={(value: UserType) => setType(value)} value={type}>
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Selecione o tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="manager">Manager</SelectItem>
                <SelectItem value="user">User</SelectItem>
              </SelectContent>
            </Select>
            {formErrors.type && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.type}</p>}
          </div>
          {editingUser && ( // Apenas na edição, permite ativar/desativar
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="isActive" className="text-right">Ativo</Label>
              <Checkbox
                id="isActive"
                checked={isActive}
                onCheckedChange={(checkedState) => {
                    if (typeof checkedState === 'boolean') {
                        setIsActive(checkedState);
                    }
                }}
                className="col-span-3"
              />
            </div>
          )}
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="password" className="text-right">Senha {editingUser ? '(Opcional)' : ''}</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="col-span-3"
            />
            {formErrors.password && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.password}</p>}
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="confirmPassword" className="text-right">Confirmar Senha</Label>
            <Input
              id="confirmPassword"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="col-span-3"
            />
            {formErrors.confirmPassword && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.confirmPassword}</p>}
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isLoading}>Cancelar</Button>
          <Button onClick={handleSubmit} disabled={isLoading}>
            {isLoading ? (editingUser ? 'Salvando...' : 'Criando...') : (editingUser ? 'Salvar Alterações' : 'Criar Usuário')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default appUserFormModal;
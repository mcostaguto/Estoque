import React, { useMemo } from 'react';
import { useLending } from '@/contexts/LendingContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Item } from '@shared/schema';

interface LoanSummaryProps {
  // Pode receber dados filtrados se necessário, mas por enquanto usará o contexto
}

const LoanSummary: React.FC<LoanSummaryProps> = () => {
  const { loans, items, getActiveLoansCount, getExpiredLoansCount } = useLending();

  // Calcula o total de empréstimos devolvidos
  const returnedLoansCount = useMemo(() => {
    return loans.filter(loan => !!loan.returnDate).length;
  }, [loans]);

  // Agrega dados para o gráfico: Empréstimos por Tipo de Item (Ferramenta vs Equipamento)
  const loansByTypeChartData = useMemo(() => {
    const toolLoans = loans.filter(loan => {
      const item = items.find(i => i.id === loan.itemId);
      return item && item.type === 'tool';
    }).length;

    const equipmentLoans = loans.filter(loan => {
      const item = items.find(i => i.id === loan.itemId);
      return item && item.type === 'equipment';
    }).length;

    // Formato JSON para o Plotly Chart
    return JSON.stringify({
      "type": "pie",
      "title": {
        "text": "Empréstimos por Tipo de Item"
      },
      "series": [
        {
          "name": "Ferramentas",
          "data": toolLoans
        },
        {
          "name": "Equipamentos",
          "data": equipmentLoans
        }
      ]
    });
  }, [loans, items]);

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total de Empréstimos</CardTitle>
          <i className="ri-hand-coin-line text-2xl text-muted-foreground"></i>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{loans.length}</div>
          <p className="text-xs text-muted-foreground">
            Total de operações de empréstimo registradas.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Empréstimos Ativos</CardTitle>
          <i className="ri-arrow-left-right-line text-2xl text-muted-foreground"></i>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{getActiveLoansCount()}</div>
          <p className="text-xs text-muted-foreground">
            Itens atualmente emprestados.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Empréstimos Devolvidos</CardTitle>
          <i className="ri-check-double-line text-2xl text-muted-foreground"></i>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{returnedLoansCount}</div>
          <p className="text-xs text-muted-foreground">
            Itens que já foram devolvidos.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Empréstimos Atrasados</CardTitle>
          <i className="ri-calendar-todo-line text-2xl text-muted-foreground"></i>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-red-600">{getExpiredLoansCount()}</div>
          <p className="text-xs text-muted-foreground">
            Itens com prazo de devolução vencido.
          </p>
        </CardContent>
      </Card>

      {/* Card para o Gráfico */}
      <Card className="col-span-full">
        <CardHeader>
          <CardTitle>Visão Geral de Empréstimos</CardTitle>
        </CardHeader>
        <CardContent>
          {/* Renderiza o JSON do gráfico. A plataforma do usuário deve ser capaz de interpretá-lo. */}
          <div className="w-full h-64 flex items-center justify-center bg-slate-50 rounded-lg border-2 border-dashed border-slate-300">
            <div className="text-center">
              <div className="text-slate-600 text-sm mb-2">📊 Gráfico de Empréstimos por Tipo</div>
              <div className="text-slate-500 text-xs">Ferramentas: 0 | Equipamentos: 0</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default LoanSummary;
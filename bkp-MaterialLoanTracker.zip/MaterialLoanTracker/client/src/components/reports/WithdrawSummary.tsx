import React, { useMemo } from 'react';
import { useConsumables } from '@/contexts/ConsumablesContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface WithdrawalSummaryProps {
  // Pode receber dados filtrados se necessário, mas por enquanto usará o contexto
}

const WithdrawalSummary: React.FC<WithdrawalSummaryProps> = () => {
  const { withdrawals, consumables, getConsumableById } = useConsumables();

  // Calcula o total de insumos retirados (quantidade total)
  const totalQuantityWithdrawn = useMemo(() => {
    return withdrawals.reduce((sum, movement) => sum + movement.quantity, 0);
  }, [withdrawals]);

  // Calcula o número de itens únicos retirados
  const uniqueItemsWithdrawn = useMemo(() => {
    const uniqueIds = new Set(withdrawals.map(movement => movement.itemId));
    return uniqueIds.size;
  }, [withdrawals]);

  // Agrega dados para o gráfico: Quantidade Retirada por Insumo
  const quantityByConsumableChartData = useMemo(() => {
    const itemQuantities: { [itemId: number]: number } = {};
    withdrawals.forEach(movement => {
      itemQuantities[movement.itemId] = (itemQuantities[movement.itemId] || 0) + movement.quantity;
    });

    const sortedItems = Object.entries(itemQuantities)
      .sort(([, qtyA], [, qtyB]) => qtyB - qtyA) // Ordena do maior para o menor
      .slice(0, 5); // Pega os 5 insumos mais retirados

    const categories: string[] = [];
    const data: number[] = [];

    sortedItems.forEach(([itemId, quantity]) => {
      const item = getConsumableById(parseInt(itemId));
      categories.push(item?.name || `ID ${itemId}`);
      data.push(quantity);
    });

    // Formato JSON para o Plotly Chart
    return JSON.stringify({
      "type": "bar",
      "title": {
        "text": "Top 5 Insumos Mais Retirados (Quantidade)"
      },
      "series": [
        {
          "name": "Quantidade Retirada",
          "data": data,
          "type": "bar"
        }
      ],
      "categories": categories
    });
  }, [withdrawals, consumables, getConsumableById]);

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total de Retiradas (Operações)</CardTitle>
          <i className="ri-file-list-3-line text-2xl text-muted-foreground"></i>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{withdrawals.length}</div>
          <p className="text-xs text-muted-foreground">
            Número total de operações de retirada.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Quantidade Total Retirada</CardTitle>
          <i className="ri-box-3-line text-2xl text-muted-foreground"></i>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{totalQuantityWithdrawn}</div>
          <p className="text-xs text-muted-foreground">
            Soma das quantidades de todos os insumos retirados.
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Insumos Únicos Retirados</CardTitle>
          <i className="ri-price-tag-3-line text-2xl text-muted-foreground"></i>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{uniqueItemsWithdrawn}</div>
          <p className="text-xs text-muted-foreground">
            Número de tipos diferentes de insumos retirados.
          </p>
        </CardContent>
      </Card>

      {/* Card para o Gráfico */}
      <Card className="col-span-full">
        <CardHeader>
          <CardTitle>Visão Geral de Retiradas</CardTitle>
        </CardHeader>
        <CardContent>
          {/* Renderiza o JSON do gráfico. A plataforma do usuário deve ser capaz de interpretá-lo. */}
          <div className="w-full h-64 flex items-center justify-center bg-slate-50 rounded-lg border-2 border-dashed border-slate-300">
            <div className="text-center">
              <div className="text-slate-600 text-sm mb-2">📈 Gráfico de Retiradas por Insumo</div>
              <div className="text-slate-500 text-xs">Sem movimentações registradas</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default WithdrawalSummary;
import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate, BrowserRouter } from 'react-router-dom';
import { AuthProvider } from '@/contexts/AuthContext';
import { SocketProvider } from '@/contexts/SocketContext';
import { ConsumablesProvider } from '@/contexts/ConsumablesContext';
import { LendingProvider } from '@/contexts/LendingContext';
import { InventoryProvider } from '@/contexts/InventoryContext';
import { Toaster } from '@/components/ui/toaster';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/ErrorBoundary';

// Importações de páginas existentes
import Dashboard from '@/pages/dashboard/dashboard';
import Login from '@/pages/auth/login';
import NotFound from '@/pages/not-found';
import ProtectedRoute from '@/components/auth/ProtectedRoute';
import Layout from '@/components/Layout'; // Caminho atualizado do Layout

// Importações da página principal do almoxarifado (com abas)
import WarehousePage from '@/pages/warehouse/warehouse';

// Importações das páginas de relatórios
import ReportPage from '@/pages/reports/report';

// NOVO/ATUALIZADO: Importação da página principal de cadastro do almoxarifado
import WarehouseRegisterPage from '@/pages/warehouseRegister/warehouseRegister';

// NOVO: Importação para as futuras páginas de gestão de usuários
import UserManagement from '@/pages/appUsers/userManagement'; // Para admins
import AccountSettings from '@/pages/appUsers/accountSettings'; // Para o próprio usuário

function App() {
  const queryClient = new QueryClient();

  return (
    <QueryClientProvider client={queryClient}>
      <ErrorBoundary>
        <AuthProvider>
          <SocketProvider>
            <BrowserRouter>
              <Routes>
                {/* Rotas que não precisam do layout principal (ex: login) */}
                <Route path="/login" element={<Login />} />
                {/*
                  REMOVIDO: <Route path="/register" element={<Register />} />
                  Assumindo que não há registro público direto.
                  Se o registro de usuário for apenas para admins, ele será via /users/management.
                */}

                {/* Rota 404 para caminhos não encontrados */}
                <Route path="*" element={<NotFound />} />

                {/* Rota principal que usa o Layout e aninha as rotas protegidas */}
                <Route element={<ProtectedRoute><Layout /></ProtectedRoute>}>
                  {/* Redirecionamento da raiz para o Dashboard */}
                  <Route path="/" element={<Navigate to="/dashboard" />} />
                  <Route path="/dashboard" element={<Dashboard />} />

                  {/* NOVO/ATUALIZADO: Rota para a página principal de cadastro do almoxarifado */}
                  <Route path="/warehouse-register/*" element={<WarehouseRegisterPage />} />

                  {/* Rota para a página principal de almoxarifado (com abas) */}
                  <Route path="/warehouse" element={<WarehousePage />} />

                  {/* Rotas para as páginas de relatórios */}
                  <Route path="/relatorios/*" element={<ReportPage />} />

                  {/* NOVO: Rotas para a gestão de usuários */}
                  <Route path="/users/management" element={<UserManagement />} />
                  <Route path="/users/account-settings" element={<AccountSettings />} />

                  {/* Adicione outras rotas protegidas que usam o Layout aqui */}
                </Route>
              </Routes>
            </BrowserRouter>
            <Toaster />
          </SocketProvider>
        </AuthProvider>
      </ErrorBoundary>
    </QueryClientProvider>
  );
}

export default App;
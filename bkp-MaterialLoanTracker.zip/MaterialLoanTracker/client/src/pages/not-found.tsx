// client/src/pages/not-found.tsx

import React from 'react';
import { Link } from 'react-router-dom'; // Importar Link para navegação

const NotFound: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-150px)] text-center"> {/* Ajuste de altura */}
      <h1 className="text-6xl font-bold text-slate-800">404</h1>
      <p className="text-xl text-slate-600 mt-4 mb-6">Página Não Encontrada</p>
      <p className="text-slate-500 mb-8">
        A página que você está procurando não existe ou foi movida.
      </p>
      <Link to="/" className="px-6 py-3 bg-primary text-white rounded-md hover:bg-blue-700 transition-colors">
        Voltar para o Dashboard
      </Link>
    </div>
  );
};

export default NotFound;
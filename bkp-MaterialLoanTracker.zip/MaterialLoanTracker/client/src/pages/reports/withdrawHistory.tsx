import React, { useState, useMemo, useEffect } from 'react';
import { useConsumables } from '@/contexts/ConsumablesContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { formatDate } from '@/lib/utils';
import { InventoryMovementFilterParams } from '@shared/schema';
import { useDebounce } from '@/hooks/useDebounce';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import WithdrawalSummary from '@/components/reports/WithdrawSummary'; // Importa o novo componente de resumo

const WithdrawHistoryPage: React.FC = () => {
  const {
    withdrawals,
    consumables,
    isLoading,
    getConsumableById,
    refreshWithdrawals,
    withdrawalsPage,
    withdrawalsPageSize,
    withdrawalsTotalPages,
    totalWithdrawals,
  } = useConsumables();

  const [rawSearchQuery, setRawSearchQuery] = useState('');
  const debouncedSearchQuery = useDebounce(rawSearchQuery, 500);
  const [currentPage, setCurrentPage] = useState(withdrawalsPage);

  // Efeito para carregar movimentações com base nos filtros e paginação
  useEffect(() => {
    const loadWithdrawals = async () => {
      await refreshWithdrawals({
        page: currentPage,
        pageSize: withdrawalsPageSize,
        search: debouncedSearchQuery,
        movementType: 'withdrawal', // Garante que só busca retiradas
      });
    };
    loadWithdrawals();
  }, [currentPage, withdrawalsPageSize, debouncedSearchQuery, refreshWithdrawals]);

  // Atualiza currentPage se o contexto mudar a página
  useEffect(() => {
    setCurrentPage(withdrawalsPage);
  }, [withdrawalsPage]);

  // A filtragem e ordenação já são feitas no backend via refreshWithdrawals
  // O useMemo abaixo é apenas para manter a estrutura, mas 'withdrawals' já virá pronto do contexto
  const filteredAndSortedWithdrawals = useMemo(() => {
    return withdrawals;
  }, [withdrawals]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Histórico de Retiradas</h2>
          <p className="text-muted-foreground">
            Veja todas as retiradas de insumos do estoque.
          </p>
        </div>
      </div>

      {/* Novo componente de resumo de retiradas */}
      <WithdrawalSummary />

      <Card>
        <CardHeader>
          <CardTitle>Filtrar Histórico</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label htmlFor="search">Buscar por nome do insumo ou observações</Label>
              <Input
                id="search"
                placeholder="Digite para buscar..."
                value={rawSearchQuery}
                onChange={(e) => setRawSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Histórico Completa</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-40">
              <div className="text-xl text-gray-600">Carregando histórico...</div>
              <div className="mt-2 w-8 h-8 border-4 border-t-4 border-blue-500 border-solid rounded-full animate-spin"></div>
            </div>
          ) : filteredAndSortedWithdrawals.length === 0 ? (
            <div className="text-center py-6 text-muted-foreground">
              Nenhuma retirada encontrada.
            </div>
          ) : (
            <div className="rounded-md border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[150px]">Item</TableHead>
                    <TableHead className="w-[150px]">Data</TableHead>
                    <TableHead>Quantidade</TableHead>
                    <TableHead>Observações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAndSortedWithdrawals.map((withdrawal) => {
                    const item = getConsumableById(withdrawal.itemId);

                    return (
                      <TableRow key={withdrawal.id}>
                        <TableCell className="font-medium">{item?.name || "Item desconhecido"}</TableCell>
                        <TableCell>{formatDate(withdrawal.date)}</TableCell>
                        <TableCell>{withdrawal.quantity}</TableCell>
                        <TableCell className="max-w-[200px] truncate text-sm text-muted-foreground">
                          {withdrawal.notes || '-'}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              {/* Controles de Paginação */}
              {totalWithdrawals > withdrawalsPageSize && (
                <div className="flex justify-between items-center p-4">
                  <Button
                    variant="outline"
                    onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="h-4 w-4 mr-2" /> Anterior
                  </Button>
                  <span>Página {currentPage} de {withdrawalsTotalPages}</span>
                  <Button
                    variant="outline"
                    onClick={() => setCurrentPage(prev => prev + 1)}
                    disabled={currentPage === withdrawalsTotalPages}
                  >
                    Próximo <ChevronRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default WithdrawHistoryPage;
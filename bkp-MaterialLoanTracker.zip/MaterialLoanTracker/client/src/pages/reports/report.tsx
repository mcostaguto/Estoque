import React, { useState } from 'react';
import { History, ScrollText } from 'lucide-react'; // Ícones para as abas
import LoanHistoryPage from '@/pages/reports/loanHistory'; // Importa a página de histórico de empréstimos
import WithdrawHistoryPage from '@/pages/reports/withdrawHistory'; // Importa a página de histórico de retiradas

const ReportPage: React.FC = () => {
  // Estado para controlar qual aba está ativa, por padrão inicia com histórico de empréstimos
  const [activeTab, setActiveTab] = useState('loanHistory');

  // Definição dos itens de navegação para as abas
  const navItems = [
    { id: 'loanHistory', label: 'Histórico de Empréstimos', icon: <History className="mr-1" size={18} /> },
    { id: 'withdrawHistory', label: 'Histórico de Retiradas', icon: <ScrollText className="mr-1" size={18} /> }
  ];

  // Função para renderizar o conteúdo da aba ativa
  const renderContent = () => {
    if (activeTab === 'loanHistory') {
      return <LoanHistoryPage />;
    } else if (activeTab === 'withdrawHistory') {
      return <WithdrawHistoryPage />;
    }
    return null;
  };

  return (
    <div className="bg-white rounded-lg shadow-sm">
      <h1 className="text-2xl font-bold p-6 pb-4">Relatórios</h1>

      {/* Navegação por abas */}
      <div className="flex space-x-2 px-6 border-b border-slate-200">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`px-4 py-2 flex items-center text-sm font-medium transition-colors ${
              activeTab === item.id
                ? 'border-b-2 border-primary text-primary' // Estilo para aba ativa
                : 'text-slate-600 hover:text-slate-900' // Estilo para aba inativa
            }`}
          >
            {item.icon}
            {item.label}
          </button>
        ))}
      </div>

      {/* Conteúdo da aba ativa */}
      <div>
        {renderContent()}
      </div>
    </div>
  );
};

export default ReportPage;
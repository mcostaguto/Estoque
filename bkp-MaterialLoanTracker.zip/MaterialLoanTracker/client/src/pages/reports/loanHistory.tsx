import React, { useState, useMemo, useEffect } from 'react';
import { useLending } from '@/contexts/LendingContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { formatDate } from '@/lib/utils';
import { Loan, Item, LoanStatusFilterParams } from '@shared/schema';
import { useDebounce } from '@/hooks/useDebounce';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import LoanSummary from '@/components/reports/LoanSummary'; // Importa o novo componente de resumo

const LoanHistoryPage: React.FC = () => {
  const {
    loans,
    items,
    people,
    isLoading,
    getItemById,
    getPersonById,
    isLoanExpired,
    refreshLoans,
    loansPage,
    loansPageSize,
    loansTotalPages,
    totalLoans,
  } = useLending();

  const [rawSearchQuery, setRawSearchQuery] = useState('');
  const debouncedSearchQuery = useDebounce(rawSearchQuery, 500);
  const [filterStatus, setFilterStatus] = useState<LoanStatusFilterParams['status']>('all');
  const [currentPage, setCurrentPage] = useState(loansPage);

  // Efeito para carregar empréstimos com base nos filtros e paginação
  useEffect(() => {
    const loadLoans = async () => {
      await refreshLoans({
        page: currentPage,
        pageSize: loansPageSize,
        search: debouncedSearchQuery,
        status: filterStatus,
      });
    };
    loadLoans();
  }, [currentPage, loansPageSize, debouncedSearchQuery, filterStatus, refreshLoans]);

  // Atualiza currentPage se o contexto mudar a página
  useEffect(() => {
    setCurrentPage(loansPage);
  }, [loansPage]);

  // A filtragem e ordenação já são feitas no backend via refreshLoans
  // O useMemo abaixo é apenas para garantir que apenas ferramentas/equipamentos são exibidos
  const filteredAndSortedLoans = useMemo(() => {
    const toolsEquipmentItemIds = new Set(items.filter((item: Item) => item.type !== 'disposable').map(item => item.id));
    return loans.filter(loan => toolsEquipmentItemIds.has(loan.itemId));
  }, [loans, items]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Histórico de Empréstimos</h2>
          <p className="text-muted-foreground">
            Veja todos os empréstimos de ferramentas e equipamentos (ativos e concluídos).
          </p>
        </div>
      </div>

      {/* Novo componente de resumo de empréstimos */}
      <LoanSummary />

      <Card>
        <CardHeader>
          <CardTitle>Filtrar Histórico</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label htmlFor="search">Buscar por item, pessoa ou observações</Label>
              <Input
                id="search"
                placeholder="Digite para buscar..."
                value={rawSearchQuery}
                onChange={(e) => setRawSearchQuery(e.target.value)}
              />
            </div>
            <div className="flex items-center gap-2">
              <Label htmlFor="status-filter" className="whitespace-nowrap">Status</Label>
              <select
                id="status-filter"
                value={filterStatus}
                onChange={(e) => {
                  setFilterStatus(e.target.value as LoanStatusFilterParams['status']);
                  setCurrentPage(1); // Resetar página ao mudar filtro
                }}
                className="px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
              >
                <option value="all">Todos</option>
                <option value="active">Ativos</option>
                <option value="overdue">Vencidos</option>
                <option value="returned">Devolvidos</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Histórico Completo</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-40">
              <div className="text-xl text-gray-600">Carregando histórico...</div>
              <div className="mt-2 w-8 h-8 border-4 border-t-4 border-blue-500 border-solid rounded-full animate-spin"></div>
            </div>
          ) : filteredAndSortedLoans.length === 0 ? (
            <div className="text-center py-6 text-muted-foreground">
              Nenhum empréstimo encontrado.
            </div>
          ) : (
            <div className="rounded-md border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[150px]">Item</TableHead>
                    <TableHead className="w-[150px]">Pessoa</TableHead>
                    <TableHead className="w-[150px]">Data Empréstimo</TableHead>
                    <TableHead className="w-[150px]">Data Prevista Devolução</TableHead>
                    <TableHead className="w-[150px]">Data Devolução</TableHead>
                    <TableHead>Observações</TableHead>
                    <TableHead className="text-right w-[100px]">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAndSortedLoans.map((loan: Loan) => {
                    const item = getItemById(loan.itemId);
                    const person = getPersonById(loan.personId);
                    const expired = isLoanExpired(loan);
                    const returned = !!loan.returnDate;

                    let statusText = "Ativo";
                    let badgeVariant: "default" | "secondary" | "destructive" | "outline" = "secondary";

                    if (returned) {
                      statusText = "Devolvido";
                      badgeVariant = "default";
                    } else if (expired) {
                      statusText = "Vencido";
                      badgeVariant = "destructive";
                    }

                    return (
                      <TableRow key={loan.id}>
                        <TableCell className="font-medium">{item?.name || "Item desconhecido"}</TableCell>
                        <TableCell>{person?.name || "Pessoa desconhecida"}</TableCell>
                        <TableCell>{formatDate(loan.loanDate)}</TableCell>
                        <TableCell className={expired && !returned ? "text-red-600 font-semibold" : ""}>
                          {(() => {
                            if (!loan.dueDate) return '-';
                            
                            try {
                              // Safe date property access
                              if (!(loan.dueDate instanceof Date) || typeof loan.dueDate.getFullYear !== 'function') {
                                console.warn('Invalid dueDate in loan history:', loan.dueDate);
                                return '-';
                              }
                              
                              const year = loan.dueDate.getFullYear();
                              const month = loan.dueDate.getMonth();
                              const date = loan.dueDate.getDate();
                              
                              // Check if it's the indefinite date (2050-12-31)
                              if (year === 2050 && month === 11 && date === 31) {
                                return 'Indefinido';
                              }
                              
                              return formatDate(loan.dueDate);
                            } catch (error) {
                              console.warn('Error processing dueDate in loan history:', loan.id, error);
                              return '-';
                            }
                          })()}
                        </TableCell>
                        <TableCell>
                          {returned ? formatDate(loan.returnDate) : '-'}
                        </TableCell>
                        <TableCell className="max-w-[200px] truncate text-sm text-muted-foreground">
                          {loan.notes || '-'}
                        </TableCell>
                        <TableCell className="text-right">
                          <Badge variant={badgeVariant}>{statusText}</Badge>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              {/* Controles de Paginação */}
              {totalLoans > loansPageSize && (
                <div className="flex justify-between items-center p-4">
                  <Button
                    variant="outline"
                    onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="h-4 w-4 mr-2" /> Anterior
                  </Button>
                  <span>Página {currentPage} de {loansTotalPages}</span>
                  <Button
                    variant="outline"
                    onClick={() => setCurrentPage(prev => prev + 1)}
                    disabled={currentPage === loansTotalPages}
                  >
                    Próximo <ChevronRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default LoanHistoryPage;
import React, { useState, useEffect } from 'react';
import { useInventory } from '@/contexts/InventoryContext'; // Usar o InventoryContext
import { useToast } from '@/hooks/use-toast';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { CardContent } from "@/components/ui/card";
import { CardHeader } from "@/components/ui/card";
import { CardTitle } from "@/components/ui/card";
import { Select } from "@/components/ui/select";
import { SelectContent } from "@/components/ui/select";
import { SelectItem } from "@/components/ui/select";
import { SelectTrigger } from "@/components/ui/select";
import { SelectValue } from "@/components/ui/select";
import { InsertItem, insertItemSchema, ItemType } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { useDebounce } from '@/hooks/useDebounce';
import { z } from 'zod'; // Importa Zod para validação local

const ItemRegister: React.FC = () => {
  const { addItem, isLoading, storagePlaces, refreshStoragePlaces } = useInventory();
  const { toast } = useToast();

  // Estados dos campos do formulário
  const [itemName, setItemName] = useState('');
  const [itemType, setItemType] = useState<ItemType>('tool');
  const [selectedStoragePlaceId, setSelectedStoragePlaceId] = useState<number | null>(null);

  // Campos específicos para 'disposable' (insumo)
  const [itemPartNumber, setItemPartNumber] = useState<string>('');
  const [itemDescription, setItemDescription] = useState<string>('');
  const [itemValue, setItemValue] = useState<string>('');
  const [itemFootprint, setItemFootprint] = useState<string>('');
  const [itemQuantity, setItemQuantity] = useState<number | null>(null);
  const [itemMinQuantity, setItemMinQuantity] = useState<number | null>(null);

  // Campos específicos para 'tool' (ferramenta)
  const [itemSize, setItemSize] = useState<string>('');

  // Campos específicos para 'equipment' (equipamento)
  const [itemManufacturer, setItemManufacturer] = useState<string>('');
  const [itemSerialNumber, setItemSerialNumber] = useState<string>('');

  // Estado para armazenar erros de validação por campo (Zod)
  const [formErrors, setFormErrors] = useState<Record<string, string | undefined>>({});

  // Debounce para o Part Number
  const debouncedPartNumber = useDebounce(itemPartNumber, 500);

  useEffect(() => {
    refreshStoragePlaces();
  }, [refreshStoragePlaces]);

  // Efeito para auto-preencher campos do insumo ao digitar o Part Number
  useEffect(() => {
    const fetchItemDetailsByPartNumber = async () => {
      if (itemType === 'disposable' && debouncedPartNumber) {
        try {
          // Endpoint: GET /api/inventory/items/details?partNumber=XYZ
          const response = await apiRequest('GET', '/api/inventory/items/details', undefined, { partNumber: debouncedPartNumber });
          const data = await response.json();

          if (data && data.description) {
            setItemDescription(data.description || '');
            setItemValue(data.value || '');
            setItemFootprint(data.footprint || '');
          } else {
            setItemDescription('');
            setItemValue('');
            setItemFootprint('');
          }
        } catch (error: any) {
          console.error('Erro ao buscar detalhes do item por Part Number:', error);
          // Opcional: toast de erro se a API falhar, mas evite em cada tecla
        }
      } else if (itemType === 'disposable' && !debouncedPartNumber) {
        setItemDescription('');
        setItemValue('');
        setItemFootprint('');
      }
    };

    fetchItemDetailsByPartNumber();
  }, [debouncedPartNumber, itemType]); // removi 'toast' das dependências para evitar loop

  const handleRegisterItem = async () => {
    setFormErrors({});

    const itemData: InsertItem = {
      name: itemName,
      type: itemType,
      storagePlaceId: selectedStoragePlaceId!,
      quantity: itemType === 'disposable' ? itemQuantity : null,
      minQuantity: itemType === 'disposable' ? itemMinQuantity : null,
      size: itemType === 'tool' ? itemSize : null,
      manufacturer: itemType === 'equipment' ? itemManufacturer : null,
      serialNumber: itemType === 'equipment' ? itemSerialNumber : null,
      partNumber: itemType === 'disposable' ? itemPartNumber : null,
      value: itemType === 'disposable' ? itemValue : null,
      footprint: itemType === 'disposable' ? itemFootprint : null,
      description: itemType === 'disposable' ? itemDescription : '', // Geral para insumos, vazio para outros
    };

    try {
      insertItemSchema.parse(itemData);
      await addItem(itemData);
      toast({
        title: "Sucesso",
        description: "Item registrado com sucesso.",
        variant: "success",
      });
      // Limpar formulário
      setItemName('');
      setItemType('tool');
      setSelectedStoragePlaceId(null);
      setItemPartNumber('');
      setItemDescription('');
      setItemValue('');
      setItemFootprint('');
      setItemQuantity(null);
      setItemMinQuantity(null);
      setItemSize('');
      setItemManufacturer('');
      setItemSerialNumber('');
      setFormErrors({});
    } catch (error: any) {
      console.error("Erro ao registrar item:", error);
      if (error instanceof z.ZodError) {
        const newErrors: Record<string, string | undefined> = {};
        error.errors.forEach((err: any) => {
          if (err.path && err.path.length > 0) {
            newErrors[err.path[0]] = err.message;
          }
        });
        setFormErrors(newErrors);
        toast({
          title: "Erro de Validação",
          description: "Por favor, corrija os campos indicados.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Erro ao registrar item",
          description: error.message || "Ocorreu um erro ao registrar o item.",
          variant: "destructive",
        });
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Registrar Novo Item</h2>
          <p className="text-muted-foreground">
            Adicione ferramentas, equipamentos ou insumos ao estoque.
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Detalhes do Item</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 py-4">
            {/* Campo Tipo */}
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="type" className="text-right">Tipo</Label>
              <Select onValueChange={(value: ItemType) => setItemType(value)} value={itemType}>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Selecione o tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="tool">Ferramenta</SelectItem>
                  <SelectItem value="equipment">Equipamento</SelectItem>
                  <SelectItem value="disposable">Insumo</SelectItem>
                </SelectContent>
              </Select>
              {formErrors.type && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.type}</p>}
            </div>

            {/* Campo Local de Armazenamento */}
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="storagePlace" className="text-right">Local Armazenamento</Label>
              <Select
                onValueChange={(value) => setSelectedStoragePlaceId(parseInt(value))}
                value={selectedStoragePlaceId?.toString() || ''}
                disabled={storagePlaces.length === 0 && !isLoading}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder={isLoading ? "Carregando locais..." : "Selecione o local"} />
                </SelectTrigger>
                <SelectContent>
                  {storagePlaces.length > 0 ? (
                    storagePlaces.map(place => (
                      <SelectItem key={place.id} value={place.id.toString()}>
                        {place.name} ({place.location})
                      </SelectItem>
                    ))
                  ) : (
                    <SelectItem value="no-places" disabled>Nenhum local cadastrado</SelectItem>
                  )}
                </SelectContent>
              </Select>
              {formErrors.storagePlaceId && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.storagePlaceId}</p>}
            </div>

            {/* Campo Nome */}
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="name" className="text-right">Nome</Label>
              <Input
                id="name"
                value={itemName}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setItemName(e.target.value)}
                className="col-span-3"
              />
              {formErrors.name && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.name}</p>}
            </div>

            {/* Campos Condicionais: Ferramenta */}
            {itemType === 'tool' && (
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="size" className="text-right">Tamanho</Label>
                <Input
                  id="size"
                  value={itemSize}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setItemSize(e.target.value)}
                  className="col-span-3"
                />
                {formErrors.size && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.size}</p>}
              </div>
            )}

            {/* Campos Condicionais: Equipamento */}
            {itemType === 'equipment' && (
              <>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="manufacturer" className="text-right">Fabricante</Label>
                  <Input
                    id="manufacturer"
                    value={itemManufacturer}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setItemManufacturer(e.target.value)}
                    className="col-span-3"
                  />
                  {formErrors.manufacturer && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.manufacturer}</p>}
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="serialNumber" className="text-right">Número de Série</Label>
                  <Input
                    id="serialNumber"
                    value={itemSerialNumber}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setItemSerialNumber(e.target.value)}
                    className="col-span-3"
                  />
                  {formErrors.serialNumber && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.serialNumber}</p>}
                </div>
              </>
            )}

            {/* Campos Condicionais: Insumo (disposable) */}
            {itemType === 'disposable' && (
              <>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="partNumber" className="text-right">Part Number</Label>
                  <Input
                    id="partNumber"
                    value={itemPartNumber}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setItemPartNumber(e.target.value)}
                    className="col-span-3"
                  />
                  {formErrors.partNumber && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.partNumber}</p>}
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="description" className="text-right">Descrição</Label>
                  <Input
                    id="description"
                    value={itemDescription}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setItemDescription(e.target.value)}
                    className="col-span-3"
                    disabled={!!debouncedPartNumber && itemDescription !== ''} // Desabilita se preenchido auto
                  />
                  {formErrors.description && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.description}</p>}
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="value" className="text-right">Valor/Especificação</Label>
                  <Input
                    id="value"
                    value={itemValue}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setItemValue(e.target.value)}
                    className="col-span-3"
                    disabled={!!debouncedPartNumber && itemValue !== ''} // Desabilita se preenchido auto
                  />
                  {formErrors.value && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.value}</p>}
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="footprint" className="text-right">Footprint</Label>
                  <Input
                    id="footprint"
                    value={itemFootprint}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setItemFootprint(e.target.value)}
                    className="col-span-3"
                    disabled={!!debouncedPartNumber && itemFootprint !== ''} // Desabilita se preenchido auto
                  />
                  {formErrors.footprint && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.footprint}</p>}
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="quantity" className="text-right">Quantidade Inicial</Label>
                  <Input
                    id="quantity"
                    type="number"
                    value={itemQuantity ?? ''}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setItemQuantity(parseInt(e.target.value) || 0)}
                    className="col-span-3"
                    min={0}
                  />
                  {formErrors.quantity && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.quantity}</p>}
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="minQuantity" className="text-right">Quantidade Mínima</Label>
                  <Input
                    id="minQuantity"
                    type="number"
                    value={itemMinQuantity ?? ''}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setItemMinQuantity(parseInt(e.target.value) || 0)}
                    className="col-span-3"
                    min={0}
                  />
                  {formErrors.minQuantity && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.minQuantity}</p>}
                </div>
              </>
            )}
            {/* Campo de descrição geral (se não for insumo, usa este) */}
            {itemType !== 'disposable' && (
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="general-description" className="text-right">Descrição</Label>
                <Input
                  id="general-description"
                  value={itemDescription} // Reutiliza o estado de descrição
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setItemDescription(e.target.value)}
                  className="col-span-3"
                />
                {formErrors.description && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.description}</p>}
              </div>
            )}
          </div>
          <Button onClick={handleRegisterItem} disabled={isLoading}>
            {isLoading ? 'Registrando...' : 'Registrar Item'}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default ItemRegister;
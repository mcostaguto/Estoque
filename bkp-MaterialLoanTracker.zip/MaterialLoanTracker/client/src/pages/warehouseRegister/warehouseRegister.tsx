import React, { useState } from 'react';
import { Package, MapPin } from 'lucide-react'; // Ícones para as abas

// Importa os componentes dos formulários que serão exibidos nas abas
import ItemRegister from './itemRegister';
import StoragePlaceRegister from './storagePlaceRegister';

const WarehouseRegisterPage: React.FC = () => {
  // Estado para controlar qual aba está ativa. Por padrão, começa com 'item'.
  const [activeTab, setActiveTab] = useState('item');

  // Define os itens de navegação para as abas, incluindo seus IDs, labels e ícones.
  const navItems = [
    { id: 'item', label: 'Cadastrar Item', icon: <Package className="mr-1" size={18} /> },
    { id: 'local', label: 'Cadastrar Local', icon: <MapPin className="mr-1" size={18} /> },
  ];

  // Função que renderiza o componente correspondente à aba ativa.
  const renderContent = () => {
    switch (activeTab) {
      case 'item':
        return <ItemRegister />;
      case 'local':
        return <StoragePlaceRegister />;
      default:
        // Caso ocorra algo inesperado, volta para o cadastro de itens como padrão.
        return <ItemRegister />;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm">
      {/* Título principal da página */}
      <h1 className="text-2xl font-bold p-6 pb-4">Gestão de Cadastros</h1>

      {/* Navegação por abas */}
      <div className="flex space-x-2 px-6 border-b border-slate-200">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            // Aplica estilos condicionalmente para destacar a aba ativa
            className={`px-4 py-2 flex items-center text-sm font-medium transition-colors ${
              activeTab === item.id
                ? 'border-b-2 border-primary text-primary' // Estilo para aba ativa
                : 'text-slate-600 hover:text-slate-900'   // Estilo para aba inativa
            }`}
          >
            {item.icon}
            {item.label}
          </button>
        ))}
      </div>

      {/* Conteúdo da aba ativa, renderizado na área principal */}
      <div className="p-6">
        {renderContent()}
      </div>
    </div>
  );
};

export default WarehouseRegisterPage;
import React, { useState } from 'react';
import { useInventory } from '@/contexts/InventoryContext'; // Para interagir com locais de armazenamento
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { CardContent } from '@/components/ui/card';
import { CardHeader } from '@/components/ui/card';
import { CardTitle } from '@/components/ui/card';
import { apiRequest } from '@/lib/queryClient';
import { InsertStoragePlacePayload } from '@shared/schema'; // Importa o schema do payload
import { z } from 'zod'; // Importa Zod para validação local

const StoragePlaceRegister: React.FC = () => {
  const { toast } = useToast();
  const { refreshStoragePlaces } = useInventory(); // Para atualizar a lista de locais

  // Estados para o formulário de Local de Armazenamento/Subárea
  const [mainLocationName, setMainLocationName] = useState(''); // Corresponde a 'name' no DB
  const [detailedLocation, setDetailedLocation] = useState(''); // Corresponde a 'location' no DB
  const [description, setDescription] = useState(''); // Corresponde a 'description' no DB
  const [isLoading, setIsLoading] = useState(false);

  const [formErrors, setFormErrors] = useState<Record<string, string | undefined>>({});

  // Schema de validação local para o formulário
  const localStoragePlaceSchema = z.object({
    name: z.string().min(1, "Nome do local principal é obrigatório."),
    location: z.string().min(1, "Subárea / Localização detalhada é obrigatória."),
    description: z.string().optional(),
  });

  // Função para cadastrar um novo Local de Armazenamento (que inclui a subárea)
  const handleRegisterStorageLocation = async () => {
    setFormErrors({});
    setIsLoading(true);

    const payload: InsertStoragePlacePayload = {
      name: mainLocationName,
      location: detailedLocation,
      description: description,
    };

    try {
      localStoragePlaceSchema.parse(payload); // Validação local antes de enviar

      // Chamada de API para cadastrar o local de armazenamento/subárea
      // Endpoint: POST /api/storage-places
      await apiRequest('POST', '/api/storage-places', payload);

      toast({
        title: "Sucesso",
        description: "Local de armazenamento / Subárea cadastrado com sucesso!",
        variant: "success",
      });
      // Limpa o formulário
      setMainLocationName('');
      setDetailedLocation('');
      setDescription('');

      refreshStoragePlaces(); // Atualiza a lista de locais no contexto

    } catch (error: any) {
      console.error('Erro ao cadastrar local de armazenamento:', error);
      if (error instanceof z.ZodError) {
        const newErrors: Record<string, string | undefined> = {};
        error.errors.forEach((err: any) => {
          if (err.path && err.path.length > 0) {
            newErrors[err.path[0]] = err.message;
          }
        });
        setFormErrors(newErrors);
        toast({
          title: "Erro de Validação",
          description: "Por favor, corrija os campos indicados.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Erro ao cadastrar local",
          description: error.message || "Ocorreu um erro ao cadastrar o local.",
          variant: "destructive",
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Cadastrar Local de Armazenamento</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 py-4">
            {/* Campo: Nome do Local Principal */}
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="main-location-name" className="text-right">Nome do Local Principal</Label>
              <Input
                id="main-location-name"
                value={mainLocationName}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setMainLocationName(e.target.value)}
                className="col-span-3"
              />
              {formErrors.name && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.name}</p>}
            </div>

            {/* Campo: Subárea / Localização Detalhada */}
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="detailed-location" className="text-right">Subárea / Localização Detalhada</Label>
              <Input
                id="detailed-location"
                value={detailedLocation}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setDetailedLocation(e.target.value)}
                className="col-span-3"
              />
              {formErrors.location && <p className="col-span-4 text-right text-red-500 text-sm">{formErrors.location}</p>}
            </div>

            {/* Campo: Descrição (Opcional) */}
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="description" className="text-right">Descrição (Opcional)</Label>
              <Input
                id="description"
                value={description}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setDescription(e.target.value)}
                className="col-span-3"
              />
            </div>
          </div>
          <Button onClick={handleRegisterStorageLocation} disabled={isLoading}>
            {isLoading ? 'Cadastrando...' : 'Cadastrar Local'}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default StoragePlaceRegister;
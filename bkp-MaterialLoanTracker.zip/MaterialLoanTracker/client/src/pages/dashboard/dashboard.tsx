import React, { useMemo, useEffect } from 'react';
import { useLending } from '@/contexts/LendingContext';
import { useConsumables } from '@/contexts/ConsumablesContext'; // Importa o contexto de insumos
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Item } from '@shared/schema';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { formatDate } from '@/lib/utils';

const Dashboard: React.FC = () => {
  const {
    isLoading: isLoadingLending, // Renomeia para evitar conflito com isLoadingConsumables
    loans, // Adicionado para acesso direto aos loans para contagem de atrasados
    items,
    people, // Adicionado para acesso direto às pessoas
    getActiveLoansCount,
    getExpiredLoansCount,
    getRecentLoans,
    getPopularItems,
    getItemById,
    getPersonById,
    isLoanExpired,
  } = useLending();

  // Add comprehensive error handling for getTime errors in dashboard
  useEffect(() => {
    const handleError = (event: ErrorEvent) => {
      if (event.message && event.message.includes('getTime is not a function')) {
        console.error('🚨 CAUGHT getTime ERROR in Dashboard:', {
          message: event.message,
          filename: event.filename,
          lineno: event.lineno,
          colno: event.colno,
          error: event.error,
          stack: event.error?.stack,
          currentLoans: loans.map(loan => ({
            id: loan.id,
            loanDate: { value: loan.loanDate, type: typeof loan.loanDate, isDate: loan.loanDate instanceof Date },
            dueDate: { value: loan.dueDate, type: typeof loan.dueDate, isDate: loan.dueDate instanceof Date },
            returnDate: { value: loan.returnDate, type: typeof loan.returnDate, isDate: loan.returnDate instanceof Date }
          }))
        });
        
        // Prevent the error from propagating
        event.preventDefault();
        return true;
      }
      return false;
    };

    window.addEventListener('error', handleError);
    return () => window.removeEventListener('error', handleError);
  }, [loans]);

  // Use the centralized safe date formatter
  const safeFormatDate = formatDate;

  const {
    consumables,
    isLoading: isLoadingConsumables, // Renomeia para evitar conflito com isLoadingLending
  } = useConsumables();

  console.log('Dados brutos dos empréstimos:', loans);

  // Calcula insumos com estoque abaixo do mínimo
  const lowStockConsumables = useMemo(() =>
    consumables.filter(item =>
      item.type === 'disposable' &&
      (item.quantity !== null && item.minQuantity !== null) && // Garante que não são nulos
      (item.quantity || 0) <= (item.minQuantity || 0) &&
      (item.quantity || 0) > 0 // Considera apenas itens com estoque > 0 mas abaixo do mínimo
    ),
    [consumables]
  );

  console.log('Dados brutos dos empréstimos:', loans);

  // Contadores para os cards
  const activeLoansCount = getActiveLoansCount();
  const expiredLoansCount = getExpiredLoansCount();
  const lowStockConsumablesCount = lowStockConsumables.length;

  console.log('Dados brutos dos empréstimos:', loans);
  // Empréstimos recentes (últimas 5 operações)
  const recentLoans = useMemo(() => getRecentLoans(5), [getRecentLoans]);

  // Itens mais populares (ferramentas/equipamentos)
  const popularLendingItems = useMemo(() => getPopularItems(5).filter(data => data.item.type !== 'disposable'), [getPopularItems]);

  // Verifica se algum dos contextos ainda está carregando
  if (isLoadingLending || isLoadingConsumables) {
    return <div className="flex justify-center items-center h-40">Carregando dashboard...</div>;
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold tracking-tight">Dashboard</h2>
      <p className="text-muted-foreground">
        Visão geral das informações mais importantes do almoxarifado.
      </p>

      {/* Cards de Resumo */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Empréstimos Ativos</CardTitle>
            <i className="ri-hand-coin-line text-2xl text-muted-foreground"></i>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeLoansCount}</div>
            <p className="text-xs text-muted-foreground">
              Ferramentas e equipamentos atualmente emprestados.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Empréstimos Atrasados</CardTitle>
            <i className="ri-calendar-todo-line text-2xl text-muted-foreground"></i>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{expiredLoansCount}</div>
            <p className="text-xs text-muted-foreground">
              Itens com devolução pendente e prazo vencido.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Insumos com Estoque Baixo</CardTitle>
            <i className="ri-alert-line text-2xl text-muted-foreground"></i>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-500">{lowStockConsumablesCount}</div>
            <p className="text-xs text-muted-foreground">
              Insumos abaixo da quantidade mínima definida.
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {/* Card de Empréstimos Recentes */}
        <Card>
          <CardHeader>
            <CardTitle>Últimas Operações de Empréstimo</CardTitle>
          </CardHeader>
          <CardContent>
            {recentLoans.length === 0 ? (
              <div className="text-center py-4 text-muted-foreground">
                Nenhuma operação de empréstimo recente.
              </div>
            ) : (
              <div className="rounded-md border overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Item</TableHead>
                      <TableHead>Pessoa</TableHead>
                      <TableHead>Data Empréstimo</TableHead>
                      <TableHead className="text-right w-[100px]">Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentLoans.map((loan) => {
                      const item = getItemById(loan.itemId);
                      const person = getPersonById(loan.personId);
                      const expired = isLoanExpired(loan);
                      const returned = !!loan.returnDate;

                      let statusText = "Ativo";
                      let badgeVariant: "default" | "secondary" | "destructive" | "outline" = "secondary";

                      if (returned) {
                        statusText = "Devolvido";
                        badgeVariant = "default";
                      } else if (expired) {
                        statusText = "Vencido";
                        badgeVariant = "destructive";
                      }

                      return (
                        <TableRow key={loan.id}>
                          <TableCell className="font-medium">{item?.name || "Item desconhecido"}</TableCell>
                          <TableCell>
                            {/* Correção do erro: Verificar se personId não é null antes de chamar getPersonById */}
                            {loan.personId !== null ? getPersonById(loan.personId)?.name || "Pessoa desconhecida" : "Pessoa desconhecida"}
                          </TableCell>
                          <TableCell>{safeFormatDate(loan.loanDate)}</TableCell>
                          <TableCell className="text-right">
                            <Badge variant={badgeVariant}>{statusText}</Badge>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Card de Itens Populares */}
        <Card>
          <CardHeader>
            <CardTitle>Itens Populares (Empréstimo)</CardTitle>
          </CardHeader>
          <CardContent>
            {popularLendingItems.length === 0 ? (
              <div className="text-center py-4 text-muted-foreground">
                Nenhum item popular ainda.
              </div>
            ) : (
              <div className="rounded-md border overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Item</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead className="text-right w-[100px]">Empréstimos</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {popularLendingItems.map(({ item, count }) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {item.type === 'tool' ? 'Ferramenta' : 'Equipamento'}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right font-bold">
                          {count}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
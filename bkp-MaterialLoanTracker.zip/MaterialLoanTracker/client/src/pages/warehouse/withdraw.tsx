import React, { useState, useMemo, useEffect } from 'react';
import { useConsumables } from '@/contexts/ConsumablesContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Item } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { useDebounce } from '@/hooks/useDebounce';
import { ChevronLeft, ChevronRight } from 'lucide-react';

type ConsumableItem = Item;

const WithdrawPage: React.FC = () => {
  const {
    consumables,
    isLoading,
    withdrawItem,
    refreshConsumables,
    consumablesPage,
    consumablesPageSize,
    consumablesTotalPages,
    totalConsumables,
  } = useConsumables();
  const { user } = useAuth();
  const { toast } = useToast();

  const [rawSearchQuery, setRawSearchQuery] = useState('');
  const debouncedSearchQuery = useDebounce(rawSearchQuery, 500);
  const [currentPage, setCurrentPage] = useState(consumablesPage);

  const [isWithdrawDialogOpen, setIsWithdrawDialogOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<ConsumableItem | null>(null);
  const [withdrawQuantity, setWithdrawQuantity] = useState<number>(1);
  const [withdrawNotes, setWithdrawNotes] = useState('');

  // Efeito para carregar insumos com base nos filtros e paginação
  useEffect(() => {
    const loadConsumables = async () => {
      await refreshConsumables({
        page: currentPage,
        pageSize: consumablesPageSize,
        search: debouncedSearchQuery,
      });
    };
    loadConsumables();
  }, [currentPage, consumablesPageSize, debouncedSearchQuery, refreshConsumables]);

  // Atualiza currentPage se o contexto mudar a página
  useEffect(() => {
    setCurrentPage(consumablesPage);
  }, [consumablesPage]);

  const filteredConsumables = useMemo(() => {
    // A filtragem por search já é feita no backend via refreshConsumables
    // Aqui, apenas usamos os 'consumables' que já vieram filtrados e paginados
    return consumables;
  }, [consumables]);

  const handleWithdrawClick = () => {
    setSelectedItem(null);
    setWithdrawQuantity(1);
    setWithdrawNotes('');
    setIsWithdrawDialogOpen(true);
  };

  const handleConfirmWithdraw = async () => {
    if (!selectedItem || withdrawQuantity <= 0) {
      toast({
        title: "Erro",
        description: "Selecione um item e uma quantidade válida para retirar.",
        variant: "destructive",
      });
      return;
    }

    if (selectedItem.quantity !== null && withdrawQuantity > selectedItem.quantity) {
        toast({
            title: "Erro",
            description: `Quantidade solicitada (${withdrawQuantity}) excede o estoque disponível (${selectedItem.quantity}).`,
            variant: "destructive",
        });
        return;
    }

    try {
      await withdrawItem(selectedItem.id, withdrawQuantity, withdrawNotes);
      setIsWithdrawDialogOpen(false);
      // O refreshConsumables já é chamado dentro de withdrawItem
    } catch (error: any) {
      console.error("Erro ao confirmar retirada:", error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Retirada de Insumos</h2>
          <p className="text-muted-foreground">
            Gerencie a retirada de insumos do estoque.
          </p>
        </div>
        <Button onClick={handleWithdrawClick}>
          <i className="ri-add-line mr-1"></i> Registrar Retirada
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filtrar Insumos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <Label htmlFor="search">Buscar por nome do insumo</Label>
              <Input
                id="search"
                placeholder="Digite para buscar..."
                value={rawSearchQuery}
                onChange={(e) => setRawSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Insumos Disponíveis</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-40">
              <div className="text-xl text-gray-600">Carregando insumos...</div>
              <div className="mt-2 w-8 h-8 border-4 border-t-4 border-blue-500 border-solid rounded-full animate-spin"></div>
            </div>
          ) : filteredConsumables.length === 0 ? (
            <div className="text-center py-6 text-muted-foreground">
              Nenhum insumo encontrado.
            </div>
          ) : (
            <div className="rounded-md border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Item</TableHead>
                    <TableHead>Quantidade</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredConsumables.map((item: ConsumableItem) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell>{item.quantity}</TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedItem(item);
                            setIsWithdrawDialogOpen(true);
                          }}
                        >
                          Retirar
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {/* Controles de Paginação */}
              {totalConsumables > consumablesPageSize && ( // Só mostra a paginação se houver mais itens que o pageSize
                <div className="flex justify-between items-center p-4">
                  <Button
                    variant="outline"
                    onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="h-4 w-4 mr-2" /> Anterior
                  </Button>
                  <span>Página {currentPage} de {consumablesTotalPages}</span>
                  <Button
                    variant="outline"
                    onClick={() => setCurrentPage(prev => prev + 1)}
                    disabled={currentPage === consumablesTotalPages}
                  >
                    Próximo <ChevronRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isWithdrawDialogOpen} onOpenChange={setIsWithdrawDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Registrar Retirada de Insumo</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="item" className="text-right">
                Item
              </Label>
              <Select
                onValueChange={(value) => setSelectedItem(consumables.find(item => item.id === parseInt(value)) || null)}
                value={selectedItem?.id?.toString() || ''}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Selecione o item" />
                </SelectTrigger>
                <SelectContent>
                  {consumables.map(item => (
                    <SelectItem key={item.id} value={item.id.toString()}>
                      {item.name} (Estoque: {item.quantity})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="quantity" className="text-right">
                Quantidade
              </Label>
              <Input
                id="quantity"
                type="number"
                value={withdrawQuantity}
                onChange={(e) => setWithdrawQuantity(parseInt(e.target.value) || 0)}
                className="col-span-3"
                min={1}
                max={selectedItem?.quantity ?? undefined}
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="notes" className="text-right">
                Observações
              </Label>
              <Input
                id="notes"
                value={withdrawNotes}
                onChange={(e) => setWithdrawNotes(e.target.value)}
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsWithdrawDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleConfirmWithdraw} disabled={!selectedItem || withdrawQuantity <= 0 || (selectedItem.quantity !== null && withdrawQuantity > selectedItem.quantity)}>
              Confirmar Retirada
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default WithdrawPage;
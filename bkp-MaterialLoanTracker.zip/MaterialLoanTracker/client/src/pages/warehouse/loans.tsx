import React, { useState, useMemo, useEffect } from 'react';
import { useLending } from '@/contexts/LendingContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { CalendarIcon, Search, ChevronLeft, ChevronRight } from 'lucide-react';
import { Loan, Item, Person, InsertLoan, LoanStatusFilterParams } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { cn, formatDate, safeDateMethod, hasValidDateProperty } from '@/lib/utils';
import { Checkbox } from '@/components/ui/checkbox';
import { useDebounce } from '@/hooks/useDebounce';

const LoansPage: React.FC = () => {
  const {
    loans,
    items,
    people,
    isLoading,
    getAvailableItems,
    createLoan,
    returnItem,
    getItemById,
    getPersonById,
    isLoanExpired,
    refreshLoans,
    loansPage,       // Do contexto
    loansPageSize,    // Do contexto
    loansTotalPages,  // Do contexto
    totalLoans,       // Do contexto
  } = useLending();

  // Track any date access in this component
  useEffect(() => {
    console.log('📍 LoansPage: Checking loans for date issues:', loans.map(loan => ({
      id: loan.id,
      loanDate: { value: loan.loanDate, type: typeof loan.loanDate, isDate: loan.loanDate instanceof Date },
      dueDate: { value: loan.dueDate, type: typeof loan.dueDate, isDate: loan.dueDate instanceof Date }
    })));
  }, [loans]);

  // Add comprehensive error handling for getTime errors
  useEffect(() => {
    const handleError = (event: ErrorEvent) => {
      if (event.message && event.message.includes('getTime is not a function')) {
        console.error('🚨 CAUGHT getTime ERROR in LoansPage:', {
          message: event.message,
          filename: event.filename,
          lineno: event.lineno,
          colno: event.colno,
          error: event.error,
          stack: event.error?.stack,
          currentLoans: loans.map(loan => ({
            id: loan.id,
            loanDate: { value: loan.loanDate, type: typeof loan.loanDate, isDate: loan.loanDate instanceof Date },
            dueDate: { value: loan.dueDate, type: typeof loan.dueDate, isDate: loan.dueDate instanceof Date },
            returnDate: { value: loan.returnDate, type: typeof loan.returnDate, isDate: loan.returnDate instanceof Date }
          }))
        });
        
        // Prevent the error from propagating
        event.preventDefault();
        return true;
      }
      return false;
    };

    window.addEventListener('error', handleError);
    return () => window.removeEventListener('error', handleError);
  }, [loans]);
  const { user } = useAuth();

  const { toast } = useToast();

  const [rawSearchQuery, setRawSearchQuery] = useState('');
  const debouncedSearchQuery = useDebounce(rawSearchQuery, 500);
  const [filterStatus, setFilterStatus] = useState<LoanStatusFilterParams['status']>('active');
  const [currentPage, setCurrentPage] = useState(loansPage); // Usar o estado da página do contexto

  const [isNewLoanDialogOpen, setIsNewLoanDialogOpen] = useState(false);
  const [selectedItemForLoan, setSelectedItemForLoan] = useState<Item | null>(null);
  const [selectedPersonForLoan, setSelectedPersonForLoan] = useState<Person | null>(null);
  const [dueDate, setDueDate] = useState<Date | undefined>(undefined);
  const [loanNotes, setLoanNotes] = useState('');
  const [isIndefiniteLoan, setIsIndefiniteLoan] = useState(false);

  // Efeito para carregar empréstimos com base nos filtros e paginação
  useEffect(() => {
    const loadLoans = async () => {
      await refreshLoans({
        page: currentPage,
        pageSize: loansPageSize, // Usar o pageSize do contexto
        search: debouncedSearchQuery,
        status: filterStatus,
      });
    };
    loadLoans();
  }, [currentPage, loansPageSize, debouncedSearchQuery, filterStatus, refreshLoans]);

  // Atualiza currentPage se o contexto mudar a página (ex: ao recarregar dados)
  useEffect(() => {
    setCurrentPage(loansPage);
  }, [loansPage]);

  const availableToolsAndEquipment = useMemo(() => getAvailableItems().filter((item: Item) => item.type !== 'disposable'), [getAvailableItems]);
  const allPeople = useMemo(() => people, [people]);

  const handleNewLoanClick = () => {
    setSelectedItemForLoan(null);
    setSelectedPersonForLoan(null);
    setDueDate(undefined);
    setLoanNotes('');
    setIsIndefiniteLoan(false);
    setIsNewLoanDialogOpen(true);
  };

  const handleConfirmNewLoan = async () => {
    if (!selectedItemForLoan || !selectedPersonForLoan) {
      toast({
        title: "Erro",
        description: "Selecione um item e uma pessoa para registrar o empréstimo.",
        variant: "destructive",
      });
      return;
    }

    let finalDueDate: Date | null = null;
    if (isIndefiniteLoan) {
      finalDueDate = new Date('2050-12-31T00:00:00Z');
    } else if (dueDate) {
      finalDueDate = dueDate;
    } else {
      toast({
        title: "Erro",
        description: "Selecione uma data de devolução ou marque 'Empréstimo Indefinido'.",
        variant: "destructive",
      });
      return;
    }

    const loanData: InsertLoan = {
      itemId: selectedItemForLoan.id,
      personId: selectedPersonForLoan.id,
      loanDate: new Date(),
      dueDate: finalDueDate,
      notes: loanNotes || null,
    };

    try {
      await createLoan(loanData);
      setIsNewLoanDialogOpen(false);
      toast({
        title: "Sucesso",
        description: "Empréstimo registrado com sucesso!",
        variant: "success",
      });
      // O refreshLoans já é chamado dentro de createLoan
    } catch (error: any) {
      console.error("Error confirming new loan:", error);
      toast({
        title: "Erro ao registrar empréstimo",
        description: error.message || "Ocorreu um erro ao registrar o empréstimo.",
        variant: "destructive",
      });
    }
  };

  const handleReturnItem = async (loanId: number) => {
    try {
      await returnItem(loanId);
      toast({
        title: "Sucesso",
        description: "Empréstimo devolvido com sucesso!",
        variant: "success",
      });
      // O returnItem já chama refreshLoans
    } catch (error: any) {
      console.error("Error returning item:", error);
      toast({
        title: "Erro ao devolver empréstimo",
        description: error.message || "Ocorreu um erro ao devolver o empréstimo.",
        variant: "destructive",
      });
    }
  };

  // Use centralized safe utilities
  const safeFormatDate = formatDate;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Controle de Empréstimos</h2>
          <p className="text-muted-foreground">
            Gerencie empréstimos e devoluções de ferramentas e equipamentos.
          </p>
        </div>
        <Button onClick={handleNewLoanClick}>
          <i className="ri-add-line mr-1"></i> Registrar Novo Empréstimo
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filtrar Empréstimos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row md:items-center gap-4">
            <div className="flex-1 flex items-center gap-2">
              <Search className="w-5 h-5 text-muted-foreground" />
              <Input
                id="search"
                placeholder="Buscar por item, pessoa ou observações..."
                value={rawSearchQuery}
                onChange={(e) => setRawSearchQuery(e.target.value)}
                className="w-full md:w-[300px]"
              />
            </div>

            <div className="flex items-center gap-2">
              <Label htmlFor="status-filter" className="whitespace-nowrap">Status</Label>
              <select
                id="status-filter"
                value={filterStatus}
                onChange={(e) => {
                  setFilterStatus(e.target.value as LoanStatusFilterParams['status']);
                  setCurrentPage(1); // Resetar página ao mudar filtro
                }}
                className="px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary"
              >
                <option value="all">Todos</option>
                <option value="active">Ativos</option>
                <option value="overdue">Vencidos</option>
                <option value="returned">Devolvidos</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Empréstimos</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-40">
              <div className="text-xl text-gray-600">Carregando empréstimos...</div>
              <div className="mt-2 w-8 h-8 border-4 border-t-4 border-blue-500 border-solid rounded-full animate-spin"></div>
            </div>
          ) : loans.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              Nenhum empréstimo encontrado com os filtros aplicados.
            </div>
          ) : (
            <div className="rounded-md border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[150px]">Item</TableHead>
                    <TableHead className="w-[150px]">Pessoa</TableHead>
                    <TableHead className="w-[150px]">Data Empréstimo</TableHead>
                    <TableHead className="w-[150px]">Data Prevista Devolução</TableHead>
                    <TableHead className="w-[150px]">Data Devolução</TableHead>
                    <TableHead>Observações</TableHead>
                    <TableHead className="text-right w-[100px]">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {loans.map((loan: Loan) => {
                    const item = getItemById(loan.itemId);
                    const person = getPersonById(loan.personId);
                    const expired = isLoanExpired(loan);

                    return (
                      <TableRow key={loan.id}>
                        <TableCell className="font-medium">{item?.name || "Item desconhecido"}</TableCell>
                        <TableCell>{person?.name || "Pessoa desconhecida"}</TableCell>
                        <TableCell>{safeFormatDate(loan.loanDate)}</TableCell>
                        <TableCell className={cn(expired && !loan.returnDate && "text-red-600 font-semibold")}>
                          {(() => {
                            if (!loan.dueDate) return '-';
                            
                            try {
                              // Use safe accessor for all date methods
                              const year = safeDateMethod(loan, 'dueDate', 'getFullYear');
                              const month = safeDateMethod(loan, 'dueDate', 'getMonth');
                              const date = safeDateMethod(loan, 'dueDate', 'getDate');
                              
                              if (year === null || month === null || date === null) {
                                console.warn('❌ Could not safely access dueDate properties for loan', loan.id);
                                return '-';
                              }
                              
                              // Check if it's the indefinite date (2050-12-31)
                              if (year === 2050 && month === 11 && date === 31) {
                                return 'Indefinido';
                              }
                              
                              return safeFormatDate(loan.dueDate);
                            } catch (error) {
                              console.warn('Error processing dueDate for loan', loan.id, error);
                              return '-';
                            }
                          })()}
                        </TableCell>
                        <TableCell>
                          {loan.returnDate ? safeFormatDate(loan.returnDate) : '-'}
                        </TableCell>
                        <TableCell className="max-w-[200px] truncate text-sm text-muted-foreground">
                          {loan.notes || '-'}
                        </TableCell>
                        <TableCell className="text-right">
                          {!loan.returnDate && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleReturnItem(loan.id)}
                            >
                              Devolver
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              {/* Controles de Paginação */}
              {totalLoans > loansPageSize && ( // Só mostra a paginação se houver mais itens que o pageSize
                <div className="flex justify-between items-center p-4">
                  <Button
                    variant="outline"
                    onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="h-4 w-4 mr-2" /> Anterior
                  </Button>
                  <span>Página {currentPage} de {loansTotalPages}</span>
                  <Button
                    variant="outline"
                    onClick={() => setCurrentPage(prev => prev + 1)}
                    disabled={currentPage === loansTotalPages}
                  >
                    Próximo <ChevronRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isNewLoanDialogOpen} onOpenChange={setIsNewLoanDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Registrar Novo Empréstimo</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="item" className="text-right">
                Item
              </Label>
              <Select onValueChange={(value) => setSelectedItemForLoan(items.find((item: Item) => item.id === parseInt(value)) || null)}>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Selecione o item" />
                </SelectTrigger>
                <SelectContent>
                  {availableToolsAndEquipment.map((item: Item) => (
                    <SelectItem key={item.id} value={item.id.toString()}>
                      {item.name} ({item.type === 'tool' ? 'Ferramenta' : 'Equipamento'})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="person" className="text-right">
                Pessoa
              </Label>
              <Select onValueChange={(value) => setSelectedPersonForLoan(people.find((person: Person) => person.id === parseInt(value)) || null)}>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Selecione a pessoa" />
                </SelectTrigger>
                <SelectContent>
                  {allPeople.map((person: Person) => (
                    <SelectItem key={person.id} value={person.id.toString()}>
                      {person.name} ({person.team})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* NOVO: Checkbox para Empréstimo Indefinido */}
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="indefiniteLoan" className="text-right">
                Empréstimo Indefinido
              </Label>
              <div className="col-span-3 flex items-center">
                <Checkbox
                  id="indefiniteLoan"
                  checked={isIndefiniteLoan}
                  onCheckedChange={(checkedState) => {
                    if (typeof checkedState === 'boolean') {
                      setIsIndefiniteLoan(checkedState);
                      if (checkedState) {
                        setDueDate(undefined);
                      }
                    }
                  }}
                />
                <span className="ml-2 text-sm text-muted-foreground">Sem data de devolução prevista</span>
              </div>
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="dueDate" className="text-right">
                Devolução Prevista
              </Label>
              <div className="col-span-3">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-[240px] justify-start text-left font-normal",
                        !dueDate && "text-muted-foreground"
                      )}
                      disabled={isIndefiniteLoan}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dueDate ? format(new Date(dueDate), "dd/MM/yyyy", { locale: ptBR }) : <span>Selecione uma data</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <Calendar
                      mode="single"
                      selected={dueDate}
                      onSelect={setDueDate}
                      initialFocus
                      locale={ptBR}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="notes" className="text-right">
                Observações
              </Label>
              <Input
                id="notes"
                value={loanNotes}
                onChange={(e) => setLoanNotes(e.target.value)}
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsNewLoanDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleConfirmNewLoan} disabled={!selectedItemForLoan || !selectedPersonForLoan || (!isIndefiniteLoan && !dueDate)}>
              Registrar Empréstimo
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default LoansPage;
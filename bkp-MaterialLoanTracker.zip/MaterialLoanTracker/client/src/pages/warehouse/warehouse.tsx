import React, { useState } from 'react';
import { ArrowRightLeft, PackageOpen } from 'lucide-react';
import LoansPage from '@/pages/warehouse/loans';
import WithdrawPage from '@/pages/warehouse/withdraw';

const WarehousePage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('loans');

  const navItems = [
    { id: 'loans', label: 'Empréstimo', icon: <ArrowRightLeft className="mr-1" size={18} /> },
    { id: 'withdraw', label: 'Retirada', icon: <PackageOpen className="mr-1" size={18} /> }
  ];

  const renderContent = () => {
    if (activeTab === 'withdraw') {
      return <WithdrawPage />;
    } else if (activeTab === 'loans') {
      return <LoansPage />;
    }
    return null;
  };

  return (
    <div className="bg-white rounded-lg shadow-sm">
      <h1 className="text-2xl font-bold p-6 pb-4">Almoxarifado</h1>

      <div className="flex space-x-2 px-6 border-b border-slate-200">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`px-4 py-2 flex items-center text-sm font-medium transition-colors ${
              activeTab === item.id
                ? 'border-b-2 border-primary text-primary'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {item.icon}
            {item.label}
          </button>
        ))}
      </div>

      <div>
        {renderContent()}
      </div>
    </div>
  );
};

export default WarehousePage;
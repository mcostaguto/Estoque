import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from '@/components/ui/table';
import { apiRequest } from '@/lib/queryClient';
import { paginatedResponseSchema, appUserSchema, PaginationParams, SearchFilterParams } from '@shared/schema';
import { z } from 'zod';
import { format } from 'date-fns'; // Para formatar datas
import { Pencil, Trash2, UserPlus, Search } from 'lucide-react'; // Ícones
import { Input } from '@/components/ui/input';

// Tipo de resposta paginada para usuários
const paginatedUserSchema = paginatedResponseSchema(appUserSchema);
type PaginatedUsersResponse = z.infer<typeof paginatedUserSchema>;

const UserManagement: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [users, setUsers] = useState<z.infer<typeof appUserSchema>[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [totalUsers, setTotalUsers] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');

  const fetchUsers = async () => {
    if (!user || user.type !== 'admin') {
      setError('Acesso negado. Apenas administradores podem gerenciar usuários.');
      setIsLoading(false);
      toast({
        title: "Acesso Negado",
        description: "Você não tem permissão para acessar esta página.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    setError(null);
    try {
      const response = await apiRequest('GET', '/api/users', undefined, { page, pageSize, search: searchQuery });
      const data: PaginatedUsersResponse = await response.json();
      paginatedUserSchema.parse(data); // Valida a resposta

      // Converte as strings de data para objetos Date
      const parsedUsers = data.data.map(u => ({
        ...u,
        createdAt: new Date(u.createdAt),
        updatedAt: new Date(u.updatedAt),
        lastLogin: u.lastLogin ? new Date(u.lastLogin) : null,
      }));

      setUsers(parsedUsers);
      setTotalUsers(data.total);
      setTotalPages(data.totalPages);

    } catch (err: any) {
      console.error('Erro ao buscar usuários:', err);
      setError(err.message || 'Falha ao carregar usuários.');
      toast({
        title: "Erro ao Carregar Usuários",
        description: err.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, [page, pageSize, searchQuery, user]); // Refetch quando página, tamanho ou busca muda

  const handleCreateUser = () => {
    // TODO: Abrir um modal/formulário para criação de novo usuário
    toast({ title: "Funcionalidade em desenvolvimento", description: "Formulário de criação de usuário será implementado aqui." });
  };

  const handleEditUser = (userId: number) => {
    // TODO: Abrir um modal/formulário para edição de usuário
    toast({ title: "Funcionalidade em desenvolvimento", description: `Editar usuário ${userId}.` });
  };

  const handleDeleteUser = async (userId: number) => {
    if (!window.confirm(`Tem certeza que deseja deletar o usuário ID ${userId}?`)) {
      return;
    }
    try {
      await apiRequest('DELETE', `/api/users/${userId}`);
      toast({ title: "Sucesso", description: "Usuário deletado com sucesso.", variant: "success" });
      fetchUsers(); // Recarregar lista
    } catch (err: any) {
      console.error('Erro ao deletar usuário:', err);
      toast({ title: "Erro ao Deletar Usuário", description: err.message, variant: "destructive" });
    }
  };

  if (isLoading) {
    return <div className="flex justify-center items-center h-40">Carregando usuários...</div>;
  }

  if (error) {
    return <div className="text-red-500 text-center py-8">{error}</div>;
  }

  if (!user || user.type !== 'admin') {
    return <div className="text-red-500 text-center py-8">Você não tem permissão para visualizar esta página.</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Gestão de Usuários</h2>
          <p className="text-muted-foreground">
            Gerencie todos os usuários do sistema.
          </p>
        </div>
        <Button onClick={handleCreateUser}>
          <UserPlus className="mr-2 h-4 w-4" /> Criar Novo Usuário
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lista de Usuários</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2 mb-4">
            <Search className="w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Buscar por nome, usuário ou email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="max-w-sm"
            />
          </div>

          {users.length === 0 ? (
            <div className="text-center py-6 text-muted-foreground">
              Nenhum usuário encontrado.
            </div>
          ) : (
            <div className="rounded-md border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Usuário</TableHead>
                    <TableHead>Nome</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Equipe</TableHead>
                    <TableHead>Ativo</TableHead>
                    <TableHead>Último Login</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((u) => (
                    <TableRow key={u.userId}>
                      <TableCell>{u.userId}</TableCell>
                      <TableCell>{u.username}</TableCell>
                      <TableCell>{u.name}</TableCell>
                      <TableCell>{u.email}</TableCell>
                      <TableCell>{u.type}</TableCell>
                      <TableCell>{u.equipe}</TableCell>
                      <TableCell>{u.isActive ? 'Sim' : 'Não'}</TableCell>
                      <TableCell>{u.lastLogin ? format(new Date(u.lastLogin), 'dd/MM/yyyy HH:mm') : '-'}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" onClick={() => handleEditUser(u.userId)} className="mr-2">
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button variant="destructive" size="sm" onClick={() => handleDeleteUser(u.userId)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              {/* Paginação */}
              {totalPages > 1 && (
                <div className="flex justify-between items-center p-4">
                  <Button
                    variant="outline"
                    onClick={() => setPage(prev => Math.max(1, prev - 1))}
                    disabled={page === 1}
                  >
                    Anterior
                  </Button>
                  <span>Página {page} de {totalPages}</span>
                  <Button
                    variant="outline"
                    onClick={() => setPage(prev => prev + 1)}
                    disabled={page === totalPages}
                  >
                    Próxima
                  </Button>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default UserManagement;
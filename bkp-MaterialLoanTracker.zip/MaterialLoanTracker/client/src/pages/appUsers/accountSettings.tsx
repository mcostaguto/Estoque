import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiRequest } from '@/lib/queryClient';
import { z } from 'zod';
import { registerUserSchema } from '@shared/schema';

// Schema para validação dos dados de perfil
const profileUpdateSchema = registerUserSchema.partial().pick({ name: true, email: true, equipe: true });
type ProfileUpdatePayload = z.infer<typeof profileUpdateSchema>;

const AccountSettings: React.FC = () => {
  const { user, refreshUserData, logout } = useAuth(); // Adicionado refreshUserData e logout
  const { toast } = useToast();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [equipe, setEquipe] = useState('');
  const [currentPassword, setCurrentPassword] = useState(''); // NOVO: Senha atual
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [isLoadingProfileUpdate, setIsLoadingProfileUpdate] = useState(false);
  const [isLoadingPasswordChange, setIsLoadingPasswordChange] = useState(false);

  const [profileErrors, setProfileErrors] = useState<Record<string, string | undefined>>({});
  const [passwordErrors, setPasswordErrors] = useState<Record<string, string | undefined>>({});

  useEffect(() => {
    if (user) {
      setName(user.name || '');
      setEmail(user.email || '');
      setEquipe(user.equipe || '');
    }
  }, [user]);

  const handleUpdateProfile = async () => {
    setProfileErrors({});
    setIsLoadingProfileUpdate(true);

    const payload: ProfileUpdatePayload = { name, email, equipe };

    try {
      profileUpdateSchema.parse(payload); // Validação local

      const response = await apiRequest('PUT', `/api/users/${user?.userId}`, payload);
      const data = await response.json();

      toast({
        title: "Sucesso",
        description: "Seu perfil foi atualizado.",
        variant: "success",
      });
      await refreshUserData(); // Atualiza os dados do usuário no contexto e localStorage

    } catch (error: any) {
      console.error('Erro ao atualizar perfil:', error);
      if (error instanceof z.ZodError) {
        const newErrors: Record<string, string | undefined> = {};
        error.errors.forEach((err: any) => {
          if (err.path && err.path.length > 0) {
            newErrors[err.path[0]] = err.message;
          }
        });
        setProfileErrors(newErrors);
        toast({
          title: "Erro de Validação",
          description: "Por favor, corrija os campos indicados.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Erro ao Atualizar Perfil",
          description: error.message || "Ocorreu um erro ao atualizar seu perfil.",
          variant: "destructive",
        });
      }
    } finally {
      setIsLoadingProfileUpdate(false);
    }
  };

  const handleChangePassword = async () => {
    setPasswordErrors({});
    setIsLoadingPasswordChange(true);

    let hasError = false;
    if (!currentPassword) {
        setPasswordErrors(prev => ({ ...prev, currentPassword: "A senha atual é obrigatória." }));
        hasError = true;
    }
    if (!newPassword || newPassword.length < 6) {
      setPasswordErrors(prev => ({ ...prev, newPassword: "A nova senha deve ter pelo menos 6 caracteres." }));
      hasError = true;
    }
    if (newPassword !== confirmNewPassword) {
      setPasswordErrors(prev => ({ ...prev, confirmNewPassword: "As senhas não coincidem." }));
      hasError = true;
    }
    if (hasError) {
        setIsLoadingPasswordChange(false);
        return;
    }

    try {
      const payload = { 
        password: newPassword, // Nova senha
        currentPassword: currentPassword // Senha atual
      };

      await apiRequest('PUT', `/api/users/${user?.userId}`, payload);

      toast({
        title: "Sucesso",
        description: "Sua senha foi alterada.",
        variant: "success",
      });
      // Limpa os campos de senha
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
      // Força um refresh para que o token possa ser validado com a nova senha se houver necessidade no AuthContext
      // ou se o JWT em si contiver algum hash da senha. No caso atual, o token não muda.
      // Poderia ser interessante forçar logout aqui por segurança (user será forçado a logar com a nova senha).
      // logout(); // Opcional: Descomente para forçar o relogin
    } catch (error: any) {
      console.error('Erro ao mudar senha:', error);
      toast({
        title: "Erro ao Mudar Senha",
        description: error.message || "Ocorreu um erro ao mudar sua senha.",
        variant: "destructive",
      });
    } finally {
      setIsLoadingPasswordChange(false);
    }
  };

  if (!user) {
    return <div className="text-center py-8">Por favor, faça login para acessar suas configurações de conta.</div>;
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold tracking-tight">Minha Conta</h2>
      <p className="text-muted-foreground">
        Gerencie suas informações de perfil e segurança.
      </p>

      {/* Cartão de Informações do Perfil */}
      <Card>
        <CardHeader>
          <CardTitle>Informações do Perfil</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="username" className="text-right">Usuário</Label>
              <Input id="username" value={user.username} disabled className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="type" className="text-right">Tipo de Usuário</Label>
              <Input id="type" value={user.type} disabled className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="name" className="text-right">Nome Completo</Label>
              <Input id="name" value={name} onChange={(e) => setName(e.target.value)} className="col-span-3" />
              {profileErrors.name && <p className="col-span-4 text-right text-red-500 text-sm">{profileErrors.name}</p>}
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="email" className="text-right">Email</Label>
              <Input id="email" value={email} onChange={(e) => setEmail(e.target.value)} className="col-span-3" />
              {profileErrors.email && <p className="col-span-4 text-right text-red-500 text-sm">{profileErrors.email}</p>}
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="equipe" className="text-right">Equipe</Label>
              <Input id="equipe" value={equipe} onChange={(e) => setEquipe(e.target.value)} className="col-span-3" />
              {profileErrors.equipe && <p className="col-span-4 text-right text-red-500 text-sm">{profileErrors.equipe}</p>}
            </div>
          </div>
          <Button onClick={handleUpdateProfile} disabled={isLoadingProfileUpdate}>
            {isLoadingProfileUpdate ? 'Atualizando...' : 'Atualizar Perfil'}
          </Button>
        </CardContent>
      </Card>

      {/* Cartão de Alteração de Senha */}
      <Card>
        <CardHeader>
          <CardTitle>Alterar Senha</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="current-password" className="text-right">Senha Atual</Label>
              <Input id="current-password" type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} className="col-span-3" />
              {passwordErrors.currentPassword && <p className="col-span-4 text-right text-red-500 text-sm">{passwordErrors.currentPassword}</p>}
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="new-password" className="text-right">Nova Senha</Label>
              <Input id="new-password" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} className="col-span-3" />
              {passwordErrors.newPassword && <p className="col-span-4 text-right text-red-500 text-sm">{passwordErrors.newPassword}</p>}
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="confirm-new-password" className="text-right">Confirmar Nova Senha</Label>
              <Input id="confirm-new-password" type="password" value={confirmNewPassword} onChange={(e) => setConfirmNewPassword(e.target.value)} className="col-span-3" />
              {passwordErrors.confirmNewPassword && <p className="col-span-4 text-right text-red-500 text-sm">{passwordErrors.confirmNewPassword}</p>}
            </div>
          </div>
          <Button onClick={handleChangePassword} disabled={isLoadingPasswordChange}>
            {isLoadingPasswordChange ? 'Alterando...' : 'Alterar Senha'}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default AccountSettings;
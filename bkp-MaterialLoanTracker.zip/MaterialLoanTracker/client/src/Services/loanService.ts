
import { InsertLoan, PaginationParams, SearchFilterParams, LoanStatusFilterParams } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';

/**
 * Frontend loan service - handles API calls to backend loan endpoints
 */

export const createLoan = async (loanData: InsertLoan, token: string) => {
  const response = await apiRequest('/api/loans', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(loanData),
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || 'Failed to create loan');
  }

  return response.json();
};

export const returnLoan = async (loanId: number, token: string) => {
  const response = await apiRequest(`/api/loans/${loanId}/return`, {
    method: 'PUT',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || 'Failed to return loan');
  }

  return response.json();
};

export const getAllLoans = async (
  params: PaginationParams & SearchFilterParams & LoanStatusFilterParams,
  token: string
) => {
  const searchParams = new URLSearchParams();
  
  if (params.page) searchParams.append('page', params.page.toString());
  if (params.pageSize) searchParams.append('pageSize', params.pageSize.toString());
  if (params.search) searchParams.append('search', params.search);
  if (params.status) searchParams.append('status', params.status);

  const response = await apiRequest(`/api/loans?${searchParams.toString()}`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || 'Failed to get loans');
  }

  return response.json();
};

export const getActiveLoans = async (token: string) => {
  const response = await apiRequest('/api/loans/active', {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || 'Failed to get active loans');
  }

  return response.json();
};

export const getOverdueLoans = async (token: string) => {
  const response = await apiRequest('/api/loans/overdue', {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || 'Failed to get overdue loans');
  }

  return response.json();
};

export const getLoanById = async (loanId: number, token: string) => {
  const response = await apiRequest(`/api/loans/${loanId}`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || 'Failed to get loan');
  }

  return response.json();
};

export const getLoansByPerson = async (personId: number, token: string) => {
  const response = await apiRequest(`/api/loans/person/${personId}`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || 'Failed to get loans by person');
  }

  return response.json();
};

export const getLoansByItem = async (itemId: number, token: string) => {
  const response = await apiRequest(`/api/loans/item/${itemId}`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || 'Failed to get loans by item');
  }

  return response.json();
};

console.log('Frontend Loan service defined - API client only');

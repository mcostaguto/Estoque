import { InsertItem, ItemType, PaginationParams, SearchFilterParams, InventoryMovementFilterParams, InventoryMovementType } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';

/**
 * Frontend inventory service - handles API calls to backend inventory endpoints
 */

export const addItem = async (itemData: InsertItem, token: string) => {
  const response = await apiRequest('/api/inventory/items', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(itemData),
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || 'Failed to add item');
  }

  return response.json();
};

export const updateItem = async (id: number, itemData: Partial<InsertItem>, token: string) => {
  const response = await apiRequest(`/api/inventory/items/${id}`, {
    method: 'PUT',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(itemData),
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || 'Failed to update item');
  }

  return response.json();
};

export const deleteItem = async (id: number, token: string) => {
  const response = await apiRequest(`/api/inventory/items/${id}`, {
    method: 'DELETE',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || 'Failed to delete item');
  }
};

export const getAllItems = async (
  params: PaginationParams & SearchFilterParams & { itemType?: ItemType },
  token: string
) => {
  const searchParams = new URLSearchParams();

  if (params.page) searchParams.append('page', params.page.toString());
  if (params.pageSize) searchParams.append('pageSize', params.pageSize.toString());
  if (params.search) searchParams.append('search', params.search);
  if (params.itemType) searchParams.append('itemType', params.itemType);

  const response = await apiRequest(`/api/inventory/items?${searchParams.toString()}`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || 'Failed to get items');
  }

  return response.json();
};

export const getItemById = async (id: number, token: string) => {
  const response = await apiRequest(`/api/inventory/items/${id}`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || 'Failed to get item');
  }

  return response.json();
};

export const getItemDetailsByPartNumber = async (partNumber: string, token: string) => {
  const response = await apiRequest(`/api/inventory/items/part-number/${partNumber}`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || 'Failed to get item details');
  }

  return response.json();
};

export const addInventoryMovement = async (
  movementData: {
    itemId: number;
    quantity: number;
    type: InventoryMovementType;
    personId: number;
    notes?: string;
  },
  token: string
) => {
  const response = await apiRequest('/api/inventory-movements', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(movementData),
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || 'Failed to add inventory movement');
  }

  return response.json();
};

export const getAllInventoryMovements = async (
  params: PaginationParams & SearchFilterParams & InventoryMovementFilterParams,
  token: string
) => {
  const searchParams = new URLSearchParams();

  if (params.page) searchParams.append('page', params.page.toString());
  if (params.pageSize) searchParams.append('pageSize', params.pageSize.toString());
  if (params.search) searchParams.append('search', params.search);
  if (params.movementType) searchParams.append('movementType', params.movementType);

  const response = await apiRequest(`/api/inventory-movements?${searchParams.toString()}`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    const errorData = await response.json();
    throw new Error(errorData.message || 'Failed to get inventory movements');
  }

  return response.json();
};

console.log('Frontend Inventory service defined - API client only');

// shared/schema.ts

import { z } from 'zod';

// =========================================================
// Tipos e Enums
// =========================================================

export const USER_TYPES = ['admin', 'manager', 'basic'] as const;
export type UserType = typeof USER_TYPES[number];

export const ITEM_TYPES = ['tool', 'equipment', 'disposable'] as const;
export type ItemType = typeof ITEM_TYPES[number];

export const INVENTORY_MOVEMENT_TYPES = ['addition', 'withdrawal', 'adjustment'] as const;
export type InventoryMovementType = typeof INVENTORY_MOVEMENT_TYPES[number];

// NOVO: Schema para userType, exportado para uso em validações
export const userTypeSchema = z.enum(USER_TYPES);

// =========================================================
// Autenticação e Usuários
// =========================================================

export const loginSchema = z.object({
    username: z.string().min(1, 'Usuário é obrigatório.'),
    password: z.string().min(1, 'Senha é obrigatória.'),
});
export type LoginPayload = z.infer<typeof loginSchema>;

export const registerUserSchema = z.object({
    username: z.string().min(3, 'Nome de usuário deve ter pelo menos 3 caracteres.').max(50, 'Nome de usuário muito longo.'),
    password: z.string().min(6, 'Senha deve ter pelo menos 6 caracteres.').max(100, 'Senha muito longa.'),
    name: z.string().min(1, 'Nome completo é obrigatório.'),
    email: z.string().email('Formato de e-mail inválido.'),
    team: z.string().min(1, 'Equipe é obrigatória.'),
    phoneNumber: z.string().min(8, 'Telefone é obrigatório.').max(20, 'Telefone muito longo.'),
    type: userTypeSchema, // CORRIGIDO: Adicionado 'type' aqui
});
export type RegisterUserPayload = z.infer<typeof registerUserSchema>;

// Schema para Person
export const personSchema = z.object({
    id: z.number().int().positive(),
    name: z.string(),
    team: z.string(),
    email: z.string().email(),
    phoneNumber: z.string(),
    createdAt: z.coerce.date(), // CORRIGIDO: Use z.coerce.date()
    updatedAt: z.coerce.date(), // CORRIGIDO: Use z.coerce.date()
});
export type Person = z.infer<typeof personSchema>; // Exportado para uso no frontend

// Schema para dados de usuário do App
export const appUserSchema = z.object({
    userId: z.number().int().positive(),
    username: z.string(),
    type: userTypeSchema, // CORRIGIDO: Referencia userTypeSchema
    personId: z.number().int().positive(),
    isActive: z.boolean(),
    createdAt: z.coerce.date(), // CORRIGIDO: Use z.coerce.date()
    updatedAt: z.coerce.date(), // CORRIGIDO: Use z.coerce.date()
    lastLogin: z.coerce.date().nullable(), // CORRIGIDO: Use z.coerce.date()
});
export type AppUser = z.infer<typeof appUserSchema>; // Exportado para uso no frontend

export const appUserWithPersonSchema = appUserSchema.extend({
    person: personSchema.optional(),
});
export type AppUserWithPerson = z.infer<typeof appUserWithPersonSchema>;


// =========================================================
// Itens (Ferramentas, Equipamentos, Insumos)
// =========================================================

export const itemSchema = z.object({
    id: z.number().int().positive(),
    name: z.string(),
    type: z.enum(ITEM_TYPES),
    storagePlaceId: z.number().int().positive().nullable(),
    quantity: z.number().int().nullable(),
    minQuantity: z.number().int().nullable(),
    size: z.string().nullable(),
    manufacturer: z.string().nullable(),
    serialNumber: z.string().nullable(),
    model: z.string().nullable(),
    acquisitionDate: z.coerce.date().nullable(), // CORRIGIDO: Use z.coerce.date()
    acquisitionContext: z.string().nullable(),
    partNumber: z.string().nullable(),
    value: z.string().nullable(),
    description: z.string().nullable(),
    footprint: z.string().nullable(),
    createdAt: z.coerce.date(), // CORRIGIDO: Use z.coerce.date()
    updatedAt: z.coerce.date(), // CORRIGIDO: Use z.coerce.date()
});
export type Item = z.infer<typeof itemSchema>;

// InsertItem payload schema com validações condicionais
export const insertItemPayloadSchema = z.object({
    name: z.string().min(1, "Nome é obrigatório."),
    type: z.enum(ITEM_TYPES, { required_error: "Tipo de item é obrigatório." }),
    storagePlaceId: z.number().int().positive("Local de armazenamento é obrigatório."),
    description: z.string().nullable().optional(),

    // Disposable specific fields
    partNumber: z.string().nullable().optional(),
    value: z.string().nullable().optional(),
    footprint: z.string().nullable().optional(),
    quantity: z.number().int().min(0, "Quantidade deve ser um número inteiro não negativo.").nullable().optional(),
    minQuantity: z.number().int().min(0, "Quantidade mínima deve ser um número inteiro não negativo.").nullable().optional(),

    // Tool specific fields
    size: z.string().nullable().optional(),

    // Equipment specific fields (and now tool manufacturer)
    manufacturer: z.string().nullable().optional(),
    serialNumber: z.string().nullable().optional(),
    model: z.string().nullable().optional(),
    acquisitionDate: z.coerce.date().nullable().optional(), // CORRIGIDO: z.coerce.date()
    acquisitionContext: z.string().nullable().optional(),

    // Removed performingPersonId and performingUserId fields as requested by user
})
.superRefine((data, ctx) => {
    if (data.type === 'disposable') {
        if (!data.partNumber || data.partNumber.trim() === '') {
            ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Part Number é obrigatório para insumos.", path: ['partNumber'] });
        }
        if (!data.description || data.description.trim() === '') {
            ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Descrição é obrigatória para insumos.", path: ['description'] });
        }
        if (!data.value || data.value.trim() === '') {
            ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Valor/Especificação é obrigatório para insumos.", path: ['value'] });
        }
        if (!data.footprint || data.footprint.trim() === '') {
            ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Footprint é obrigatório para insumos.", path: ['footprint'] });
        }
        if (data.quantity === null || data.quantity === undefined || data.quantity < 0) {
            ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Quantidade inicial é obrigatória e deve ser um número não negativo para insumos.", path: ['quantity'] });
        }
        // Ensure other types' fields are null for disposable
        if (data.size !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Tamanho não se aplica a insumos.", path: ['size'] }); }
        if (data.serialNumber !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Número de série não se aplica a insumos.", path: ['serialNumber'] }); }
        if (data.model !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Modelo não se aplica a insumos.", path: ['model'] }); }
        if (data.acquisitionDate !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Data de Aquisição não se aplica a insumos.", path: ['acquisitionDate'] }); }
        if (data.acquisitionContext !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Contexto de Aquisição não se aplica a insumos.", path: ['acquisitionContext'] }); }
    } else if (data.type === 'tool') {
        if (!data.size || data.size.trim() === '') {
            ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Tamanho é obrigatório para ferramentas.", path: ['size'] });
        }
        if (!data.manufacturer || data.manufacturer.trim() === '') {
            ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Fabricante é obrigatório para ferramentas.", path: ['manufacturer'] });
        }
        // Ensure other types' fields are null for tools
        if (data.partNumber !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Part Number não se aplica a ferramentas.", path: ['partNumber'] }); }
        if (data.value !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Valor/Especificação não se aplica a ferramentas.", path: ['value'] }); }
        if (data.footprint !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Footprint não se aplica a ferramentas.", path: ['footprint'] }); }
        if (data.quantity !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Quantidade não se aplica a ferramentas.", path: ['quantity'] }); }
        if (data.minQuantity !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Quantidade Mínima não se aplica a ferramentas.", path: ['minQuantity'] }); }
        if (data.serialNumber !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Número de série não se aplica a ferramentas.", path: ['serialNumber'] }); }
        if (data.model !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Modelo não se aplica a ferramentas.", path: ['model'] }); }
        if (data.acquisitionDate !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Data de Aquisição não se aplica a ferramentas.", path: ['acquisitionDate'] }); }
        if (data.acquisitionContext !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Contexto de Aquisição não se aplica a ferramentas.", path: ['acquisitionContext'] }); }
    } else if (data.type === 'equipment') {
        if (!data.manufacturer || data.manufacturer.trim() === '') {
            ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Fabricante é obrigatório para equipamentos.", path: ['manufacturer'] });
        }
        if (!data.serialNumber || data.serialNumber.trim() === '') {
            ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Número de série é obrigatório para equipamentos.", path: ['serialNumber'] });
        }
        if (!data.model || data.model.trim() === '') {
            ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Modelo é obrigatório para equipamentos.", path: ['model'] });
        }
        if (!data.acquisitionDate) {
            ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Data de Aquisição é obrigatória para equipamentos.", path: ['acquisitionDate'] });
        }
        if (!data.acquisitionContext || data.acquisitionContext.trim() === '') {
            ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Contexto de Aquisição é obrigatório para equipamentos.", path: ['acquisitionContext'] });
        }
        // Ensure other types' fields are null for equipment
        if (data.partNumber !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Part Number não se aplica a equipamentos.", path: ['partNumber'] }); }
        if (data.value !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Valor/Especificação não se aplica a equipamentos.", path: ['value'] }); }
        if (data.footprint !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Footprint não se aplica a equipamentos.", path: ['footprint'] }); }
        if (data.quantity !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Quantidade não se aplica a equipamentos.", path: ['quantity'] }); }
        if (data.minQuantity !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Quantidade Mínima não se aplica a equipamentos.", path: ['minQuantity'] }); }
        if (data.size !== null) { ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Tamanho não se aplica a equipamentos.", path: ['size'] }); }
    }
});
export type InsertItemPayload = z.infer<typeof insertItemPayloadSchema>;

// Add missing InsertItem alias for frontend compatibility
export type InsertItem = InsertItemPayload;
export const insertItemSchema = insertItemPayloadSchema;


export const storagePlaceSchema = z.object({
    id: z.number().int().positive(),
    name: z.string(),
    location: z.string(),
    description: z.string().nullable(),
    createdAt: z.coerce.date(), // CORRIGIDO: Use z.coerce.date()
    updatedAt: z.coerce.date(), // CORRIGIDO: Use z.coerce.date()
});
export type StoragePlace = z.infer<typeof storagePlaceSchema>;

export const insertStoragePlacePayloadSchema = z.object({
    name: z.string().min(1, "Nome do local principal é obrigatório."),
    location: z.string().min(1, "Subárea / Localização detalhada é obrigatória."),
    description: z.string().optional(),
});
export type InsertStoragePlacePayload = z.infer<typeof insertStoragePlacePayloadSchema>;

// =========================================================
// Empréstimos (Loans)
// =========================================================

export const loanSchema = z.object({
    id: z.number().int().positive(),
    itemId: z.number().int().positive(),
    personId: z.number().int().positive(),
    loanDate: z.coerce.date(), // CORRIGIDO: Use z.coerce.date()
    dueDate: z.coerce.date().nullable(), // CORRIGIDO: Use z.coerce.date()
    returnDate: z.coerce.date().nullable(), // CORRIGIDO: Use z.coerce.date()
    isIndefinite: z.boolean(),
    createdAt: z.coerce.date(), // CORRIGIDO: Use z.coerce.date()
    updatedAt: z.coerce.date(), // CORRIGIDO: Use z.coerce.date()
    notes: z.string().nullable(), // notes já estava, mantido
});
export type Loan = z.infer<typeof loanSchema>;

export const insertLoanSchema = z.object({
    itemId: z.number().int().positive('ID do item é obrigatório e deve ser positivo.'),
    personId: z.number().int().positive('ID da pessoa é obrigatório e deve ser positivo.'),
    loanDate: z.coerce.date().optional(), // CORRIGIDO: Use z.coerce.date()
    dueDate: z.coerce.date().nullable().optional(), // CORRIGIDO: Use z.coerce.date()
    notes: z.string().nullable().optional(),
    isIndefinite: z.boolean().optional(),
}).superRefine((data, ctx) => {
    if (data.isIndefinite === true && (data.dueDate !== null && data.dueDate !== undefined)) {
        ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: "Empréstimos indefinidos não devem ter uma data de devolução.",
            path: ['dueDate'],
        });
    }
    if (data.isIndefinite === false && (data.dueDate === null || data.dueDate === undefined)) {
        ctx.addIssue({
            code: z.ZodIssueCode.custom,
            message: "Empréstimos definidos devem ter uma data de devolução.",
            path: ['dueDate'],
        });
    }
});
export type InsertLoanPayload = z.infer<typeof insertLoanSchema>;

// Add missing InsertLoan alias for frontend compatibility 
export type InsertLoan = InsertLoanPayload;


// NOVO: Schema para payload de retorno de empréstimo (se houver dados adicionais, como performingUserId)
export const returnLoanPayloadSchema = z.object({
    performingUserId: z.number().int().positive("ID do usuário realizando a ação é obrigatório.").optional(),
});
export type ReturnLoanPayload = z.infer<typeof returnLoanPayloadSchema>;

// Filtros de Status para Empréstimos
export const loanStatusFilterParamsSchema = z.object({
    status: z.enum(['all', 'active', 'overdue', 'returned']).optional(),
});
export type LoanStatusFilterParams = z.infer<typeof loanStatusFilterParamsSchema>;

// =========================================================
// Movimentação de Inventário
// =========================================================

export const inventoryMovementSchema = z.object({
    id: z.number().int().positive(),
    itemId: z.number().int().positive(),
    quantity: z.number().int(),
    date: z.coerce.date(), // CORRIGIDO: Use z.coerce.date()
    personId: z.number().int().positive().nullable(),
    notes: z.string().nullable(),
    type: z.enum(INVENTORY_MOVEMENT_TYPES),
});
export type InventoryMovement = z.infer<typeof inventoryMovementSchema>;

// ALTERADO: Adiciona performingUserId para auditoria e personId para o sujeito da movimentação
export const insertInventoryMovementSchema = z.object({
    itemId: z.number().int().positive('ID do item é obrigatório e deve ser positivo.'),
    quantity: z.number().int('Quantidade deve ser um número inteiro.').refine(q => q !== 0, 'Quantidade não pode ser zero.'),
    type: z.enum(INVENTORY_MOVEMENT_TYPES, { required_error: 'Tipo de movimentação é obrigatório.' }),
    personId: z.number().int().positive('ID da pessoa (sujeito) é obrigatório e deve ser positivo.').nullable(), // Agora representa a pessoa do movimento, não o executor
    notes: z.string().nullable().optional(),
    performingUserId: z.number().int().positive('ID do usuário que realiza a ação é obrigatório.').nullable(), // Quem registrou
});
export type InsertInventoryMovement = z.infer<typeof insertInventoryMovementSchema>;

// Filtros de Movimentação de Inventário
export const inventoryMovementFilterParamsSchema = z.object({
    movementType: z.enum(INVENTORY_MOVEMENT_TYPES).optional(),
});
export type InventoryMovementFilterParams = z.infer<typeof inventoryMovementFilterParamsSchema>;

// =========================================================
// Parâmetros de Query Comuns
// =========================================================

export const paginationParamsSchema = z.object({
    page: z.coerce.number().int().positive().optional().default(1),
    pageSize: z.coerce.number().int().positive().optional().default(10),
});
export type PaginationParams = z.infer<typeof paginationParamsSchema>;

export const searchFilterParamsSchema = z.object({
    search: z.string().optional(),
});
export type SearchFilterParams = z.infer<typeof searchFilterParamsSchema>;

export const itemTypeFilterParamsSchema = z.object({
    itemType: z.enum(ITEM_TYPES).optional(),
    value: z.string().optional(), // For disposable items
    footprint: z.string().optional(), // For disposable items
});
export type ItemTypeFilterParams = z.infer<typeof itemTypeFilterParamsSchema>;

// =========================================================
// Respostas de API Comuns
// =========================================================

// Simplified pagination schema to avoid excessive type depth
export const paginatedResponseSchema = <T extends z.ZodTypeAny>(itemSchema: T) =>
    z.object({
        data: z.array(itemSchema),
        total: z.number().int().min(0),
        page: z.number().int().positive(),
        pageSize: z.number().int().positive(),
        totalPages: z.number().int().min(0),
    });

// Specific pagination schemas to avoid type complexity
export const paginatedLoanResponseSchema = z.object({
    data: z.array(loanSchema),
    total: z.number().int().min(0),
    page: z.number().int().positive(),
    pageSize: z.number().int().positive(),
    totalPages: z.number().int().min(0),
});

export const paginatedItemResponseSchema = z.object({
    data: z.array(itemSchema),
    total: z.number().int().min(0),
    page: z.number().int().positive(),
    pageSize: z.number().int().positive(),
    totalPages: z.number().int().min(0),
});

// =========================================================
// Controle de Acesso Simplificado (Portas + Ferramentas)
// =========================================================

// Verificação de Credenciais para Controle de Porta
export const doorAccessRequestSchema = z.object({
  userId: z.number().int().positive(),
  badgeId: z.string().min(1),
  doorId: z.string().min(1), // Identificador da porta (ex: "DOOR_MAIN", "DOOR_STORAGE_A")
  timestamp: z.coerce.date(),
});
export type DoorAccessRequest = z.infer<typeof doorAccessRequestSchema>;

// Resposta do Sistema de Controle de Porta
export const doorAccessResponseSchema = z.object({
  allowed: z.boolean(),
  reason: z.string(),
  userName: z.string().optional(),
  userTeam: z.string().optional(),
});
export type DoorAccessResponse = z.infer<typeof doorAccessResponseSchema>;

// Notificação de Remoção de Ferramenta/Equipamento
export const toolRemovalNotificationSchema = z.object({
  userId: z.number().int().positive(),
  itemId: z.number().int().positive(),
  doorId: z.string().min(1), // Porta/área onde a ferramenta foi removida
  timestamp: z.coerce.date(),
});
export type ToolRemovalNotification = z.infer<typeof toolRemovalNotificationSchema>;

// Notificação de Retorno de Ferramenta/Equipamento
export const toolReturnNotificationSchema = z.object({
  userId: z.number().int().positive(),
  itemId: z.number().int().positive(),
  doorId: z.string().min(1), // Porta/área onde a ferramenta foi retornada
  timestamp: z.coerce.date(),
});
export type ToolReturnNotification = z.infer<typeof toolReturnNotificationSchema>;

// Log de Acesso à Porta (apenas para auditoria)
export const doorAccessLogSchema = z.object({
  id: z.number().int().positive(),
  userId: z.number().int().positive(),
  badgeId: z.string(),
  doorId: z.string(),
  allowed: z.boolean(),
  reason: z.string(),
  timestamp: z.coerce.date(),
});
export type DoorAccessLog = z.infer<typeof doorAccessLogSchema>;

// =========================================================
// Exportações
// =========================================================

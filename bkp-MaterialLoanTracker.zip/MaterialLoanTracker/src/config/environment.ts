// src/config/environment.ts
import dotenv from "dotenv";
import { z } from "zod";
import path from "path";
import { fileURLToPath } from "url";

// Get the directory of this file and navigate to project root
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.join(__dirname, '../../');

// Carrega as variáveis de ambiente do arquivo .env
dotenv.config({ path: path.join(projectRoot, '.env') });

// Define o esquema para as variáveis de ambiente
const environmentSchema = z.object({
  NODE_ENV: z
    .enum(["development", "production", "test"])
    .default("development"),
  PORT: z.coerce.number().int().positive().default(5000),
  DATABASE_URL: z
    .string()
    .url({ message: "DATABASE_URL inválida. Deve ser uma URL válida." }),
  JWT_SECRET: z
    .string()
    .min(32, { message: "JWT_SECRET deve ter pelo menos 32 caracteres." }),
  JWT_EXPIRES_IN: z.string().default("1d"),
  FRONTEND_URL: z.string().min(1, { message: "FRONTEND_URL é obrigatória." }),
  // NOVO: Variável de ambiente para a senha inicial do administrador
  ADMIN_INITIAL_PASSWORD: z.string().optional(),
  // NOVO: Variável de ambiente para o número de salt rounds do bcrypt
  BCRYPT_SALT_ROUNDS: z.coerce.number().int().positive().optional().default(10),
});

// Tenta validar as variáveis de ambiente
const parsedEnv = environmentSchema.safeParse(process.env);

if (!parsedEnv.success) {
  console.error(
    "❌ Erro de validação nas variáveis de ambiente:",
    parsedEnv.error.flatten().fieldErrors,
  );
  throw new Error(
    "Variáveis de ambiente inválidas. Verifique o console para detalhes.",
  );
}

// Exporta as variáveis de ambiente validadas e tipadas
export const environment = {
  nodeEnv: parsedEnv.data.NODE_ENV,
  port: 5000, // Force port 5000 for web server (database uses 5432)
  host: process.env.NODE_ENV === 'production' ? '0.0.0.0' : 'localhost',
  databaseUrl: parsedEnv.data.DATABASE_URL,
  jwt: {
    secret: parsedEnv.data.JWT_SECRET,
    expiresIn: parsedEnv.data.JWT_EXPIRES_IN,
  },
  frontendUrl: parsedEnv.data.FRONTEND_URL,
  adminInitialPassword: parsedEnv.data.ADMIN_INITIAL_PASSWORD,
  bcryptSaltRounds: parsedEnv.data.BCRYPT_SALT_ROUNDS, // Expõe a nova variável
};
// src/config/database.ts

import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import { environment } from '@config/environment';
import * as schema from '@models/schema'; // NOVO: Importa todos os schemas

// Cria um cliente de banco de dados usando a biblioteca `postgres`
const client = postgres(environment.databaseUrl, {
  // Configurações adicionais do cliente postgres (opcional)
});

// Inicializa o Drizzle ORM com o cliente postgres E O SCHEMA
export const db = drizzle(client, { schema });

console.log('Database client initialized.');

export const closeDbConnection = async () => {
  console.log('Closing database connection...');
  await client.end();
  console.log('Database connection closed.');
};
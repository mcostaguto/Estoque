// src/types/express.d.ts
import { AppUser } from '@models/schema';
import { Server as SocketIOServer } from 'socket.io';
import { UserType } from '@shared/schema';

// Este é o único local onde a interface Request do Express é estendida
declare global {
  namespace Express {
    export interface Request {
      user?: Omit<AppUser, 'password'>; // Contém userId, username, type, personId, isActive, etc.
      token?: string; // Para poder acessar o token completo no req (útil para blacklist)
      io?: SocketIOServer; // CORRIGIDO: Para passar a instância do Socket.IO para os controladores
    }
  }
}
// src/services/storagePlaceService.ts

// In-memory storage for storage places
const storagePlacesData: any[] = [
  { id: 1, name: 'Armazém Principal', location: 'A1', description: 'Local principal de armazenamento' },
  { id: 2, name: 'Sala de Ferramentas', location: 'B2', description: 'Local para ferramentas' },
  { id: 3, name: 'Depósito de Componentes', location: 'C3', description: 'Local para componentes eletrônicos' }
];

// Função para adicionar um novo Local de Armazenamento
export const addStoragePlace = async (data: any) => {
  const newPlace = {
    id: storagePlacesData.length + 1,
    ...data,
    createdAt: new Date()
  };
  storagePlacesData.push(newPlace);
  return newPlace;
};

// Função para listar todos os locais de armazenamento
export const getAllStoragePlaces = async () => {
  return storagePlacesData;
};

console.log('StoragePlace service defined.');
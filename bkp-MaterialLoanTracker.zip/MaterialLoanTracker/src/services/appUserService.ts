// backend/src/services/appUserService.ts

import { db } from '@config/database';
import { appUsers, people, AppUser, InsertAppUser, Person, InsertPerson, auditLogs, InsertAuditLog } from '@models/schema';
import { eq, and, like, count, sql } from 'drizzle-orm';
import bcrypt from 'bcrypt';
import { RegisterUserPayload, PaginationParams, SearchFilterParams, UserType, AppUserWithPerson } from '@shared/schema';

// Interface para o payload de atualização de usuário, que pode incluir a nova senha
export interface UpdateAppUserPayload {
  password?: string; // Nova senha
  type?: UserType;
  isActive?: boolean;
  // Campos da entidade Person (associada)
  name?: string;
  email?: string;
  team?: string;
  phoneNumber?: string;
  // Campo opcional para auditoria
  performingUserId?: number | null;
}

/**
 * Cria um novo appUser e uma pessoa associada.
 * @param userData Dados para registro do usuário.
 * @returns O novo usuário criado (sem a senha, mas com dados da pessoa).
 * @throws Erro se o nome de usuário ou e-mail já existirem.
 */
export const createAppUser = async (userData: RegisterUserPayload & { performingUserId?: number | null }): Promise<Omit<AppUserWithPerson, 'password'>> => {
  return db.transaction(async (tx) => {
    const existingAppUser = await tx.select().from(appUsers).where(eq(appUsers.username, userData.username)).limit(1);
    if (existingAppUser.length > 0) {
      throw new Error('Nome de usuário já existe.');
    }

    const existingPerson = await tx.select().from(people).where(eq(people.email, userData.email)).limit(1);
    if (existingPerson.length > 0) {
      throw new Error('E-mail já cadastrado.');
    }

    const hashedPassword = await bcrypt.hash(userData.password, 10);

    const newPersonData: InsertPerson = {
      name: userData.name,
      team: userData.team,
      email: userData.email,
      phoneNumber: userData.phoneNumber,
    };
    const newPersonRecord = await tx.insert(people).values(newPersonData).returning();
    const newPerson = newPersonRecord[0];

    if (!newPerson) {
      throw new Error('Falha ao criar registro de pessoa.');
    }

    const newAppUserData: InsertAppUser = {
      username: userData.username,
      password: hashedPassword,
      type: userData.type,
      personId: newPerson.id,
      isActive: true,
    };
    const newAppUserRecord = await tx.insert(appUsers).values(newAppUserData).returning();
    const newAppUser = newAppUserRecord[0];

    if (!newAppUser) {
      throw new Error('Falha ao criar registro de usuário.');
    }

    // Registrar auditoria
    await tx.insert(auditLogs).values({
      userId: userData.performingUserId || null,
      action: 'CREATE',
      entityType: 'AppUser',
      entityId: newAppUser.userId,
      details: {
        new: {
          username: newAppUser.username,
          type: newAppUser.type,
          personName: newPerson.name,
          personEmail: newPerson.email,
          personTeam: newPerson.team
        }
      },
    });

    const { password: _, ...appUserWithoutPassword } = newAppUser;
    const finalPerson: Person = { ...newPerson, phoneNumber: newPerson.phoneNumber || '' };
    const finalAppUser: Omit<AppUserWithPerson, 'password'> = {
      ...appUserWithoutPassword,
      type: newAppUser.type,
      person: finalPerson
    };
    return finalAppUser;
  });
};

/**
 * Busca todos os appUsers com paginação e filtro, incluindo dados da pessoa.
 * @param params Parâmetros de paginação e busca.
 * @returns Um objeto contendo os dados dos usuários, total, página, tamanho da página e total de páginas.
 */
export const getAllAppUsers = async (
  params: PaginationParams & SearchFilterParams
): Promise<{ data: Omit<AppUserWithPerson, 'password'>[]; total: number; page: number; pageSize: number; totalPages: number }> => {
  const { page = 1, pageSize = 10, search } = params;
  const offset = (page - 1) * pageSize;

  let query = db.select({
    user: appUsers,
    person: people,
  })
  .from(appUsers)
  .leftJoin(people, eq(appUsers.personId, people.id))
  .$dynamic();

  let countQuery = db.select({ count: count() })
  .from(appUsers)
  .leftJoin(people, eq(appUsers.personId, people.id))
  .$dynamic();

  if (search) {
    const searchLower = `%${search.toLowerCase()}%`;
    query = query.where(
      sql`(${appUsers.username} ILIKE ${searchLower} OR ${people.name} ILIKE ${searchLower} OR ${people.email} ILIKE ${searchLower} OR ${people.phoneNumber} ILIKE ${searchLower} OR ${people.team} ILIKE ${searchLower})`
    );
    countQuery = countQuery.where(
      sql`(${appUsers.username} ILIKE ${searchLower} OR ${people.name} ILIKE ${searchLower} OR ${people.email} ILIKE ${searchLower} OR ${people.phoneNumber} ILIKE ${searchLower} OR ${people.team} ILIKE ${searchLower})`
    );
  }

  const [totalResult] = await countQuery;
  const total = totalResult ? totalResult.count : 0;
  const totalPages = Math.ceil(total / pageSize);

  const data = await query.limit(pageSize).offset(offset);

  // Remove a senha dos objetos de usuário antes de retornar e formata o retorno
  const usersWithPersonWithoutPasswords = data.map(({ user, person }) => {
    const { password: _, ...userWithoutPassword } = user;
    const finalPerson: Person | undefined = person ? { ...person, phoneNumber: person.phoneNumber || '' } : undefined;
    return {
      ...userWithoutPassword,
      type: user.type,
      person: finalPerson
    };
  });

  return {
    data: usersWithPersonWithoutPasswords,
    total,
    page,
    pageSize,
    totalPages,
  };
};

/**
 * Busca um appUser por ID, incluindo dados da pessoa.
 * @param userId ID do usuário.
 * @returns O usuário encontrado (sem a senha, mas com dados da pessoa) ou null.
 */
export const getAppUserById = async (userId: number): Promise<Omit<AppUserWithPerson, 'password'> | null> => {
  const [result] = await db.select({
    user: appUsers,
    person: people,
  })
  .from(appUsers)
  .leftJoin(people, eq(appUsers.personId, people.id))
  .where(eq(appUsers.userId, userId))
  .limit(1);

  if (!result || !result.user) return null;

  const { password: _, ...appUserWithoutPassword } = result.user;
  // CORREÇÃO: Fazer o type assertion explícito para 'type'
  // E garantir que phoneNumber é string (se o schema Drizzle for notNull)
  const finalPerson: Person | undefined = result.person ? { ...result.person, phoneNumber: result.person.phoneNumber || '' } : undefined;
  const finalAppUser: Omit<AppUserWithPerson, 'password'> = {
    ...appUserWithoutPassword,
    type: result.user.type as UserType, // Type assertion aqui
    person: finalPerson
  };
  return finalAppUser;
};

/**
 * Atualiza os dados de um usuário e/ou da pessoa associada.
 * Pode incluir validação de senha atual se 'currentPassword' for fornecida e 'password' for alterada.
 */
export const updateAppUser = async (
  userId: number,
  updateData: UpdateAppUserPayload,
  currentPassword?: string // Parâmetro para a senha atual
): Promise<Omit<AppUserWithPerson, 'password'> | null> => {
  return db.transaction(async (tx) => {
    const [existingUser] = await tx.select().from(appUsers).where(eq(appUsers.userId, userId)).limit(1);
    if (!existingUser) {
      throw new Error('Usuário não encontrado.');
    }

    const [existingPersonRecord] = await tx.select().from(people).where(eq(people.id, existingUser.personId)).limit(1);
    const existingPerson = existingPersonRecord;
    if (!existingPerson) {
        throw new Error('Pessoa associada ao usuário não encontrada.');
    }

    const dataToUpdate: Partial<InsertAppUser> = {};
    const personDataToUpdate: Partial<InsertPerson> = {};
    const changes: { [key: string]: { old: any; new: any } } = {};

    // Processar campos da entidade AppUser
    if (updateData.type !== undefined && updateData.type !== existingUser.type) {
      dataToUpdate.type = updateData.type;
      changes.type = { old: existingUser.type, new: updateData.type };
    }
    if (typeof updateData.isActive === 'boolean' && updateData.isActive !== existingUser.isActive) {
      dataToUpdate.isActive = updateData.isActive;
      changes.isActive = { old: existingUser.isActive, new: updateData.isActive };
    }

    // Processar campos da entidade Person
    if (updateData.name !== undefined && updateData.name !== existingPerson.name) {
      personDataToUpdate.name = updateData.name;
      changes.personName = { old: existingPerson.name, new: updateData.name };
    }
    if (updateData.email !== undefined && updateData.email !== existingPerson.email) {
      const emailExists = await tx.select().from(people).where(eq(people.email, updateData.email)).limit(1);
      if (emailExists.length > 0 && emailExists[0].id !== existingPerson.id) {
        throw new Error('E-mail já cadastrado para outro usuário.');
      }
      personDataToUpdate.email = updateData.email;
      changes.personEmail = { old: existingPerson.email, new: updateData.email };
    }
    if (updateData.phoneNumber !== undefined && updateData.phoneNumber !== existingPerson.phoneNumber) {
        personDataToUpdate.phoneNumber = updateData.phoneNumber;
        changes.personPhoneNumber = { old: existingPerson.phoneNumber, new: updateData.phoneNumber };
    }
    if (updateData.team !== undefined && updateData.team !== existingPerson.team) {
        personDataToUpdate.team = updateData.team;
        changes.personTeam = { old: existingPerson.team, new: updateData.team };
    }

    // Lógica para alteração de senha
    if (updateData.password) {
      if (!currentPassword) {
        throw new Error('É necessário fornecer a senha atual para alterá-la.');
      }
      const passwordMatch = await bcrypt.compare(currentPassword, existingUser.password);
      if (!passwordMatch) {
        throw new Error('Senha atual incorreta.');
      }
      dataToUpdate.password = await bcrypt.hash(updateData.password, 10);
      changes.password = { old: 'hashed', new: 'new_hashed' }; // Não logar senhas em claro
    }
    dataToUpdate.updatedAt = new Date(); // Atualiza o timestamp de atualização

    const [updatedUserResult] = await tx.update(appUsers).set(dataToUpdate).where(eq(appUsers.userId, userId)).returning();
    if (!updatedUserResult) throw new Error('Falha ao atualizar usuário.');

    // Atualiza a pessoa associada, se houver dados para atualizar
    let updatedPerson: Person | undefined;
    if (Object.keys(personDataToUpdate).length > 0) {
      const [p] = await tx.update(people).set(personDataToUpdate).where(eq(people.id, updatedUserResult.personId)).returning();
      updatedPerson = p;
    } else {
        // Se não houve atualização na pessoa, busca os dados existentes para retornar
        updatedPerson = existingPerson;
    }

    // Registrar auditoria se houver mudanças
    if (Object.keys(changes).length > 0) {
      await tx.insert(auditLogs).values({
        userId: updateData.performingUserId || null,
        action: 'UPDATE',
        entityType: 'AppUser',
        entityId: userId,
        details: { changes: changes },
      });
    }

    const { password: _, ...userWithoutPassword } = updatedUserResult;
    // CORREÇÃO: Fazer o type assertion explícito para 'type'
    // E garantir que phoneNumber é string (se o schema Drizzle for notNull)
    const finalUpdatedPerson: Person | undefined = updatedPerson ? { ...updatedPerson, phoneNumber: updatedPerson.phoneNumber || '' } : undefined;
    const finalAppUser: Omit<AppUserWithPerson, 'password'> = {
      ...userWithoutPassword,
      type: updatedUserResult.type as UserType, // Type assertion aqui
      person: finalUpdatedPerson
    };
    return finalAppUser;
  });
};

console.log('AppUser service defined.');
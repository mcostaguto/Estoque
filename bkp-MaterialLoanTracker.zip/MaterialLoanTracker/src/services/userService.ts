// src/services/userService.ts

interface User {
  id: number;
  username: string;
  email: string;
  type: 'admin' | 'manager' | 'basic';
  personId: number;
  createdAt: Date;
}

// Mock users data
const users: User[] = [
  {
    id: 1,
    username: 'testuser',
    email: 'test@example.com',
    type: 'admin',
    personId: 1,
    createdAt: new Date('2024-01-01')
  },
  {
    id: 2,
    username: 'manager1',
    email: 'manager@example.com',
    type: 'manager',
    personId: 2,
    createdAt: new Date('2024-01-02')
  },
  {
    id: 3,
    username: 'user1',
    email: 'user1@example.com',
    type: 'basic',
    personId: 3,
    createdAt: new Date('2024-01-03')
  }
];

export const getAllUsers = async () => {
  return users;
};

export const createUser = async (userData: Partial<User>) => {
  const newUser: User = {
    id: users.length + 1,
    username: userData.username || '',
    email: userData.email || '',
    type: userData.type || 'basic',
    personId: userData.personId || 0,
    createdAt: new Date()
  };
  
  users.push(newUser);
  return newUser;
};

export const getUserById = async (id: number) => {
  return users.find(user => user.id === id);
};
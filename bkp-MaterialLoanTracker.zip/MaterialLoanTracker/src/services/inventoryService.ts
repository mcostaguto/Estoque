// src/services/inventoryService.ts

// Temporary in-memory storage for inventory services
const inventoryItems: any[] = [
  {
    id: 1,
    name: 'Drill',
    type: 'tool',
    quantity: 5,
    minQuantity: 2,
    maxQuantity: 10,
    unit: 'unit',
    active: true,
    location: 'Workshop',
    tags: null,
    notes: 'Standard power drill for construction projects',
    storagePlaceId: 1,
    size: 'Medium',
    manufacturer: 'DeWalt',
    serialNumber: 'DW001',
    model: 'DCD771',
    acquisitionDate: new Date('2023-01-15'),
    acquisitionContext: 'Initial equipment purchase',
    description: 'Cordless drill with battery pack'
  },
  {
    id: 2,
    name: 'Hammer',
    type: 'tool',
    quantity: 3,
    minQuantity: 1,
    maxQuantity: 5,
    unit: 'unit',
    active: true,
    location: 'Workshop',
    tags: null,
    notes: 'Claw hammer for general use',
    storagePlaceId: 1,
    size: 'Standard',
    manufacturer: 'Stanley',
    serialNumber: 'ST002',
    model: 'STHT51512',
    acquisitionDate: new Date('2023-01-15'),
    acquisitionContext: 'Initial equipment purchase',
    description: 'Steel claw hammer 16oz'
  },
  {
    id: 3,
    name: 'Safety Goggles',
    type: 'disposable',
    quantity: 50,
    minQuantity: 10,
    maxQuantity: 100,
    unit: 'unit',
    active: true,
    location: 'Safety Equipment Room',
    tags: 'safety,eyes',
    notes: 'Clear safety goggles, ANSI Z87.1 compliant',
    storagePlaceId: 2,
    size: 'One Size',
    manufacturer: '3M',
    serialNumber: '3M003',
    model: 'SecureFit SF400',
    acquisitionDate: new Date('2023-02-01'),
    acquisitionContext: 'Safety equipment upgrade',
    description: 'Anti-fog safety goggles with adjustable strap'
  }
];

// Get all inventory items with pagination
export const getAllItems = async (
  page: number = 1,
  pageSize: number = 10,
  search?: string,
  itemType?: string
): Promise<{ data: Item[]; total: number; page: number; pageSize: number; totalPages: number }> => {
  let filteredData = [...inventoryItems]; // Use the correct variable name here

  // Apply item type filter if provided
  if (itemType) {
    filteredData = filteredData.filter(item => item.type === itemType);
  }

  // Apply search filter if provided
  if (search) {
    filteredData = filteredData.filter(item =>
      item.name.toLowerCase().includes(search.toLowerCase()) ||
      item.type.toLowerCase().includes(search.toLowerCase()) ||
      (item.manufacturer && item.manufacturer.toLowerCase().includes(search.toLowerCase()))
    );
  }

  // Calculate pagination
  const total = filteredData.length;
  const totalPages = Math.ceil(total / pageSize);
  const offset = (page - 1) * pageSize;
  const paginatedData = filteredData.slice(offset, offset + pageSize);

  // Return in expected format
  return {
    data: paginatedData.map(item => ({
        id: item.id,
        name: item.name,
        type: item.type,
        quantity: item.quantity,
        minQuantity: item.minQuantity,
        maxQuantity: item.maxQuantity,
        unit: item.unit,
        location: item.location,
        tags: item.tags,
        notes: item.notes,
        active: item.active,
        createdAt: item.createdAt,
        updatedAt: item.updatedAt,
        storagePlaceId: item.storagePlaceId || null,
        size: item.size || '',
        manufacturer: item.manufacturer || '',
        serialNumber: item.serialNumber || '',
        model: item.model || '',
        acquisitionDate: item.acquisitionDate || null,
        acquisitionContext: item.acquisitionContext || '',
        description: item.description || '',
        partNumber: item.partNumber || '',
        value: item.value || '',
        footprint: item.footprint || '',
      })),
    total,
    page,
    pageSize,
    totalPages
  };
};

// Add new item
export const addItem = async (data: any) => {
  const newItem = {
    id: inventoryItems.length + 1,
    ...data,
    createdAt: new Date(),
    updatedAt: new Date()
  };
  inventoryItems.push(newItem);
  return newItem;
};

// Temporary in-memory storage for inventory movements
const inventoryMovements: any[] = [
  {
    id: 1,
    itemId: 1,
    quantity: 5,
    type: 'addition',
    personId: 1,
    notes: 'Entrada inicial de estoque',
    date: new Date(),
    createdAt: new Date(),
    updatedAt: new Date()
  },
  {
    id: 2,
    itemId: 2,
    quantity: -10,
    type: 'withdrawal',
    personId: 1,
    notes: 'Retirada para projeto',
    date: new Date(),
    createdAt: new Date(),
    updatedAt: new Date()
  }
];

// Get all inventory movements with pagination
export const getAllInventoryMovements = async (query: any) => {
  const page = parseInt(query.page) || 1;
  const pageSize = parseInt(query.pageSize) || 10;
  const search = query.search;
  const movementType = query.movementType;

  let filteredData = inventoryMovements;

  // Apply movement type filter if provided
  if (movementType) {
    filteredData = filteredData.filter(movement => movement.type === movementType);
  }

  // Apply search filter if provided
  if (search) {
    filteredData = filteredData.filter(movement =>
      movement.notes && movement.notes.toLowerCase().includes(search.toLowerCase())
    );
  }

  // Calculate pagination
  const total = filteredData.length;
  const totalPages = Math.ceil(total / pageSize);
  const offset = (page - 1) * pageSize;
  const paginatedData = filteredData.slice(offset, offset + pageSize);

  // Return in expected format
  return {
    data: paginatedData,
    total,
    page,
    pageSize,
    totalPages
  };
};

console.log('Inventory service loaded with sample data');
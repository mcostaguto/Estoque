// src/services/accessControlService.ts

import { db } from '@config/database';
import { 
  people, 
  appUsers, 
  auditLogs,
  loans,
  items
} from '@models/schema';
import { eq, desc, count, sql } from 'drizzle-orm';
import { 
  PaginationParams,
  SearchFilterParams,
  DoorAccessRequest,
  DoorAccessResponse,
  ToolRemovalNotification,
  ToolReturnNotification
} from '@shared/schema';

// Valida credenciais e determina se a porta deve abrir
export async function validateDoorAccess(
  accessRequest: DoorAccessRequest
): Promise<DoorAccessResponse> {
  try {
    // Busca informações do usuário
    const user = await db.query.appUsers.findFirst({
      where: eq(appUsers.userId, accessRequest.userId),
      with: {
        person: true
      }
    });

    // Verifica se usuário existe e está ativo
    if (!user || !user.isActive) {
      await logDoorAccess(accessRequest, false, 'Usuário não encontrado ou inativo');
      return {
        allowed: false,
        reason: 'Acesso negado: Usuário inválido'
      };
    }

    // Verifica se o badge corresponde ao usuário
    // (assumindo que badgeId seja único por usuário - implementar conforme sua lógica)

    // Lógica simples de autorização: usuários ativos podem acessar
    const isAuthorized = user.type === 'admin' || user.type === 'manager' || user.type === 'basic';

    if (isAuthorized) {
      await logDoorAccess(accessRequest, true, 'Acesso autorizado');
      return {
        allowed: true,
        reason: 'Acesso autorizado',
        userName: user.person?.name,
        userTeam: user.person?.team
      };
    } else {
      await logDoorAccess(accessRequest, false, 'Usuário sem permissão');
      return {
        allowed: false,
        reason: 'Acesso negado: Sem permissão'
      };
    }
  } catch (error) {
    console.error('Erro ao validar acesso à porta:', error);
    await logDoorAccess(accessRequest, false, 'Erro interno do sistema');
    return {
      allowed: false,
      reason: 'Erro interno do sistema'
    };
  }
}

// Registra log de tentativa de acesso (para auditoria)
async function logDoorAccess(
  accessRequest: DoorAccessRequest, 
  allowed: boolean, 
  reason: string
): Promise<void> {
  try {
    await db.insert(auditLogs).values({
      userId: accessRequest.userId,
      action: allowed ? 'DOOR_ACCESS_GRANTED' : 'DOOR_ACCESS_DENIED',
      entityType: 'DoorAccess',
      entityId: null,
      details: {
        badgeId: accessRequest.badgeId,
        doorId: accessRequest.doorId,
        timestamp: accessRequest.timestamp,
        reason: reason
      }
    });
  } catch (error) {
    console.error('Erro ao registrar log de acesso:', error);
  }
}

// Busca histórico de acessos às portas
export async function getDoorAccessHistory(
  params: PaginationParams & SearchFilterParams
): Promise<any> {
  try {
    const { page = 1, pageSize = 10, search } = params;
    const offset = (page - 1) * pageSize;

    // Busca logs de auditoria relacionados a acessos às portas
    const whereClause = search 
      ? sql`(${auditLogs.action} = 'DOOR_ACCESS_GRANTED' OR ${auditLogs.action} = 'DOOR_ACCESS_DENIED') AND (${auditLogs.details}->>'badgeId' ILIKE ${`%${search}%`} OR ${auditLogs.details}->>'doorId' ILIKE ${`%${search}%`})`
      : sql`${auditLogs.action} = 'DOOR_ACCESS_GRANTED' OR ${auditLogs.action} = 'DOOR_ACCESS_DENIED'`;

    const history = await db.query.auditLogs.findMany({
      where: whereClause,
      limit: pageSize,
      offset: offset,
      orderBy: desc(auditLogs.timestamp),
      with: {
        user: {
          with: {
            person: true
          }
        }
      }
    });

    const totalResult = await db.select({ count: count() })
      .from(auditLogs)
      .where(whereClause);

    const total = totalResult[0]?.count || 0;

    return {
      data: history,
      total,
      page,
      pageSize,
      totalPages: Math.ceil(total / pageSize)
    };
  } catch (error) {
    console.error('Erro ao buscar histórico de acessos:', error);
    throw error;
  }
}

// Registra remoção de ferramenta e cria empréstimo automático
export async function handleToolRemoval(
  notification: ToolRemovalNotification
): Promise<any> {
  try {
    // Busca informações do usuário e do item
    const [user, item] = await Promise.all([
      db.query.appUsers.findFirst({
        where: eq(appUsers.userId, notification.userId),
        with: { person: true }
      }),
      db.query.items.findFirst({
        where: eq(items.id, notification.itemId)
      })
    ]);

    if (!user || !user.isActive) {
      throw new Error('Usuário não encontrado ou inativo');
    }

    if (!item) {
      throw new Error('Item não encontrado');
    }

    // Verifica se já existe empréstimo ativo para este item
    const existingLoan = await db.query.loans.findFirst({
      where: sql`${loans.itemId} = ${notification.itemId} AND ${loans.returnDate} IS NULL`
    });

    if (existingLoan) {
      await logToolActivity(notification, 'TOOL_REMOVAL_ALREADY_LOANED', 'Item já está emprestado');
      return {
        success: false,
        reason: 'Item já está emprestado',
        existingLoan: existingLoan
      };
    }

    // Cria empréstimo automático
    const newLoan = await db.insert(loans).values({
      itemId: notification.itemId,
      personId: user.person!.id,
      loanDate: notification.timestamp,
      dueDate: null, // Empréstimo indefinido por padrão
      isIndefinite: true,
      notes: `Empréstimo automático - Remoção detectada via ${notification.doorId}`
    }).returning();

    // Registra auditoria
    await logToolActivity(notification, 'TOOL_REMOVAL_AUTO_LOAN', 'Empréstimo automático criado');

    return {
      success: true,
      loan: newLoan[0],
      user: {
        name: user.person?.name,
        team: user.person?.team
      },
      item: {
        name: item.name,
        type: item.type
      }
    };
  } catch (error) {
    console.error('Erro ao processar remoção de ferramenta:', error);
    await logToolActivity(notification, 'TOOL_REMOVAL_ERROR', error.message);
    throw error;
  }
}

// Registra retorno de ferramenta e finaliza empréstimo
export async function handleToolReturn(
  notification: ToolReturnNotification
): Promise<any> {
  try {
    // Busca empréstimo ativo para este item
    const activeLoan = await db.query.loans.findFirst({
      where: sql`${loans.itemId} = ${notification.itemId} AND ${loans.returnDate} IS NULL`,
      with: {
        person: true,
        item: true
      }
    });

    if (!activeLoan) {
      await logToolActivity(notification, 'TOOL_RETURN_NO_LOAN', 'Nenhum empréstimo ativo encontrado');
      return {
        success: false,
        reason: 'Nenhum empréstimo ativo encontrado para este item'
      };
    }

    // Finaliza o empréstimo
    const updatedLoan = await db.update(loans)
      .set({ returnDate: notification.timestamp })
      .where(eq(loans.id, activeLoan.id))
      .returning();

    // Registra auditoria
    await logToolActivity(notification, 'TOOL_RETURN_AUTO_CLOSE', 'Empréstimo fechado automaticamente');

    return {
      success: true,
      loan: updatedLoan[0],
      user: {
        name: activeLoan.person.name,
        team: activeLoan.person.team
      },
      item: {
        name: activeLoan.item.name,
        type: activeLoan.item.type
      }
    };
  } catch (error) {
    console.error('Erro ao processar retorno de ferramenta:', error);
    await logToolActivity(notification, 'TOOL_RETURN_ERROR', error.message);
    throw error;
  }
}

// Registra atividade de ferramenta no log de auditoria
async function logToolActivity(
  notification: ToolRemovalNotification | ToolReturnNotification,
  action: string,
  reason: string
): Promise<void> {
  try {
    await db.insert(auditLogs).values({
      userId: notification.userId,
      action: action,
      entityType: 'ToolAccess',
      entityId: notification.itemId,
      details: {
        doorId: notification.doorId,
        timestamp: notification.timestamp,
        reason: reason
      }
    });
  } catch (error) {
    console.error('Erro ao registrar log de atividade:', error);
  }
}

// Busca informações do usuário por badge (útil para sistemas de controle)
export async function getUserByBadge(badgeId: string): Promise<any> {
  try {
    // Aqui você implementaria a lógica para buscar usuário por badge
    // Por simplicidade, assumindo que badgeId está no campo username ou em uma tabela separada
    const user = await db.query.appUsers.findFirst({
      where: eq(appUsers.username, badgeId), // Ajustar conforme sua implementação
      with: {
        person: true
      }
    });

    if (!user || !user.isActive) {
      return null;
    }

    return {
      userId: user.userId,
      name: user.person?.name,
      team: user.person?.team,
      type: user.type,
      isActive: user.isActive
    };
  } catch (error) {
    console.error('Erro ao buscar usuário por badge:', error);
    return null;
  }
}
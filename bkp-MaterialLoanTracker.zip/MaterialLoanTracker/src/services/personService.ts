// src/services/personService.ts

export interface Person {
  id: number;
  name: string;
  email: string;
  phone: string;
  team: string;
  role: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

// Sample data for demonstration
const peopleData: Person[] = [
  {
    id: 1,
    name: 'João Silva',
    email: 'joao.silva@empresa.com',
    phone: '(11) 99999-1234',
    team: 'Engenharia',
    role: 'Engenheiro Senior',
    isActive: true,
    createdAt: new Date('2024-01-15'),
    updatedAt: new Date('2024-01-15')
  },
  {
    id: 2,
    name: 'Maria Santos',
    email: 'maria.santos@empresa.com',
    phone: '(11) 99999-5678',
    team: 'Manutenção',
    role: 'Técnica de Manutenção',
    isActive: true,
    createdAt: new Date('2024-01-20'),
    updatedAt: new Date('2024-01-20')
  },
  {
    id: 3,
    name: 'Pedro Costa',
    email: 'pedro.costa@empresa.com',
    phone: '(11) 99999-9012',
    team: 'Operações',
    role: 'Operador',
    isActive: true,
    createdAt: new Date('2024-02-01'),
    updatedAt: new Date('2024-02-01')
  }
];

// Get all people with pagination
export const getAllPeople = async (
  page: number = 1,
  pageSize: number = 10,
  search?: string
): Promise<{ data: Person[]; total: number; page: number; pageSize: number; totalPages: number }> => {
  let filteredData = [...peopleData];

  // Apply search filter if provided
  if (search) {
    const searchLower = search.toLowerCase();
    filteredData = filteredData.filter(person =>
      person.name.toLowerCase().includes(searchLower) ||
      person.email.toLowerCase().includes(searchLower) ||
      person.team.toLowerCase().includes(searchLower) ||
      person.role.toLowerCase().includes(searchLower)
    );
  }

  const total = filteredData.length;
  const totalPages = Math.ceil(total / pageSize);
  const offset = (page - 1) * pageSize;
  const paginatedData = filteredData.slice(offset, offset + pageSize);

  console.log(`PersonService: Returning paginated people - page: ${page}, pageSize: ${pageSize}, total: ${total}`);

  // Always return in expected paginated format
  const result = {
    data: paginatedData,
    total,
    page,
    pageSize,
    totalPages
  };

  console.log('PersonService: getAllPeople returning:', {
    type: typeof result,
    isArray: Array.isArray(result),
    hasData: 'data' in result,
    dataLength: result.data.length
  });

  return result;
};

export const getPersonById = async (id: number): Promise<Person | null> => {
  const person = peopleData.find(p => p.id === id);
  return person || null;
};

export const createPerson = async (personData: Omit<Person, 'id' | 'createdAt' | 'updatedAt'>): Promise<Person> => {
  const newPerson = {
    id: peopleData.length + 1,
    ...personData,
    createdAt: new Date(),
    updatedAt: new Date()
  };

  peopleData.push(newPerson);
  return newPerson;
};

export const updatePerson = async (id: number, personData: Partial<Omit<Person, 'id' | 'createdAt' | 'updatedAt'>>): Promise<Person | null> => {
  const index = peopleData.findIndex(p => p.id === id);
  if (index === -1) {
    return null;
  }

  peopleData[index] = {
    ...peopleData[index],
    ...personData,
    updatedAt: new Date()
  };

  return peopleData[index];
};

export const deletePerson = async (id: number): Promise<boolean> => {
  const index = peopleData.findIndex(p => p.id === id);
  if (index === -1) {
    return false;
  }

  peopleData.splice(index, 1);
  return true;
};

console.log('Person service loaded with sample data');
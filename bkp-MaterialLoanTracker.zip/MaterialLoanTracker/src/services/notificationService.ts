// src/services/notificationService.ts

import { getAllLoans } from './loanService'; // Importa a função para buscar empréstimos
import { getPersonById } from './personService'; // Import correct function name
// Note: itemService doesn't exist yet, we'll implement basic functionality here
import { Server as SocketIOServer } from 'socket.io'; // NOVO: Importa o tipo do Socket.IO Server

/**
 * Função para verificar e notificar empréstimos atrasados.
 * @param io Instância do Socket.IO Server para emitir notificações.
 */
export const checkAndNotifyOverdueLoans = async (io: SocketIOServer) => {
  console.log('Iniciando verificação de empréstimos atrasados...');
  try {
    // Get all active loans and filter for overdue ones
    const allLoansResult = await getAllLoans({ status: 'active' });
    const allLoans = Array.isArray(allLoansResult.data) ? allLoansResult.data : [];
    
    const now = new Date();
    const overdueLoans = allLoans.filter((loan: any) => 
      loan.dueDate && new Date(loan.dueDate) < now
    );

    if (overdueLoans.length === 0) {
      console.log('Nenhum empréstimo atrasado encontrado.');
      return;
    }

    console.log(`Encontrados ${overdueLoans.length} empréstimos atrasados.`);

    // Process each overdue loan
    for (const loan of overdueLoans) {
      try {
        // Get person and item details (simplified for now)
        const person = await getPersonById(loan.personId);
        const itemName = `Item ID: ${loan.itemId}`; // Simplified since itemService doesn't exist yet
        
        const overdueDays = Math.floor((now.getTime() - new Date(loan.dueDate).getTime()) / (1000 * 60 * 60 * 24));
        
        // Emit notification via Socket.IO
        io.emit('overdue-loan-notification', {
          loanId: loan.id,
          personName: person?.name || 'Pessoa desconhecida',
          itemName,
          overdueDays,
          dueDate: loan.dueDate,
          message: `Empréstimo em atraso: ${itemName} para ${person?.name || 'Pessoa desconhecida'} - ${overdueDays} dias de atraso`
        });
        
        console.log(`Notificação enviada para empréstimo atrasado: ID ${loan.id}`);
      } catch (error) {
        console.error(`Erro ao processar empréstimo atrasado ID ${loan.id}:`, error);
      }
    }
  } catch (error: any) {
    console.error('Erro ao verificar empréstimos atrasados:', error);
  }
};

// Additional notification functions can be added here
export const notifyNewLoan = (io: SocketIOServer, loanData: any) => {
  io.emit('new-loan-notification', {
    message: 'Novo empréstimo registrado',
    loanData
  });
};

export const notifyLoanReturn = (io: SocketIOServer, loanData: any) => {
  io.emit('loan-return-notification', {
    message: 'Empréstimo devolvido',
    loanData
  });
};stimos atrasados.`);

    for (const loan of overdueLoans) {
      // Buscar detalhes da pessoa e do item para a notificação
      const person = await getPerson(loan.personId); // Supondo que getPerson exista e retorne Person | undefined
      const item = await getItem(loan.itemId); // Supondo que getItem exista e retorne Item | undefined

      const personName = person ? person.name : 'Pessoa Desconhecida';
      const itemName = item ? item.name : 'Item Desconhecido';
      const dueDate = loan.dueDate ? new Date(loan.dueDate).toLocaleDateString('pt-BR') : 'N/A'; // Ensure dueDate is Date object

      const notificationMessage =
        `O empréstimo do item "${itemName}" (ID: ${loan.itemId}) ` +
        `para "${personName}" (ID: ${loan.personId}) está atrasado. ` +
        `Data de devolução prevista: ${dueDate}.`;

      console.warn(`[NOTIFICAÇÃO DE ATRASO] ${notificationMessage}`);

      // NOVO: Emitir notificação via Socket.IO para admins e managers
      // Assumindo que você tem um mecanismo para identificar usuários online e seus papéis
      // ou que o frontend irá filtrar as mensagens recebidas.
      io.emit('overdue-loan-notification', {
        loanId: loan.id,
        itemName: itemName,
        personName: personName,
        dueDate: dueDate,
        message: notificationMessage,
        type: 'warning', // Or 'error', 'info'
      });

      // TODO: No futuro, aqui você pode integrar com:
      // - Serviço de e-mail (ex: nodemailer)
      // - Serviço de SMS
      // - Atualizar um campo 'lastNotificationDate' no empréstimo para evitar notificações repetidas
      //   ou registrar em uma tabela de histórico de notificações.
    }

    console.log('Verificação de empréstimos atrasados concluída.');
  } catch (error) {
    console.error('Erro ao verificar e notificar empréstimos atrasados:', error);
  }
};

/**
 * Creates and initializes the notification system.
 * @param io Socket.IO server instance
 */
export const createNotificationSystem = (io: SocketIOServer) => {
  console.log('Notification system initialized.');
  
  // Set up periodic checking for overdue loans (every hour)
  setInterval(() => {
    checkAndNotifyOverdueLoans(io);
  }, 60 * 60 * 1000); // 1 hour
  
  return {
    checkOverdueLoans: () => checkAndNotifyOverdueLoans(io)
  };
};

console.log('Notification service defined.');
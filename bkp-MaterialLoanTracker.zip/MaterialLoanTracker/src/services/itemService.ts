// src/services/itemService.ts
import { db } from '@config/database';
import { items, Item } from '@models/schema';
import { eq } from 'drizzle-orm';

export const getItem = async (itemId: number): Promise<Item | undefined> => {
  const itemRecord = await db.select().from(items).where(eq(items.id, itemId)).limit(1);
  return itemRecord[0];
};
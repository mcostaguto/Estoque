// src/services/authService.ts

import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { LoginPayload, RegisterUserPayload, AppUser } from '@shared/schema';
import { environment } from '@config/environment';

// Temporary in-memory store for demo purposes
const testUsers = [
  {
    userId: 1,
    username: 'testuser',
    passwordHash: '$2b$10$gAVYXaaMe5/9eZsWL8/8pOEe7Xk.hNjd5cPNInnqP1AQK.ACH93HC', // test123
    type: 'admin' as const,
    personId: 1,
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastLogin: null as Date | null,
    person: {
      id: 1,
      name: 'Test User',
      team: 'Development',
      email: 'test@example.com',
      phoneNumber: '555-0123'
    }
  }
];

const revokedTokensList: string[] = [];

export const login = async (credentials: LoginPayload) => {
  const { username, password } = credentials;

  // Find user in test users
  const user = testUsers.find(u => u.username === username);

  if (!user) {
    throw new Error('Credenciais inválidas');
  }

  // Check if user is active
  if (!user.isActive) {
    throw new Error('Usuário inativo. Entre em contato com o administrador.');
  }

  // Verify password
  const isPasswordValid = await bcrypt.compare(password, user.passwordHash);
  if (!isPasswordValid) {
    throw new Error('Credenciais inválidas');
  }

  // Update last login
  user.lastLogin = new Date();

  // Generate JWT token
  const token = jwt.sign(
    {
      userId: user.userId,
      username: user.username,
      type: user.type,
      personId: user.personId
    },
    environment.jwt.secret,
    { expiresIn: environment.jwt.expiresIn }
  );

  return {
    appUser: user,
    token
  };
};

export const registerUser = async (userData: RegisterUserPayload) => {
  const { username, password, name, email, team, phoneNumber, type } = userData;

  // Check if username already exists
  const existingUser = testUsers.find(u => u.username === username);
  if (existingUser) {
    throw new Error('Nome de usuário já existe.');
  }

  // Check if email already exists
  const existingEmail = testUsers.find(u => u.person.email === email);
  if (existingEmail) {
    throw new Error('E-mail já cadastrado.');
  }

  // Hash password
  const passwordHash = await bcrypt.hash(password, environment.bcryptSaltRounds);

  // Create new user
  const newUserId = testUsers.length + 1;
  const newPersonId = testUsers.length + 1;
  
  const newUser = {
    userId: newUserId,
    username,
    passwordHash,
    type,
    personId: newPersonId,
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastLogin: null as Date | null,
    person: {
      id: newPersonId,
      name,
      team,
      email,
      phoneNumber
    }
  };

  testUsers.push(newUser);

  // Generate JWT token
  const token = jwt.sign(
    {
      userId: newUser.userId,
      username: newUser.username,
      type: newUser.type,
      personId: newUser.personId
    },
    environment.jwt.secret,
    { expiresIn: environment.jwt.expiresIn }
  );

  return {
    appUser: newUser,
    token
  };
};

export const addTokenToBlacklist = async (token: string, expiresAt: Date) => {
  revokedTokensList.push(token);
};
// src/services/loanService.ts

import { Loan, InsertLoan } from '../../shared/schema';

// Helper function to create a proper Date object and validate it
const createDate = (dateInput: string | Date | null | undefined): Date | null => {
  if (!dateInput) return null;

  try {
    const date = dateInput instanceof Date ? dateInput : new Date(dateInput);

    // Validate the date
    if (isNaN(date.getTime())) {
      console.warn('Invalid date created:', dateInput);
      return null;
    }

    return date;
  } catch (error) {
    console.error('Error creating date:', dateInput, error);
    return null;
  }
};

// Helper function to ensure dates are returned as ISO strings for API responses
const formatDateForAPI = (date: Date | string | null | undefined): string | null => {
  if (!date) return null;

  try {
    const dateObj = date instanceof Date ? date : new Date(date);
    if (isNaN(dateObj.getTime())) {
      console.warn('Invalid date for API formatting:', date);
      return null;
    }
    return dateObj.toISOString();
  } catch (error) {
    console.error('Error formatting date for API:', date, error);
    return null;
  }
};

// Helper function to safely format loan data for API response with ISO string dates
const formatLoanForResponse = (loan: any): any => {
  return {
    id: Number(loan.id) || 0,
    itemId: Number(loan.itemId) || 0,
    personId: Number(loan.personId) || 0,
    isIndefinite: Boolean(loan.isIndefinite) || false,
    notes: loan.notes || null,
    loanDate: formatDateForAPI(loan.loanDate) || new Date().toISOString(),
    dueDate: formatDateForAPI(loan.dueDate),
    returnDate: formatDateForAPI(loan.returnDate),
    createdAt: formatDateForAPI(loan.createdAt) || new Date().toISOString(),
    updatedAt: formatDateForAPI(loan.updatedAt) || new Date().toISOString()
  };
};

// Sample loan data with ISO string dates for consistent API responses
const loansData: any[] = [
  {
    id: 1,
    itemId: 1,
    personId: 1,
    loanDate: '2024-01-15T00:00:00.000Z',
    dueDate: '2024-01-22T00:00:00.000Z',
    returnDate: null,
    notes: 'Empréstimo para projeto de eletrônica',
    isIndefinite: false,
    createdAt: '2024-01-15T10:00:00.000Z',
    updatedAt: '2024-01-15T10:00:00.000Z'
  },
  {
    id: 2,
    itemId: 2,
    personId: 2,
    loanDate: '2024-01-10T00:00:00.000Z',
    dueDate: '2024-01-17T00:00:00.000Z',
    returnDate: '2024-01-16T00:00:00.000Z',
    notes: 'Devolvido antecipadamente',
    isIndefinite: false,
    createdAt: '2024-01-10T14:30:00.000Z',
    updatedAt: '2024-01-16T09:15:00.000Z'
  },
  {
    id: 3,
    itemId: 3,
    personId: 1,
    loanDate: '2024-01-20T00:00:00.000Z',
    dueDate: null,
    returnDate: null,
    notes: 'Empréstimo por tempo indeterminado',
    isIndefinite: true,
    createdAt: '2024-01-20T16:45:00.000Z',
    updatedAt: '2024-01-20T16:45:00.000Z'
  }
];

// Get all loans with pagination and filtering
export const getAllLoans = async (query: any = {}) => {
  const page = parseInt(query.page) || 1;
  const pageSize = parseInt(query.pageSize) || 10;
  const search = query.search;
  const status = query.status;

  let filteredData = loansData;

  // Apply status filter if provided
  if (status) {
    filteredData = filteredData.filter(loan => loan.status === status);
  }

  // Apply search filter if provided
  if (search) {
    filteredData = filteredData.filter(loan =>
      loan.notes && loan.notes.toLowerCase().includes(search.toLowerCase())
    );
  }

  // Calculate pagination
  const total = filteredData.length;
  const totalPages = Math.ceil(total / pageSize);
  const offset = (page - 1) * pageSize;
  const paginatedData = filteredData.slice(offset, offset + pageSize);

  // Ensure all date fields are properly formatted as ISO strings for API response
  const processedData = paginatedData.map(loan => formatLoanForResponse(loan));

  // Return in expected format
  return {
    data: processedData,
    total,
    page,
    pageSize,
    totalPages
  };
};

// Add new loan
export const addLoan = async (data: any) => {
  const now = new Date();
  const newLoan = {
    id: loansData.length + 1,
    ...data,
    loanDate: data.loanDate ? createDate(data.loanDate) : now,
    dueDate: data.dueDate ? createDate(data.dueDate) : null,
    returnDate: null,
    status: 'active',
    notes: data.notes || '',
    isIndefinite: data.isIndefinite || false,
    createdAt: now,
    updatedAt: now
  };
  loansData.push(newLoan);
  return formatLoanForResponse(newLoan);
};

// Helper function to create a complete loan object with all required fields
    const createCompleteLoan = (baseLoan: any, item?: any, person?: any): any => {
      return {
        id: baseLoan.id,
        itemId: baseLoan.itemId,
        personId: baseLoan.personId || null,
        loanDate: baseLoan.loanDate,
        dueDate: baseLoan.dueDate,
        returnDate: baseLoan.returnDate,
        notes: baseLoan.notes,
        isIndefinite: baseLoan.isIndefinite || false,
        createdAt: baseLoan.createdAt,
        updatedAt: baseLoan.updatedAt,
        // Include related data if available
        ...(item && { item }),
        ...(person && { person })
      };
    };

console.log('Loan service loaded with sample data');
// src/models/appUser.ts

import { pgTable, serial, varchar, boolean, timestamp, integer, unique } from 'drizzle-orm/pg-core';
import { people } from '@models/schema'; // Importa a definição da tabela 'people'

// Define a tabela 'app_users' no banco de dados
export const appUsers = pgTable('app_users', {
  userId: serial('user_id').primaryKey(),
  username: varchar('username', { length: 255 }).unique().notNull(),
  password: varchar('password', { length: 255 }).notNull(),
  type: varchar('type', { length: 50 }).notNull(),
  // name e email foram movidos para a entidade Person
  // team: varchar('team', { length: 255 }).notNull(), // REMOVIDO: 'team' agora em Person
  personId: integer('person_id')
    // personId não precisa ser unique aqui se uma pessoa pode ter múltiplos usuários
    .references(() => people.id, { onDelete: 'cascade' })
    .notNull(),
  isActive: boolean('is_active').default(true).notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().$onUpdateFn(() => new Date()).notNull(),
  lastLogin: timestamp('last_login', { withTimezone: true }),
});

// Exporta o tipo TypeScript correspondente ao schema da tabela 'app_users'
export type AppUser = typeof appUsers.$inferSelect;
export type InsertAppUser = typeof appUsers.$inferInsert;

console.log('AppUser model schema defined.');
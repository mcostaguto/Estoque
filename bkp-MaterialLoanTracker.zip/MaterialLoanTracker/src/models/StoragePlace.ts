import { pgTable, serial, varchar, timestamp } from 'drizzle-orm/pg-core';

// Define a tabela 'storage_places' no banco de dados
export const storagePlaces = pgTable('storage_places', {
  // id: Chave primária, serial (auto-incremento)
  id: serial('id').primaryKey(),

  // name: Nome do local de armazenamento, string, não nulo
  name: varchar('name', { length: 255 }).notNull(),

  // location: Localização específica dentro do local (ex: Prateleira 2), string, não nulo
  location: varchar('location', { length: 255 }).notNull(),

  // description: Descrição adicional sobre o local, string, pode ser nulo
  description: varchar('description', { length: 255 }),

  // created_at: Data de criação, timestamp com timezone, padrão data/hora atual, não nulo
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),

  // updated_at: Data de última atualização, timestamp com timezone, padrão data/hora atual, atualiza ao modificar, não nulo
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().defaultNow().$onUpdateFn(() => new Date()).notNull(),

  // Opcional: Adicionar restrição única composta se necessário (ex: nome e localização devem ser únicos juntos)
  // unique('name_location_unique').on(name, location),
});

// Exporta os tipos TypeScript correspondentes ao schema da tabela 'storage_places'
export type StoragePlace = typeof storagePlaces.$inferSelect; // Tipo para dados selecionados do DB
export type InsertStoragePlace = typeof storagePlaces.$inferInsert; // Tipo para dados a serem inseridos no DB

console.log('StoragePlace model schema defined.');
// src/models/AuditLog.ts

import { pgTable, serial, integer, varchar, timestamp, jsonb } from 'drizzle-orm/pg-core';
import { appUsers } from '@models/appUser'; // Referencia a tabela de usuários

// Define a tabela 'audit_logs' para auditoria de ações no sistema
export const auditLogs = pgTable('audit_logs', {
  // id: Chave primária, serial (auto-incremento)
  id: serial('id').primaryKey(),

  // userId: ID do usuário que realizou a ação (FK para appUsers)
  // Pode ser nulo se a ação foi realizada por um processo automático ou usuário não autenticado
  userId: integer('user_id').references(() => appUsers.userId, { onDelete: 'set null' }),

  // action: Descrição da ação realizada (ex: 'CREATE_USER', 'UPDATE_ITEM', 'DELETE_LOAN')
  action: varchar('action', { length: 100 }).notNull(),

  // entityType: Tipo da entidade que foi afetada pela ação (ex: 'User', 'Item', 'Loan')
  entityType: varchar('entity_type', { length: 50 }).notNull(),

  // entityId: ID da entidade que foi afetada (PK da entidade afetada)
  entityId: integer('entity_id'),

  // details: Detalhes adicionais sobre a ação, como mudanças nos campos (JSONB)
  details: jsonb('details'),

  // timestamp: Data e hora em que a ação ocorreu
  timestamp: timestamp('timestamp', { withTimezone: true }).defaultNow().notNull(),

  // ipAddress: Endereço IP do cliente que realizou a ação (opcional, pode ser capturado via middleware)
  ipAddress: varchar('ip_address', { length: 45 }), // IPv4 ou IPv6
});

// Exporta os tipos TypeScript correspondentes ao schema da tabela 'audit_logs'
export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;

console.log('AuditLog model schema defined.');
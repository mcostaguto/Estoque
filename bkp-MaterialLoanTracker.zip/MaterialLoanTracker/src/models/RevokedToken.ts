// src/models/RevokedToken.ts

import { pgTable, serial, varchar, timestamp } from 'drizzle-orm/pg-core';

// Define a tabela 'revoked_tokens' para armazenar JWTs que foram invalidados
export const revokedTokens = pgTable('revoked_tokens', {
  // id: Chave primária, serial (auto-incremento)
  id: serial('id').primaryKey(),

  // token: O token JWT (ou seu hash) que foi revogado
  // É importante indexar esta coluna para buscas rápidas.
  token: varchar('token', { length: 500 }).notNull().unique(),

  // revoked_at: Data e hora em que o token foi revogado
  revokedAt: timestamp('revoked_at', { withTimezone: true }).defaultNow().notNull(),

  // expires_at: Data e hora em que o token originalmente expiraria
  // Útil para limpar tokens expirados da blacklist (otimização de DB)
  expiresAt: timestamp('expires_at', { withTimezone: true }).notNull(),
});

// Exporta os tipos TypeScript correspondentes ao schema da tabela 'revoked_tokens'
export type RevokedToken = typeof revokedTokens.$inferSelect;
export type InsertRevokedToken = typeof revokedTokens.$inferInsert;

console.log('RevokedToken model schema defined.');
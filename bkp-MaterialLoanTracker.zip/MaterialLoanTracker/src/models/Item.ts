// src/models/item.ts

import { pgTable, varchar, integer, timestamp, serial, uniqueIndex } from 'drizzle-orm/pg-core'; // Importar uniqueIndex
import { storagePlaces } from '@models/StoragePlace';
import { ITEM_TYPES } from '@shared/schema'; // Importa os tipos de item compartilhados
import { sql } from 'drizzle-orm'; // Importar sql

// Define a tabela 'items' no banco de dados
export const items = pgTable('items', {
  id: serial('id').primaryKey(),

  name: varchar('name', { length: 255 }).notNull(),

  type: varchar('type', { length: 50, enum: ITEM_TYPES }).notNull(),

  storagePlaceId: integer('storage_place_id')
    .references(() => storagePlaces.id, { onDelete: 'set null' }),

  quantity: integer('quantity'),
  minQuantity: integer('min_quantity'),

  size: varchar('size', { length: 255 }),

  manufacturer: varchar('manufacturer', { length: 255 }),

  serialNumber: varchar('serial_number', { length: 255 }),

  // NOVO: Campos para equipamento
  model: varchar('model', { length: 255 }), // NOVO: Modelo do equipamento
  acquisitionDate: timestamp('acquisition_date', { withTimezone: true }), // NOVO: Data de aquisição
  acquisitionContext: varchar('acquisition_context', { length: 255 }), // NOVO: Contexto de aquisição

  // part_number: Agora pode ser nulo para outros tipos, mas a unicidade será garantida por índice
  partNumber: varchar('part_number', { length: 255 }),

  value: varchar('value', { length: 255 }),

  description: varchar('description', { length: 255 }),

  footprint: varchar('footprint', { length: 255 }),

  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),

  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().$onUpdateFn(() => new Date()).notNull(),
}, (table) => {
  // NOVO: Adiciona um índice único condicional para 'part_number'
  // Garante que 'partNumber' é único SOMENTE para itens do tipo 'disposable'
  return {
    partNumberDisposableUnique: uniqueIndex('idx_part_number_disposable')
      .on(table.partNumber)
      .where(sql`${table.type} = 'disposable'`), // Correção: usar sql template literal
  };
});

// Exporta os tipos TypeScript correspondentes ao schema da tabela 'items'
export type Item = typeof items.$inferSelect;
export type InsertItem = typeof items.$inferInsert;

console.log('Item model schema defined.');
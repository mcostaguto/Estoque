// src/models/schema.ts

import { pgTable, serial, varchar, timestamp, unique } from 'drizzle-orm/pg-core';
import { appUsers } from './appUser'; // Referência local
import { storagePlaces } from './StoragePlace';
import { items } from './Item';
import { inventoryMovements } from './InventoryMovement';
import { loans } from './Loan';
import { revokedTokens } from './RevokedToken'; // NOVO: Importa revokedTokens
import { auditLogs } from './AuditLog'; // NOVO: Importa auditLogs

// Define a tabela 'people' no banco de dados
export const people = pgTable('people', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  team: varchar('team', { length: 255 }).notNull(),
  email: varchar('email', { length: 255 }).unique().notNull(),
  phoneNumber: varchar('phone_number', { length: 20 }).notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().$onUpdateFn(() => new Date()).notNull(),
});

export type Person = typeof people.$inferSelect;
export type InsertPerson = typeof people.$inferInsert;


// Re-exporta a definição da tabela 'app_users' e seus tipos
export { appUsers };
export type { AppUser, InsertAppUser } from './appUser';


// Re-exporta a definição da tabela 'storage_places' e seus tipos
export { storagePlaces };
export type { StoragePlace, InsertStoragePlace } from './StoragePlace';

// Re-exporta a definição da tabela 'items' e seus tipos
export { items };
export type { Item, InsertItem } from './Item';

// Re-exporta a definição da tabela 'inventory_movements' e seus tipos
export { inventoryMovements };
export type { InventoryMovement, DbInsertInventoryMovement } from './InventoryMovement'; // ALTERADO: Renomeado InsertInventoryMovement

// Re-exporta a definição da tabela 'loans' e seus tipos
export { loans };
export type { Loan, InsertLoan } from './Loan';

// NOVO: Re-exporta a definição da tabela 'revoked_tokens' e seus tipos
export { revokedTokens };
export type { RevokedToken, InsertRevokedToken } from './RevokedToken';

// NOVO: Re-exporta a definição da tabela 'audit_logs' e seus tipos
export { auditLogs };
export type { AuditLog, InsertAuditLog } from './AuditLog';


console.log('Database schema models defined (people, appUsers, storagePlaces, items, inventoryMovements, loans, revokedTokens, auditLogs).');
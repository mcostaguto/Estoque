// src/models/Loan.ts

import { pgTable, serial, integer, timestamp, varchar, boolean } from 'drizzle-orm/pg-core'; // Importa 'boolean'
import { items } from '@models/Item';
import { people } from '@models/schema';

// Define a tabela 'loans' no banco de dados
export const loans = pgTable('loans', {
  id: serial('id').primaryKey(),
  itemId: integer('item_id')
    .references(() => items.id, { onDelete: 'restrict' })
    .notNull(),
  personId: integer('person_id')
    .references(() => people.id, { onDelete: 'restrict' })
    .notNull(),
  loanDate: timestamp('loan_date', { withTimezone: true }).defaultNow().notNull(),
  dueDate: timestamp('due_date', { withTimezone: true }),
  returnDate: timestamp('return_date', { withTimezone: true }),
  isIndefinite: boolean('is_indefinite').default(false).notNull(), 
  notes: varchar('notes', { length: 255 }),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().$onUpdateFn(() => new Date()).notNull(),
});

// Exporta os tipos TypeScript correspondentes ao schema da tabela 'loans'
export type Loan = typeof loans.$inferSelect;
export type InsertLoan = typeof loans.$inferInsert;

console.log('Loan model schema defined.');
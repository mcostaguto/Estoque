// src/models/InventoryMovement.ts

import { pgTable, serial, integer, timestamp, varchar } from 'drizzle-orm/pg-core';
import { items } from '@models/Item'; // Importa a definição da tabela 'items'
import { people } from '@models/schema'; // Importa a definição da tabela 'people'
import { INVENTORY_MOVEMENT_TYPES } from '../../shared/schema'; // Importa os tipos de movimentação compartilhados

// Define a tabela 'inventory_movements' no banco de dados
export const inventoryMovements = pgTable('inventory_movements', {
  // id: Chave primária, serial (auto-incremento)
  id: serial('id').primaryKey(),

  // item_id: ID do item movimentado, inteiro, não nulo
  // Cria uma chave estrangeira referenciando a coluna 'id' da tabela 'items'
  // ON DELETE CASCADE significa que se um item for deletado, todas as suas movimentações também serão.
  // Escolha a política de exclusão que melhor se adapta à sua regra de negócio. CASCADE é comum para logs.
  itemId: integer('item_id')
    .references(() => items.id, { onDelete: 'cascade' }) // Referencia a tabela 'items'
    .notNull(),

  // quantity: Quantidade movimentada, inteiro, não nulo
  // Positivo para adição/entrada, negativo para retirada/saída (ou apenas o valor absoluto dependendo da lógica do serviço)
  quantity: integer('quantity').notNull(),

  // date: Data e hora da movimentação, timestamp com timezone, padrão data/hora atual, não nulo
  date: timestamp('date', { withTimezone: true }).defaultNow().notNull(),

  // person_id: ID da pessoa que realizou/recebeu a movimentação, inteiro, pode ser nulo
  // Cria uma chave estrangeira referenciando a coluna 'id' da tabela 'people'
  // Pode ser nulo para movimentações automáticas (ex: ajuste de inventário por sistema)
  personId: integer('person_id')
    .references(() => people.id, { onDelete: 'set null' }), // Referencia a tabela 'people'

  // notes: Observações sobre a movimentação, string, pode ser nulo
  notes: varchar('notes', { length: 255 }),

  // type: Tipo da movimentação (addition, withdrawal, adjustment), string, não nulo
  type: varchar('type', { length: 50, enum: INVENTORY_MOVEMENT_TYPES }).notNull(), // Usamos enum para validação no DB

  // created_at: Data de criação do registro (pode ser redundante com 'date', mas útil para auditoria), timestamp com timezone, padrão data/hora atual, não nulo
  // createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(), // Opcional

  // updated_at: Data de última atualização do registro, timestamp com timezone, padrão data/hora atual, atualiza ao modificar, não nulo
  // updatedAt: timestamp('updated_at', { withTimezone: true }).defaultNow().onUpdateNow().notNull(), // Opcional
});

// Exporta os tipos TypeScript correspondentes ao schema da tabela 'inventory_movements'
export type InventoryMovement = typeof inventoryMovements.$inferSelect; // Tipo para dados selecionados do DB
export type DbInsertInventoryMovement = typeof inventoryMovements.$inferInsert; // RENOMEADO: Tipo para dados a serem inseridos no DB (para evitar conflito com payload)

console.log('InventoryMovement model schema defined.');
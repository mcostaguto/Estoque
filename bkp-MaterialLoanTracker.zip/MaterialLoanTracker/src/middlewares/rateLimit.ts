// src/middlewares/rateLimit.ts

import { Request, Response, NextFunction } from 'express';

// In-memory store for rate limiting (for demonstration purposes)
// For production, consider a persistent store like Redis.
const requestCounts = new Map<string, { count: number; lastReset: number }>();
const WINDOW_SIZE_MS = 60 * 1000; // 1 minute
const MAX_REQUESTS = 100; // Max 100 requests per minute per IP (more generous for development)

/**
 * Middleware para aplicar rate limiting.
 * Limita o número de requisições por IP em um determinado período.
 */
const rateLimit = (req: Request, res: Response, next: NextFunction) => {
  const ip = req.ip || req.socket.remoteAddress; // Get client IP address

  if (!ip) {
    return res.status(500).json({ message: "Unable to determine client IP address for rate limiting." });
  }

  const now = Date.now();
  const clientData = requestCounts.get(ip) || { count: 0, lastReset: now };

  // Reset count if window has passed
  if (now - clientData.lastReset > WINDOW_SIZE_MS) {
    clientData.count = 0;
    clientData.lastReset = now;
  }

  // Check if limit exceeded
  if (clientData.count >= MAX_REQUESTS) {
    return res.status(429).json({ message: "Too many requests. Please try again later." });
  }

  // Increment count and proceed
  clientData.count++;
  requestCounts.set(ip, clientData);

  next();
};

export default rateLimit;

console.log('Rate Limit middleware defined.');
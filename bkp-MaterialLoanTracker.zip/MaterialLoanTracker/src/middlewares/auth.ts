// src/middlewares/auth.ts

import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { environment } from '@config/environment';

// In-memory storage for revoked tokens
const revokedTokensSet = new Set<string>();

export const revokeToken = (token: string) => {
  revokedTokensSet.add(token);
};

// Middleware de autenticação
export const authenticateToken = (req: Request, res: Response, next: NextFunction): void => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (token == null) {
    console.warn('Acesso negado: Token não fornecido.');
    res.sendStatus(401);
    return;
  }

  // Verifica se o token está na blacklist (em memória)
  if (revokedTokensSet.has(token)) {
    console.warn('Acesso negado: Token revogado.');
    res.sendStatus(401);
    return;
  }

  jwt.verify(token, environment.jwt.secret, (err, userPayload) => {
    if (err) {
      console.warn('Acesso negado: Token inválido ou expirado.', err.message);
      res.sendStatus(403);
      return;
    }

    req.user = userPayload as any; // Token payload
    req.token = token; // Armazena o token completo no req para uso posterior (ex: logout)
    next();
  });
};

console.log('Auth middleware defined.');
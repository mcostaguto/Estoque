// src/middlewares/authorization.ts

import { Request, Response, NextFunction } from 'express';
import { UserType } from '@shared/schema'; // Importa os tipos de usuário definidos no shared schema

// O 'declare module 'express'' foi movido para 'src/types/express.d.ts'
// para centralizar a tipagem e evitar conflitos.

/**
 * Middleware de autorização baseado em papéis.
 * Verifica se o usuário autenticado possui pelo menos um dos papéis necessários.
 * @param allowedRoles Array de papéis permitidos (ex: ['admin', 'manager'])
 */
export const authorize = (allowedRoles: UserType[]) => {
  return (req: Request, res: Response, next: NextFunction) => {
    // 1. Verificar se o usuário está autenticado
    if (!req.user) {
      // Se não houver req.user, o middleware authenticateToken não foi executado ou falhou.
      // Isso teoricamente não deveria acontecer se 'authenticateToken' for encadeado antes.
      return res.status(401).json({ message: 'Não autenticado. Token não fornecido ou inválido.' });
    }

    // 2. Verificar se o tipo de usuário do usuário autenticado está entre os papéis permitidos
    // CORRIGIDO: Cast explícito de req.user.type para UserType
    if (!allowedRoles.includes(req.user.type as UserType)) {
      // Se o papel do usuário não estiver na lista de papéis permitidos, nega o acesso
      console.warn(`Acesso negado para usuário ${req.user.username} (Tipo: ${req.user.type}). Papéis permitidos: ${allowedRoles.join(', ')}`);
      return res.status(403).json({ message: 'Acesso negado. Você não tem permissão para realizar esta ação.' });
    }

    // 3. Se o usuário tiver um papel permitido, continua para o próximo middleware/rota
    next();
  };
};

console.log('Authorization middleware defined.');
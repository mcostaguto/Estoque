
// src/sockets/index.ts

import { Server as SocketServer } from 'socket.io';
import { Server as HttpServer } from 'http';

export function initSocket(server: HttpServer): SocketServer {
  const io = new SocketServer(server, {
    cors: {
      origin: [
        "http://localhost:3000", 
        "http://localhost:5173", 
        "https://*.replit.dev",
        "https://*.replit.app",
        process.env.REPLIT_DOMAIN ? `https://${process.env.REPLIT_DOMAIN}` : null
      ].filter(Boolean),
      methods: ["GET", "POST"],
      credentials: true
    },
    transports: ['polling', 'websocket'],
    allowEIO3: true,
    pingTimeout: 60000,
    pingInterval: 25000,
    upgradeTimeout: 30000,
    path: '/socket.io/',
    serveClient: false
  });

  io.on('connection', (socket) => {
    console.log('Cliente conectado:', socket.id);

    socket.on('disconnect', (reason) => {
      console.log('Cliente desconectado:', socket.id, 'Motivo:', reason);
    });

    socket.on('error', (error) => {
      console.error('Socket error:', error);
    });

    socket.on('connect_error', (error) => {
      console.error('Socket connection error:', error);
    });
  });

  io.engine.on('connection_error', (err) => {
    console.log('Socket.IO connection error details:');
    console.log('Request:', err.req ? err.req.url : 'N/A');
    console.log('Message:', err.message);
    console.log('Description:', err.description);
    console.log('Context:', err.context);
  });

  return io;
}

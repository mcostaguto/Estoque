// src/server.ts

import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { errorHandler } from '@middlewares/errorHandler';
import { environment } from '@config/environment';
import rateLimitMiddleware from '@middlewares/rateLimit';

// Rotas
import authRoutes from '@routes/authRoutes';
import createInventoryRoutes from '@routes/inventoryRoutes'; // Função factory
import createInventoryMovementRoutes from './routes/inventoryMovementRoutes';
import createAccessControlRoutes from '@routes/accessControlRoutes';
import loanRoutes from '@routes/loanRoutes';
import storagePlaceRoutes from '@routes/storagePlaceRoutes';
import userRoutes from '@routes/userRoutes';
import createPeopleRoutes from '@routes/peopleRoutes';
import { createNotificationSystem } from '@services/notificationService';
import * as accessControlService from '@services/accessControlService';

const app = express();

// Configuração do CORS
const allowedOrigins = [
  'http://localhost:3000',
  'http://localhost:5173',
  environment.frontendUrl
];

// Add current Replit domain if available
if (process.env.REPLIT_DOMAINS) {
  const replitDomains = process.env.REPLIT_DOMAINS.split(',').map(domain => `https://${domain.trim()}`);
  allowedOrigins.push(...replitDomains);
}

const corsOptions = {
  origin: function (origin: string | undefined, callback: (err: Error | null, allow?: boolean) => void) {
    // Allow requests with no origin (like mobile apps, curl requests, etc.)
    if (!origin) {
      callback(null, true);
      return;
    }

    // Allow any origin in development
    if (environment.nodeEnv === 'development') {
      callback(null, true);
      return;
    }

    if (allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('Bloqueado pelo CORS'));
    }
  },
  credentials: true,
  optionsSuccessStatus: 200
};

// Middlewares globais
app.use(cors(corsOptions));
app.use(helmet());
app.use(morgan('combined'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
// Disable rate limiting in development for better performance
if (environment.nodeEnv === 'production') {
  app.use(rateLimitMiddleware);
}

// Socket.IO completely removed to eliminate connection errors
console.log('Socket.IO removed - using standard HTTP only');
const io = null;
(app as any).io = io;

// Health check
app.get('/health', (req: Request, res: Response) => {
  res.status(200).json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    environment: environment.nodeEnv 
  });
});

// Rotas da API
app.use('/api/auth', authRoutes);
app.use('/api/inventory', createInventoryRoutes(io)); // Passa io para rotas que precisam
app.use('/api/inventory-movements', createInventoryMovementRoutes());
app.use('/api/access-control', createAccessControlRoutes()); // Rotas simplificadas de controle de acesso
app.use('/api/loans', loanRoutes);
app.use('/api/storage-places', storagePlaceRoutes);
app.use('/api/users', userRoutes);
app.use('/api/people', createPeopleRoutes());

// Middleware de tratamento de erros (deve ser o último)
app.use(errorHandler);

// Middleware para limpar tokens expirados (executado a cada 24 horas)
setInterval(async () => {
  try {
    // Implementar limpeza de tokens expirados se necessário
    console.log('Executando limpeza de tokens expirados...');
  } catch (error) {
    console.error('Erro ao limpar tokens expirados:', error);
  }
}, 24 * 60 * 60 * 1000); // 24 horas em milissegundos

const PORT = environment.port;
const HOST = '0.0.0.0';

// Serve static files from the frontend build
import path from 'path';
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.static(path.join(__dirname, '../dist/public')));

// Handle React routing, return all requests to React app
app.get('*', (req, res, next) => {
  // Skip API routes and socket.io
  if (req.path.startsWith('/api') || req.path.startsWith('/socket.io')) {
    return next();
  }
  res.sendFile(path.join(__dirname, '../dist/public/index.html'));
});

// Inicia o servidor HTTP
app.listen(PORT, HOST, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
  console.log(`CORS configurado para permitir origens: ${allowedOrigins.join(', ')}`);
  console.log(`Ambiente: ${environment.nodeEnv}`);
});
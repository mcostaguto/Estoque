// src/routes/loanRoutes.ts

import { Router, RequestHandler } from 'express'; // <--- Importe RequestHandler
import {
  createLoanController,
  returnLoanController,
  getAllLoansController,
  getActiveLoansController,
  getOverdueLoansController,
  getLoanByIdController,
} from '@controllers/loanController';
import { authenticateToken } from '@middlewares/auth';

// Cria uma nova instância do Router
const router = Router();

// Aplica o middleware de autenticação a todas as rotas de empréstimo
// Isso garante que apenas usuários autenticados possam acessar essas rotas
router.use(authenticateToken as RequestHandler); // <--- Adicionado 'as RequestHandler'

// Define a rota POST para registrar um novo empréstimo
// Ex: POST /api/loans
router.post('/', createLoanController as RequestHandler); // <--- Adicionado 'as RequestHandler'

// Define a rota PUT para registrar a devolução de um empréstimo
// Ex: PUT /api/loans/:id/return
router.put('/:id/return', returnLoanController as RequestHandler); // <--- Adicionado 'as RequestHandler'

// Define a rota GET para buscar todos os empréstimos
// Ex: GET /api/loans
router.get('/', getAllLoansController as RequestHandler); // <--- Adicionado 'as RequestHandler'

// Define a rota GET para buscar empréstimos ativos
// Ex: GET /api/loans/active
router.get('/active', getActiveLoansController as RequestHandler); // <--- Adicionado 'as RequestHandler'

// Define a rota GET para buscar empréstimos vencidos
// Ex: GET /api/loans/overdue
router.get('/overdue', getOverdueLoansController as RequestHandler); // <--- Adicionado 'as RequestHandler'

// Define a rota GET para buscar um empréstimo por ID
// Ex: GET /api/loans/:id
router.get('/:id', getLoanByIdController as RequestHandler); // <--- Adicionado 'as RequestHandler'


// Exporta o router para ser usado no arquivo principal do servidor
export default router;

console.log('Loan routes defined.');
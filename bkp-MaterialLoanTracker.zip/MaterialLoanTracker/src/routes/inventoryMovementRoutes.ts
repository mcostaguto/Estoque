// src/routes/inventoryMovementRoutes.ts

import { Router, RequestHandler } from 'express';
import { getAllInventoryMovements } from '../services/inventoryService';
import { authenticateToken } from '../middlewares/auth';

export default function createInventoryMovementRoutes() {
  const router = Router();

  // Apply authentication to all routes
  router.use(authenticateToken as RequestHandler);

  // Get all inventory movements
  router.get('/', async (req, res) => {
    try {
      const movements = await getAllInventoryMovements(req.query);
      res.json(movements);
    } catch (error: any) {
      console.error('Erro ao buscar movimentações de estoque:', error);
      res.status(500).json({ message: 'Erro ao buscar movimentações de estoque', error: error.message });
    }
  });

  return router;
}

// src/routes/userRoutes.ts

import { Router, RequestHandler } from 'express';
import { getAllPeople } from '../services/personService';
import { authenticateToken } from '../middlewares/auth';

export default function createUserRoutes() {
  const router = Router();

  // Apply authentication to all routes
  router.use(authenticateToken as RequestHandler);

  // Get all users (using people data for now)
  router.get('/', async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const pageSize = parseInt(req.query.pageSize as string) || 10;
      const search = req.query.search as string;
      
      console.log(`UserRoutes: GET / - page: ${page}, pageSize: ${pageSize}, search: ${search}`);
      
      const users = await getAllPeople(page, pageSize, search);
      
      console.log(`UserRoutes: Returning response:`, {
        type: typeof users,
        isArray: Array.isArray(users),
        hasData: users && typeof users === 'object' && 'data' in users
      });
      
      res.json(users);
    } catch (error: any) {
      console.error('Erro ao buscar usuários:', error);
      res.status(500).json({ message: 'Erro ao buscar usuários', error: error.message });
    }
  });

  return router;
}

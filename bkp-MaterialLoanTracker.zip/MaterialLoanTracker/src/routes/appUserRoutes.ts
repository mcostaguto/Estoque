// src/routes/appUserRoutes.ts

import { Router, RequestHandler } from "express"; // NOVO: Importa RequestHandler
import {
  createappUserController,
  getAllappUsersController,
  getappUserByIdController,
  updateappUserController,
  deleteappUserController,
} from "@controllers/appUserController";
import { authenticateToken } from "@middlewares/auth";
import { authorize } from "@middlewares/authorization";

const router = Router();

// Aplica o middleware de autenticação a todas as rotas de usuário
router.use(authenticateToken as RequestHandler); // CORRIGIDO: Cast para RequestHandler

// Rotas protegidas por autenticação e autorização
// NOVO RBAC:
// create: Apenas admin pode criar usuários (manager pode criar 'basic' validado no controller,
// mas a rota é restrita a admin para ter controle total sobre quem pode iniciar o processo de criação).
router.post("/", authorize(["admin"]), createappUserController as RequestHandler); // CORRIGIDO: Cast
// getAll: Apenas admin pode listar todos os usuários (manager não pode gerenciar usuários, apenas relatórios)
router.get("/", authorize(["admin"]), getAllappUsersController as RequestHandler); // CORRIGIDO: Cast

// Rotas que podem ser acessadas por admin (qualquer usuário), manager (qualquer usuário) e basic (apenas o próprio usuário, validado no controller)
router.get("/:id", authorize(["admin", "manager", "basic"]), getappUserByIdController as RequestHandler); // CORRIGIDO: Cast
router.put("/:id", authorize(["admin", "manager", "basic"]), updateappUserController as RequestHandler); // CORRIGIDO: Cast
// delete: Apenas admin (é uma desativação lógica, validado no controller)
router.delete("/:id", authorize(["admin"]), deleteappUserController as RequestHandler); // CORRIGIDO: Cast


export default router;

console.log('AppUser routes defined.');
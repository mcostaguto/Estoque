
// src/routes/accessControlRoutes.ts

import { Router, RequestHandler } from 'express';
import { createAccessControlController } from '@controllers/accessControlController';
import { authenticateToken } from '@middlewares/auth';

// Função factory simplificada para controle de portas
export default function accessControlRoutes() {
  const router = Router();
  const accessControlController = createAccessControlController();

  // Endpoint principal: validar acesso à porta
  router.post('/door-access', accessControlController.validateDoorAccess as RequestHandler);

  // Endpoints para notificações de ferramentas
  router.post('/tool-removal', accessControlController.handleToolRemoval as RequestHandler);
  router.post('/tool-return', accessControlController.handleToolReturn as RequestHandler);

  // Endpoint para buscar usuário por badge (útil para sistemas externos)
  router.get('/user-by-badge/:badgeId', accessControlController.getUserByBadge as RequestHandler);

  // Endpoints protegidos para administração (requer autenticação)
  router.use(authenticateToken as RequestHandler);

  // Endpoint para buscar histórico de acessos (apenas para admins)
  router.get('/door-access-history', accessControlController.getDoorAccessHistory as RequestHandler);

  return router;
}

// src/routes/inventoryRoutes.ts

import { Router, RequestHandler } from 'express';
import { createInventoryController } from '@controllers/inventoryController';
import { authenticateToken } from '@middlewares/auth';
import { getAllItems } from '../services/inventoryService.js';

// NOVO: `inventoryRoutes` agora é uma função que recebe `io`
export default function inventoryRoutes(io: any) {
  const router = Router();
  // NOVO: Cria uma instância do controlador com `io`
  const inventoryController = createInventoryController(io);

  // Aplica o middleware de autenticação a todas as rotas de inventário
  router.use(authenticateToken as RequestHandler);

  router.post('/items', inventoryController.addItem as RequestHandler);
  router.put('/items/:id', inventoryController.updateItem as RequestHandler);
  router.delete('/items/:id', inventoryController.deleteItem as RequestHandler);
  // Get all items
  router.get('/items', async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const pageSize = parseInt(req.query.pageSize as string) || 10;
      const search = req.query.search as string;
      const itemType = req.query.itemType as string;

      console.log(`InventoryRoutes: GET /items - page: ${page}, pageSize: ${pageSize}, search: ${search}, itemType: ${itemType}`);

      const items = await getAllItems(page, pageSize, search, itemType);

      console.log(`InventoryRoutes: Returning response:`, {
        type: typeof items,
        isArray: Array.isArray(items),
        hasData: items && typeof items === 'object' && 'data' in items
      });

      res.json(items);
    } catch (error: any) {
      console.error('Erro ao buscar itens:', error);
      res.status(500).json({ message: 'Erro ao buscar itens', error: error.message });
    }
  });
  router.get('/items/:id', inventoryController.getItemById as RequestHandler);

  // Rota para buscar detalhes de um item por Part Number (para auto-preenchimento)
  router.get('/items/details', inventoryController.getItemDetailsByPartNumberController as RequestHandler);

  // Rotas para movimentações de inventário (anteriormente em itemRoutes)
  // CORRIGIDO: Nome do método
  router.post("/inventory-movements", inventoryController.addInventoryMovementController as RequestHandler);
  router.get("/inventory-movements", inventoryController.getAllInventoryMovements as RequestHandler);

  return router;
}
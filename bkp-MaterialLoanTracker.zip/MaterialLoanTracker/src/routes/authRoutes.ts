// src/routes/authRoutes.ts

import { Router, RequestHandler } from 'express';
import { loginController, registerController, getMeController, logoutController } from '@controllers/authController'; // NOVO: Importe logoutController
import { authenticateToken } from '@middlewares/auth'; // Importe authenticateToken

// Cria uma nova instância do Router
const router = Router();

// Define a rota POST para login
router.post('/login', loginController as RequestHandler);

// Define a rota POST para registro
router.post('/register', registerController as RequestHandler);

// NOVO: Define a rota POST para logout
router.post('/logout', authenticateToken as RequestHandler, logoutController as RequestHandler); // Protegida para garantir que um token válido esteja presente

// NOVO: Define a rota GET para buscar os dados do usuário logado
// Esta rota requer autenticação para acessar req.user
router.get('/me', authenticateToken as RequestHandler, getMeController as RequestHandler);

// Exporta o router para ser usado no arquivo principal do servidor
export default router;

console.log('Auth routes defined.');
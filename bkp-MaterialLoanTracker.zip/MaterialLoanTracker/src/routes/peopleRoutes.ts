
// src/routes/peopleRoutes.ts

import { Router, Request, Response } from 'express';
import { getAllPeople, getPersonById, createPerson, updatePerson, deletePerson } from '@services/personService';
import { authenticateToken } from '@middlewares/auth';

export default function createPeopleRoutes() {
  const router = Router();

  // Apply authentication middleware to all routes
  router.use(authenticateToken);

  // Get all people with pagination
  router.get('/', async (req: Request, res: Response) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const pageSize = parseInt(req.query.pageSize as string) || 10;
      const search = req.query.search as string;

      console.log(`PeopleRoutes: GET /people - page: ${page}, pageSize: ${pageSize}, search: ${search}`);

      const result = await getAllPeople(page, pageSize, search);

      // Validate response format
      if (!result || typeof result !== 'object' || Array.isArray(result) || !('data' in result)) {
        console.error('PeopleRoutes: Invalid response format from getAllPeople:', result);
        return res.status(500).json({ 
          message: 'Erro interno: formato de resposta inválido',
          error: 'Invalid response format'
        });
      }

      console.log(`PeopleRoutes: Returning paginated response:`, {
        type: typeof result,
        isArray: Array.isArray(result),
        hasData: result && typeof result === 'object' && 'data' in result,
        dataCount: result.data ? result.data.length : 0
      });

      res.json(result);
    } catch (error: any) {
      console.error('Erro ao buscar pessoas:', error);
      res.status(500).json({ 
        message: 'Erro ao buscar pessoas', 
        error: error.message,
        data: [],
        total: 0,
        page: 1,
        pageSize: 10,
        totalPages: 0
      });
    }
  });

  // Get person by ID
  router.get('/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const person = await getPersonById(id);
      
      if (!person) {
        return res.status(404).json({ message: 'Pessoa não encontrada' });
      }
      
      res.json(person);
    } catch (error: any) {
      console.error('Erro ao buscar pessoa:', error);
      res.status(500).json({ message: 'Erro ao buscar pessoa', error: error.message });
    }
  });

  // Create new person
  router.post('/', async (req: Request, res: Response) => {
    try {
      const newPerson = await createPerson(req.body);
      res.status(201).json(newPerson);
    } catch (error: any) {
      console.error('Erro ao criar pessoa:', error);
      res.status(500).json({ message: 'Erro ao criar pessoa', error: error.message });
    }
  });

  // Update person
  router.put('/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updatedPerson = await updatePerson(id, req.body);
      
      if (!updatedPerson) {
        return res.status(404).json({ message: 'Pessoa não encontrada' });
      }
      
      res.json(updatedPerson);
    } catch (error: any) {
      console.error('Erro ao atualizar pessoa:', error);
      res.status(500).json({ message: 'Erro ao atualizar pessoa', error: error.message });
    }
  });

  // Delete person
  router.delete('/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await deletePerson(id);
      
      if (!deleted) {
        return res.status(404).json({ message: 'Pessoa não encontrada' });
      }
      
      res.status(204).send();
    } catch (error: any) {
      console.error('Erro ao deletar pessoa:', error);
      res.status(500).json({ message: 'Erro ao deletar pessoa', error: error.message });
    }
  });

  return router;
}

console.log('People routes defined.');

// src/routes/storagePlaceRoutes.ts

import { Router, RequestHandler } from 'express';
import { addStoragePlaceController, getAllStoragePlacesController } from '@controllers/storagePlaceController';
import { authenticateToken } from '@middlewares/auth'; // Para rotas protegidas

const router = Router();

// Aplica o middleware de autenticação para todas as rotas de locais
router.use(authenticateToken as RequestHandler);

// Rota para adicionar um novo local de armazenamento (que inclui a subárea)
router.post('/', addStoragePlaceController as RequestHandler);

// Rota para buscar todos os locais de armazenamento
router.get('/', getAllStoragePlacesController as RequestHandler);

export default router;

console.log('StoragePlace routes defined.');
// src/controllers/loanController.ts

import { Request, Response, NextFunction } from 'express';
import { ZodError } from 'zod'; // Importa ZodError para tratar erros de validação
import {
  insertLoanSchema,
  paginationParamsSchema,
  searchFilterParamsSchema,
  loanStatusFilterParamsSchema // CORRIGIDO: Nome do schema de filtro de status
} from '@shared/schema'; // Importa schemas de validação e os novos schemas de filtro/paginação
import * as loanService from '@services/loanService'; // Importa todas as funções do serviço de empréstimos

// Helper function to ensure dates are properly formatted
const formatDateForJSON = (date: Date | string | null | undefined): string | null => {
  if (!date) return null;

  try {
    const dateObj = date instanceof Date ? date : new Date(date);
    if (isNaN(dateObj.getTime())) {
      console.warn('Invalid date for JSON formatting:', date);
      return null;
    }
    return dateObj.toISOString();
  } catch (error) {
    console.error('Error formatting date for JSON:', date, error);
    return null;
  }
};

// Helper function to format loan for API response
const formatLoanForAPI = (loan: any) => {
  return {
    id: Number(loan.id) || 0,
    itemId: Number(loan.itemId) || 0,
    personId: Number(loan.personId) || 0,
    isIndefinite: Boolean(loan.isIndefinite) || false,
    notes: loan.notes || null,
    loanDate: formatDateForJSON(loan.loanDate),
    dueDate: formatDateForJSON(loan.dueDate),
    returnDate: formatDateForJSON(loan.returnDate),
    createdAt: formatDateForJSON(loan.createdAt),
    updatedAt: formatDateForJSON(loan.updatedAt)
  };
};

// Controlador para registrar um novo empréstimo
export const createLoanController = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    // 1. Validar o corpo da requisição usando o schema Zod
    const loanDataParsed = insertLoanSchema.parse(req.body);

    const loanDataForService = {
      ...loanDataParsed,
      loanDate: loanDataParsed.loanDate ? new Date(loanDataParsed.loanDate) : new Date(),
      dueDate: loanDataParsed.dueDate ? new Date(loanDataParsed.dueDate) : null,
      performingUserId: req.user?.userId // Inclui performingUserId para auditoria
    };

    // 2. Chamar o serviço para criar o empréstimo
    const newLoan = await loanService.createLoan(loanDataForService, req.io); // Passa req.io para o serviço

    // 3. Enviar a resposta de sucesso (status 201 Created) com a data formatada
    const formattedLoan = formatLoanForAPI(newLoan);
    res.status(201).json({
      message: 'Empréstimo registrado com sucesso!',
      loan: formattedLoan,
    });

  } catch (error: any) {
    // 4. Tratar erros
    if (error instanceof ZodError) {
      console.error('Erro de validação ao criar empréstimo:', error.errors);
      res.status(400).json({
        message: 'Dados de entrada inválidos para o empréstimo.',
        errors: error.errors,
      });
    } else if (error.message.includes('Item não encontrado') ||
               error.message.includes('Pessoa não encontrada') ||
               error.message.includes('Insumos não podem ser emprestados') ||
               error.message.includes('Este item já está emprestado')) {
      console.warn(`Falha ao criar empréstimo: ${error.message}`);
      res.status(400).json({
        message: error.message,
      });
    } else {
      console.error('Erro interno ao criar empréstimo:', error);
      res.status(500).json({
        message: 'Ocorreu um erro interno ao tentar registrar o empréstimo.',
      });
    }
  }
};

// Controlador para registrar a devolução de um empréstimo
export const returnLoanController = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const loanId = parseInt(req.params.id);

    // Validação básica do ID
    if (isNaN(loanId)) {
      res.status(400).json({ message: 'ID do empréstimo inválido.' });
      return;
    }

    // Inclui performingUserId para auditoria
    const updatedLoan = await loanService.returnLoan(loanId, req.io, req.user?.userId); // Passa req.io e performingUserId

    // Enviar a resposta de sucesso com a data formatada
    const formattedLoan = formatLoanForAPI(updatedLoan);
    res.status(200).json({
      message: 'Empréstimo devolvido com sucesso!',
      loan: formattedLoan,
    });

  } catch (error: any) {
    if (error.message.includes('Empréstimo não encontrado') ||
        error.message.includes('Este empréstimo já foi devolvido')) {
      console.warn(`Falha ao devolver empréstimo: ${error.message}`);
      res.status(400).json({
        message: error.message,
      });
    } else {
      console.error('Erro interno ao devolver empréstimo:', error);
      res.status(500).json({
        message: 'Ocorreu um erro interno ao tentar devolver o empréstimo.',
      });
    }
  }
};

// Controlador para buscar todos os empréstimos com paginação e filtros
export const getAllLoansController = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    // Combina e valida os parâmetros de query usando Zod
    const queryParams = paginationParamsSchema.merge(searchFilterParamsSchema).merge(loanStatusFilterParamsSchema).parse(req.query);

    const loans = await loanService.getAllLoans(queryParams);
    
    // Format all loans to ensure proper date handling
    if (loans && typeof loans === 'object' && 'data' in loans && Array.isArray(loans.data)) {
      const formattedLoans = loans.data.map(formatLoanForAPI);
      res.json({
        ...loans,
        data: formattedLoans
      });
    } else {
      res.json(loans);
    }
  } catch (error: any) {
    if (error instanceof ZodError) {
      res.status(400).json({
        message: 'Parâmetros de query inválidos para buscar empréstimos.',
        errors: error.errors,
      });
    } else {
      console.error('Erro ao buscar todos os empréstimos:', error);
      res.status(500).json({
        message: 'Ocorreu um erro interno ao tentar buscar os empréstimos.',
      });
    }
  }
};

// Controlador para buscar empréstimos ativos
export const getActiveLoansController = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    // Este controlador pode ser mantido para compatibilidade, mas a função getAllLoans com filtro 'active' é mais flexível.
    // Ou, pode ser removido se a UI for adaptada para usar getAllLoans com query params.
    const activeLoans = await loanService.getActiveLoans();
    // Format dates for active loans
    if (Array.isArray(activeLoans)) {
      const formattedActiveLoans = activeLoans.map(formatLoanForAPI);
      res.status(200).json(formattedActiveLoans);
    } else {
      res.status(200).json(activeLoans);
    }
  } catch (error: any) {
    console.error('Erro ao buscar empréstimos ativos:', error);
    res.status(500).json({
      message: 'Ocorreu um erro interno ao tentar buscar os empréstimos ativos.',
    });
  }
};

// Controlador para buscar empréstimos vencidos
export const getOverdueLoansController = async (_req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    // Similar ao getActiveLoansController, pode ser mantido ou substituído.
    const overdueLoans = await loanService.getOverdueLoans();
    // Format dates for overdue loans
    if (Array.isArray(overdueLoans)) {
      const formattedOverdueLoans = overdueLoans.map(formatLoanForAPI);
      res.status(200).json(formattedOverdueLoans);
    } else {
      res.status(200).json(overdueLoans);
    }
  } catch (error: any) {
    console.error('Erro ao buscar empréstimos vencidos:', error);
    res.status(500).json({
      message: 'Ocorreu um erro interno ao tentar buscar os empréstimos vencidos.',
    });
  }
};

// Controlador para buscar um empréstimo por ID
export const getLoanByIdController = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const loanId = parseInt(req.params.id);
    if (isNaN(loanId)) {
      res.status(400).json({ message: 'ID do empréstimo inválido.' });
      return;
    }
    const loan = await loanService.getLoanById(loanId);
    if (loan) {
      const formattedLoan = formatLoanForAPI(loan);
      res.status(200).json(formattedLoan);
    } else {
      res.status(404).json({ message: 'Empréstimo não encontrado.' });
    }
  } catch (error: any) {
    console.error('Erro ao buscar empréstimo por ID:', error);
    res.status(500).json({
      message: 'Ocorreu um erro interno ao tentar buscar o empréstimo.',
    });
  }
};

console.log('Loan controller defined.');
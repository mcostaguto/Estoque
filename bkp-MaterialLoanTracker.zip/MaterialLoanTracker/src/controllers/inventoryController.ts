// src/controllers/inventoryController.ts

import { Request, Response, NextFunction } from 'express';
import * as inventoryService from '../services/inventoryService.js';
import * as storagePlaceService from '../services/storagePlaceService.js';
import {
  PaginationParams,
  SearchFilterParams,
  InventoryMovementFilterParams,
  ItemTypeFilterParams,
  insertInventoryMovementSchema
} from '@shared/schema';
import { ZodError } from 'zod';

export function createInventoryController(io: any) {
  return {
    addItem: async (req: Request, res: Response, next: NextFunction): Promise<void> => {
      try {
        const newItem = await inventoryService.addItem(req.body);
        res.status(201).json(newItem);
      } catch (error: any) {
        console.error('Erro ao adicionar item:', error);
        res.status(500).json({ message: error.message || 'Erro ao adicionar item' });
      }
    },

    updateItem: async (req: Request, res: Response, next: NextFunction): Promise<void> => {
      try {
        const updatedItem = await inventoryService.updateItem(Number(req.params.id), req.body);
        if (!updatedItem) {
          res.status(404).json({ message: 'Item não encontrado para atualização.' });
          return;
        }
        res.status(200).json(updatedItem);
      } catch (error) {
        console.error('Erro ao atualizar item:', error);
        res.status(500).json({ message: 'Erro ao atualizar item', error });
      }
    },

    deleteItem: async (req: Request, res: Response, next: NextFunction): Promise<void> => {
      try {
        await inventoryService.deleteItem(Number(req.params.id));
        res.status(204).send();
      } catch (error) {
        console.error('Erro ao deletar item:', error);
        res.status(500).json({ message: 'Erro ao deletar item', error });
      }
    },

    getAllItems: async (req: Request, res: Response, next: NextFunction): Promise<void> => {
      try {
        const params: PaginationParams & SearchFilterParams & ItemTypeFilterParams = {
          page: req.query.page ? parseInt(req.query.page as string) : 1,
          pageSize: req.query.pageSize ? parseInt(req.query.pageSize as string) : 10,
          search: req.query.search as string | undefined,
          itemType: req.query.itemType as ItemTypeFilterParams['itemType'] | undefined,
          value: req.query.value as string | undefined,
          footprint: req.query.footprint as string | undefined,
        };

        const items = await inventoryService.getAllItems(params);
        res.status(200).json(items);
      } catch (error) {
        console.error('Erro ao buscar itens:', error);
        res.status(500).json({ message: 'Erro ao buscar itens', error });
      }
    },

    getItemById: async (req: Request, res: Response, next: NextFunction): Promise<void> => {
      try {
        const item = await inventoryService.getItemById(Number(req.params.id));
        if (item) {
          res.status(200).json(item);
        } else {
          res.status(404).json({ message: 'Item não encontrado' });
        }
      } catch (error) {
        console.error('Erro ao buscar item por ID:', error);
        res.status(500).json({ message: 'Erro ao buscar item', error });
      }
    },

    getItemDetailsByPartNumberController: async (req: Request, res: Response, next: NextFunction): Promise<void> => {
      try {
        const partNumber = req.query.partNumber as string;
        if (!partNumber) {
          res.status(400).json({ message: 'Part Number é obrigatório.' });
          return;
        }
        const itemDetails = await inventoryService.getItemDetailsByPartNumber(partNumber);
        if (itemDetails) {
          res.status(200).json(itemDetails);
        } else {
          res.status(404).json({ message: 'Detalhes do item não encontrados para este Part Number.' });
        }
      } catch (error) {
        console.error('Erro ao buscar detalhes do item por Part Number:', error);
        res.status(500).json({ message: 'Erro interno ao buscar detalhes do item.', error });
      }
    },

    addInventoryMovementController: async (req: Request, res: Response, next: NextFunction): Promise<void> => {
      try {
        // Valida o payload completo, que agora inclui `personId` (sujeito) e `performingUserId` (executor)
        const movementData = insertInventoryMovementSchema.parse(req.body);

        // Passa o `personId` do payload (sujeito da movimentação) e o `userId` do token (executor da ação) para o serviço
        const newMovement = await inventoryService.addInventoryMovement({ 
            ...movementData, 
            personId: movementData.personId, // O personId é o sujeito da movimentação, vindo do frontend
            performingUserId: req.user?.userId || null // O userId é do usuário autenticado (quem registra a ação), vindo do token
        }, req.io); // req.io é a instância do Socket.IO para notificações em tempo real

        res.status(201).json(newMovement);
      } catch (error: any) {
        if (error instanceof ZodError) {
          res.status(400).json({
            message: "Dados de movimentação de inventário inválidos.",
            errors: error.errors,
          });
        } else {
          console.error("Erro ao adicionar movimentação de inventário:", error);
          res.status(500).json({ message: error.message || 'Erro ao adicionar movimentação de inventário' });
        }
      }
    },

    getAllInventoryMovements: async (req: Request, res: Response, next: NextFunction): Promise<void> => {
      try {
        const params: PaginationParams & SearchFilterParams & InventoryMovementFilterParams = {
          page: req.query.page ? parseInt(req.query.page as string) : 1,
          pageSize: req.query.pageSize ? parseInt(req.query.pageSize as string) : 10,
          search: req.query.search as string | undefined,
          movementType: req.query.movementType as InventoryMovementFilterParams['movementType'] | undefined,
        };

        const movements = await inventoryService.getAllInventoryMovements(params);
        res.status(200).json(movements);
      } catch (error: any) {
        console.error('Erro ao buscar movimentações de inventário:', error);
        res.status(500).json({ message: 'Ocorreu um erro interno ao tentar buscar as movimentações de inventário.', error });
      }
    }
  };
}

console.log('Inventory controller defined (as factory).');
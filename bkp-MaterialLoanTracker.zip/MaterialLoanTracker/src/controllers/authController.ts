// src/controllers/authController.ts

import { Request, Response, NextFunction } from 'express';
// CORREÇÃO: Importa AppUser diretamente, pois é o tipo correto exportado
import { loginSchema, registerUserSchema, AppUser } from '@shared/schema';
import { login, registerUser, addTokenToBlacklist } from '@services/authService'; // NOVO: Importa addTokenToBlacklist
import { ZodError } from 'zod';
import jwt from 'jsonwebtoken'; // NOVO: Para decodificar o token no logout

// O 'declare module 'express'' foi movido para 'src/types/express.d.ts'
// para centralizar a tipagem e evitar conflitos.

// Controlador para a rota de login
export const loginController = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const credentials = loginSchema.parse(req.body);
    const { appUser, token } = await login(credentials);

    res.status(200).json({
      message: 'Login bem-sucedido!',
      user: appUser,
      token: token,
    });

  } catch (error: any) {
    if (error instanceof ZodError) {
      console.error('Erro de validação no login:', error.errors);
      res.status(400).json({
        message: 'Dados de entrada inválidos.',
        errors: error.errors,
      });
    } else if (error.message === 'Credenciais inválidas' || error.message === 'Usuário inativo. Entre em contato com o administrador.') {
      console.warn(`Tentativa de login falhou: ${error.message}`);
      res.status(401).json({
        message: error.message,
      });
    } else {
      console.error('Erro interno no login:', error);
      res.status(500).json({
        message: 'Ocorreu um erro interno ao tentar fazer login.',
      });
    }
  }
};

// Controlador para a rota de registro de usuário
export const registerController = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        const userData = registerUserSchema.parse(req.body);
        const { appUser, token } = await registerUser(userData);

        res.status(201).json({
            message: 'Usuário registrado com sucesso!',
            user: appUser,
            token: token,
        });

    } catch (error: any) {
         if (error instanceof ZodError) {
            console.error('Erro de validação no registro:', error.errors);
            res.status(400).json({
              message: 'Dados de entrada inválidos.',
              errors: error.errors,
            });
        } else if (error.message === 'Nome de usuário já existe.' || error.message === 'E-mail já cadastrado.') {
             console.warn(`Tentativa de registro falhou: ${error.message}`);
             res.status(409).json({
                 message: error.message,
             });
        }
         else {
            console.error('Erro interno no registro:', error);
            res.status(500).json({
              message: 'Ocorreu um erro interno ao tentar registrar usuário.',
            });
        }
    }
};

// Controlador para obter os dados do usuário autenticado (GET /api/auth/me)
export const getMeController = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        if (!req.user) {
            res.status(401).json({ message: 'Não autenticado. Token inválido ou ausente.' });
            return;
        }
        res.status(200).json(req.user);
    } catch (error: any) {
        console.error('Erro ao buscar dados do usuário logado:', error);
        res.status(500).json({ message: 'Ocorreu um erro interno ao buscar dados do usuário.' });
    }
};

/**
 * Controlador para fazer logout (invalida o token JWT).
 */
export const logoutController = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const token = req.token; // Token completo, armazenado pelo middleware authenticateToken
    if (!token) {
      res.status(400).json({ message: 'Token não fornecido para logout.' });
      return;
    }

    // Decodifica o token para obter a data de expiração (exp)
    const decodedToken: any = jwt.decode(token);
    if (!decodedToken || !decodedToken.exp) {
      res.status(400).json({ message: 'Token inválido ou sem data de expiração.' });
      return;
    }

    // `exp` é em segundos, Date espera milissegundos
    const expiresAt = new Date(decodedToken.exp * 1000);

    await addTokenToBlacklist(token, expiresAt);
    res.status(200).json({ message: 'Logout realizado com sucesso.' });
  } catch (error: any) {
    console.error('Erro ao fazer logout:', error);
    res.status(500).json({ message: error.message || 'Ocorreu um erro interno ao fazer logout.' });
  }
};

console.log('Auth controller defined.');
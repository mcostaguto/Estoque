// src/controllers/accessControlController.ts

import { Request, Response, NextFunction } from 'express';
import { 
  PaginationParams, 
  SearchFilterParams,
  DoorAccessRequest,
  ToolRemovalNotification,
  ToolReturnNotification
} from '@shared/schema';
import * as accessControlService from '@services/accessControlService';

export function createAccessControlController() {
  return {
    // Valida acesso à porta baseado em credenciais
    validateDoorAccess: async (req: Request, res: Response, next: NextFunction): Promise<void> => {
      try {
        const accessRequest: DoorAccessRequest = req.body;
        const validation = await accessControlService.validateDoorAccess(accessRequest);

        // Status code baseado no resultado
        const statusCode = validation.allowed ? 200 : 403;
        res.status(statusCode).json(validation);
      } catch (error: any) {
        console.error('Erro ao validar acesso à porta:', error);
        res.status(500).json({ 
          allowed: false,
          reason: 'Erro interno do sistema',
          error: error.message 
        });
      }
    },

    // Busca informações do usuário por badge
    getUserByBadge: async (req: Request, res: Response, next: NextFunction): Promise<void> => {
      try {
        const { badgeId } = req.params;
        const user = await accessControlService.getUserByBadge(badgeId);

        if (!user) {
          res.status(404).json({ 
            message: 'Usuário não encontrado ou inativo' 
          });
          return;
        }

        res.status(200).json(user);
      } catch (error: any) {
        console.error('Erro ao buscar usuário por badge:', error);
        res.status(500).json({ 
          message: 'Erro ao buscar usuário', 
          error: error.message 
        });
      }
    },

    // Busca histórico de acessos às portas
    getDoorAccessHistory: async (req: Request, res: Response, next: NextFunction): Promise<void> => {
      try {
        const params: PaginationParams & SearchFilterParams = {
          page: req.query.page ? parseInt(req.query.page as string) : 1,
          pageSize: req.query.pageSize ? parseInt(req.query.pageSize as string) : 10,
          search: req.query.search as string | undefined,
        };

        const history = await accessControlService.getDoorAccessHistory(params);
        res.status(200).json(history);
      } catch (error: any) {
        console.error('Erro ao buscar histórico de acessos:', error);
        res.status(500).json({ 
          message: 'Erro ao buscar histórico de acessos', 
          error: error.message 
        });
      }
    },

    // Processa remoção de ferramenta detectada
    handleToolRemoval: async (req: Request, res: Response, next: NextFunction): Promise<void> => {
      try {
        const notification: ToolRemovalNotification = req.body;
        const result = await accessControlService.handleToolRemoval(notification);

        res.status(200).json(result);
      } catch (error: any) {
        console.error('Erro ao processar remoção de ferramenta:', error);
        res.status(500).json({ 
          success: false,
          message: 'Erro ao processar remoção de ferramenta', 
          error: error.message 
        });
      }
    },

    // Processa retorno de ferramenta detectado
    handleToolReturn: async (req: Request, res: Response, next: NextFunction): Promise<void> => {
      try {
        const notification: ToolReturnNotification = req.body;
        const result = await accessControlService.handleToolReturn(notification);

        res.status(200).json(result);
      } catch (error: any) {
        console.error('Erro ao processar retorno de ferramenta:', error);
        res.status(500).json({ 
          success: false,
          message: 'Erro ao processar retorno de ferramenta', 
          error: error.message 
        });
      }
    }
  };
}
// src/controllers/appUserController.ts

import { Request, Response, NextFunction } from "express";
import { ZodError } from "zod";
import * as appUserService from "@services/appUserService";
import {
  registerUserSchema,
  paginationParamsSchema,
  searchFilterParamsSchema,
  userTypeSchema, // MANTIDO: para validação do enum
  appUserSchema, // MANTIDO: para tipagem
  personSchema // MANTIDO: para tipagem
} from "@shared/schema";
import { UpdateAppUserPayload } from "@services/appUserService";
import { z } from "zod"; // NOVO: Importado 'z' para Zod schemas

// Controlador para criar um novo usuário (APENAS ADMIN pode criar qualquer tipo, MANAGER pode criar 'basic')
export const createappUserController = async (
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> => {
  try {
    const userData = registerUserSchema.parse(req.body);
    // RBAC: Um manager só pode criar usuários do tipo 'basic'
    if (req.user?.type === 'manager' && userData.type !== 'basic') {
        res.status(403).json({ message: "Gerentes só podem criar usuários do tipo 'basic'." });
        return;
    }
    // Inclui performingUserId para auditoria
    const newAppUser = await appUserService.createAppUser({ ...userData, performingUserId: req.user?.userId });
    res.status(201).json({
      message: "Usuário criado com sucesso!",
      user: newAppUser,
    });
  } catch (error: any) {
    if (error instanceof ZodError) {
      res
        .status(400)
        .json({
          message: "Dados de criação de usuário inválidos.",
          errors: error.errors,
        });
    } else if (
      error.message === "Nome de usuário já existe." ||
      error.message === "E-mail já cadastrado."
    ) {
      res.status(409).json({ message: error.message });
    } else {
      console.error("Erro ao criar usuário:", error);
      res
        .status(500)
        .json({
          message: "Ocorreu um erro interno ao tentar criar o usuário.",
        });
    }
  }
};

// Controlador para buscar todos os usuários com paginação e filtro (ADMIN)
export const getAllappUsersController = async (
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> => {
  try {
    const queryParams = paginationParamsSchema
      .merge(searchFilterParamsSchema)
      .parse(req.query);

    const users = await appUserService.getAllAppUsers(queryParams);
    res.status(200).json(users);
  } catch (error: any) {
    if (error instanceof ZodError) {
      res
        .status(400)
        .json({
          message: "Parâmetros de query inválidos para buscar usuários.",
          errors: error.errors,
        });
    } else {
      console.error("Erro ao buscar todos os usuários:", error);
      res
        .status(500)
        .json({
          message: "Ocorreu um erro interno ao tentar buscar os usuários.",
        });
    }
  }
};

// Controlador para buscar um usuário por ID (ADMIN, MANAGER (qualquer um), BASIC (apenas o próprio))
export const getappUserByIdController = async (
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> => {
  try {
    const userId = parseInt(req.params.id);
    if (isNaN(userId)) {
      res.status(400).json({ message: "ID de usuário inválido." });
      return;
    }

    // RBAC: Lógica para permitir que o usuário acesse APENAS seus próprios dados (a menos que seja admin ou manager)
    if (req.user && req.user.type !== "admin" && req.user.type !== "manager" && req.user.userId !== userId) {
      res
        .status(403)
        .json({
          message:
            "Acesso negado. Você não tem permissão para visualizar este usuário.",
        });
      return;
    }

    const userFound = await appUserService.getAppUserById(userId);
    if (userFound) {
      res.status(200).json(userFound);
    } else {
      res.status(404).json({ message: "Usuário não encontrado." });
    }
  } catch (error) {
    console.error("Erro ao buscar usuário por ID:", error);
    res
      .status(500)
      .json({
        message: "Ocorreu um erro interno ao tentar buscar o usuário.",
      });
  }
};

// Controlador para atualizar um usuário (por admins ou o próprio usuário)
export const updateappUserController = async (
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> => {
  try {
    const userId = parseInt(req.params.id);
    if (isNaN(userId)) {
      res.status(400).json({ message: "ID de usuário inválido." });
      return;
    }

    const { currentPassword, ...updateFields } = req.body;

    // NOVO: Schema específico para validação do payload de atualização
    const updatePayloadSchema = z.object({
        name: z.string().optional(),
        email: z.string().email().optional(),
        phoneNumber: z.string().optional(),
        team: z.string().optional(), // `team` agora faz parte do payload de Person
        password: z.string().min(6).optional(),
        type: userTypeSchema.optional(), // appUser type
        isActive: z.boolean().optional(), // appUser isActive
        performingUserId: z.number().optional(), // ID do usuário que realiza a ação
    }).strip(); // Remove propriedades não especificadas

    const updateData: UpdateAppUserPayload = updatePayloadSchema.parse(updateFields);

    // RBAC: Lógica para permitir que o usuário atualize APENAS seus próprios dados (exceto type/isActive)
    // Admins podem atualizar todos os campos.
    if (req.user && req.user.userId !== userId && req.user.type !== "admin") {
      const restrictedFields = ['type', 'isActive'];
      const isAttemptingRestrictedUpdate = Object.keys(updateData).some(field =>
        restrictedFields.includes(field)
      );

      if (isAttemptingRestrictedUpdate) {
        res
          .status(403)
          .json({
            message: "Acesso negado. Você não tem permissão para alterar este tipo de informação.",
          });
        return;
      }
    }

    const updatedUser = await appUserService.updateAppUser(
      userId,
      updateData,
      currentPassword,
    );

    if (updatedUser) {
      res
        .status(200)
        .json({
          message: "Usuário atualizado com sucesso!",
          user: updatedUser,
        });
    } else {
      res
        .status(404)
        .json({ message: "Usuário não encontrado para atualização." });
    }
  } catch (error: any) {
    if (error instanceof ZodError) {
      res
        .status(400)
        .json({
          message: "Dados de atualização inválidos.",
          errors: error.errors,
        });
    } else if (
      error.message === "E-mail já cadastrado para outro usuário." ||
      error.message === "Senha atual incorreta." ||
      error.message === "É necessário fornecer a senha atual para alterá-la."
    ) {
      res.status(409).json({ message: error.message });
    } else {
      console.error("Erro ao atualizar usuário:", error);
      res
        .status(500)
        .json({
          message: "Ocorreu um erro interno ao tentar atualizar o usuário.",
        });
    }
  }
};

// Controlador para deletar um usuário (considerar apenas exclusão lógica por `isActive`) (APENAS ADMIN)
export const deleteappUserController = async (
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> => {
  try {
    const userId = parseInt(req.params.id);
    if (isNaN(userId)) {
      res.status(400).json({ message: "ID de usuário inválido." });
      return;
    }

    // A deleção aqui é uma desativação lógica
    // Inclui performingUserId para auditoria
    const deletedUser = await appUserService.updateAppUser(userId, { isActive: false, performingUserId: req.user?.userId });

    if (deletedUser) {
      res
        .status(200)
        .json({ message: "Usuário desativado (excluído logicamente) com sucesso!" });
    } else {
      res
        .status(404)
        .json({ message: "Usuário não encontrado para desativação." });
    }
  } catch (error) {
    console.error("Erro ao desativar usuário:", error);
    res
      .status(500)
      .json({
        message: "Ocorreu um erro interno ao tentar desativar o usuário.",
      });
  }
};

console.log('AppUser controller defined.');
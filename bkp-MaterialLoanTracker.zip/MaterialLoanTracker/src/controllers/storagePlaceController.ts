// src/controllers/storagePlaceController.ts

import { Request, Response, NextFunction } from 'express';
import { ZodError } from 'zod';
import * as storagePlaceService from '@services/storagePlaceService';
import { insertStoragePlacePayloadSchema } from '@shared/schema'; // Importa o payload do schema compartilhado

// Controlador para adicionar um novo Local de Armazenamento/Subárea
export const addStoragePlaceController = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const data = insertStoragePlacePayloadSchema.parse(req.body); // Valida o payload
    const newPlace = await storagePlaceService.addStoragePlace(data);
    res.status(201).json(newPlace);
  } catch (error: any) {
    if (error instanceof ZodError) {
      console.error('Erro de validação ao adicionar local de armazenamento:', error.errors);
      res.status(400).json({ message: 'Dados de entrada inválidos para o local de armazenamento.', errors: error.errors });
    } else {
      console.error('Erro ao adicionar local de armazenamento:', error);
      res.status(500).json({ message: 'Ocorreu um erro interno ao tentar adicionar o local de armazenamento.' });
    }
  }
};

// Controlador para buscar todos os locais de armazenamento (para ser usado pelo frontend)
export const getAllStoragePlacesController = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const storagePlaces = await storagePlaceService.getAllStoragePlaces();
    res.status(200).json(storagePlaces);
  } catch (error: any) {
    console.error('Erro ao buscar locais de armazenamento:', error);
    res.status(500).json({ message: 'Ocorreu um erro interno ao tentar buscar os locais de armazenamento.' });
  }
};


console.log('StoragePlace controller defined.');
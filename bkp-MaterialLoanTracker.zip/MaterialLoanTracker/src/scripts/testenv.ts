import { dirname } from 'path';
import { fileURLToPath } from 'url';
import * as dotenv from 'dotenv';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

dotenv.config({ path: __dirname + '/../../.env' });

console.log('TEST ENV:', process.env.DATABASE_URL, process.env.JWT_SECRET);

// src/scripts/seed.ts

import { dirname } from 'path';
import { fileURLToPath } from 'url';
import * as dotenv from 'dotenv';

// Resolve __dirname em ES Modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Carrega .env ANTES de qualquer outro import!
dotenv.config({ path: __dirname + '/../../.env' });

// No Replit, DATABASE_URL é automaticamente definida quando você cria um banco PostgreSQL
// Verifica se DATABASE_URL está disponível
console.log('🔍 Verificando variáveis de ambiente...');
console.log('DATABASE_URL disponível:', !!process.env.DATABASE_URL);

if (!process.env.DATABASE_URL) {
  console.error('❌ ERRO: DATABASE_URL não está definida nas variáveis de ambiente.');
  console.error('');
  console.error('📋 OPÇÕES PARA CONFIGURAR O BANCO:');
  console.error('');
  console.error('🔹 OPÇÃO 1 - Banco do Replit (RECOMENDADO):');
  console.error('1. Clique na aba "Database" na barra lateral esquerda');
  console.error('2. Clique em "Create a database"');
  console.error('3. Selecione PostgreSQL');
  console.error('4. A variável DATABASE_URL será automaticamente definida');
  console.error('');
  console.error('🔹 OPÇÃO 2 - Banco Externo via Secrets:');
  console.error('1. Clique na aba "Secrets" na barra lateral esquerda');
  console.error('2. Adicione uma nova secret:');
  console.error('   Nome: DATABASE_URL');
  console.error('   Valor: postgresql://username:password@host:port/database');
  console.error('');
  console.error('🔹 OPÇÃO 3 - Banco Externo via .env:');
  console.error('1. Descomente DATABASE_URL no arquivo .env');
  console.error('2. Configure: DATABASE_URL="postgresql://username:password@host:port/database"');
  console.error('');
  process.exit(1);
}

// Log da URL do banco (mascarado por segurança)
const maskedUrl = process.env.DATABASE_URL.replace(/:\/\/[^@]+@/, '://***:***@');
console.log('🔗 Conectando ao banco:', maskedUrl);

import { db } from '@config/database';
import { eq } from 'drizzle-orm';
import bcrypt from 'bcrypt';
import { appUsers, people, InsertAppUser, InsertPerson } from '@models/schema';
import { environment } from '@config/environment';

async function createInitialAdminUser() {
  console.log('🌱 Iniciando script de criação do usuário administrador inicial...');
  console.log('🔗 Conectando ao banco de dados...');

  // Credenciais do usuário administrador
  const adminUsername = 'admin';
  const adminPassword = 'admin123';
  const adminEmail = 'admin@almoxarifado.com';
  const adminPhoneNumber = '99999999999';
  const adminName = 'Administrador do Sistema';
  const adminTeam = 'TI';
  const adminType = 'admin';

  try {
    // Test database connection first
    console.log('🔄 Testando conexão com o banco de dados...');
    
    // Try a simple query to test connection
    try {
      await db.select().from(people).limit(1);
      console.log('✅ Conexão com o banco de dados estabelecida com sucesso!');
    } catch (testError: any) {
      console.error('❌ Erro na conexão inicial com o banco:', testError.message);
      
      if (testError.message.includes('relation "people" does not exist')) {
        console.error('');
        console.error('💡 SOLUÇÃO: As tabelas ainda não foram criadas no banco.');
        console.error('Execute primeiro as migrações do Drizzle:');
        console.error('   npx drizzle-kit push');
        console.error('');
      }
      
      throw testError;
    }

    await db.transaction(async (tx) => {
      // Verifica se já existe um usuário admin
      const existingAppUser = await tx.select().from(appUsers).where(eq(appUsers.username, adminUsername)).limit(1);
      if (existingAppUser.length > 0) {
        console.log(`✅ Usuário '${adminUsername}' já existe. Pulando criação.`);
        console.log(`📋 Credenciais existentes:`);
        console.log(`   Username: ${adminUsername}`);
        console.log(`   Senha: ${adminPassword}`);
        console.log(`   Email: ${adminEmail}`);
        return;
      }

      // Verifica se já existe uma pessoa com este email
      const existingPerson = await tx.select().from(people).where(eq(people.email, adminEmail)).limit(1);
      if (existingPerson.length > 0) {
        console.log(`⚠️  Pessoa com e-mail '${adminEmail}' já existe. Pulando criação.`);
        return;
      }

      console.log('🔐 Criando hash da senha...');
      const hashedPassword = await bcrypt.hash(adminPassword, environment.bcryptSaltRounds);

      console.log('👤 Criando registro de pessoa...');
      const newPersonData: InsertPerson = {
        name: adminName,
        team: adminTeam,
        email: adminEmail,
        phoneNumber: adminPhoneNumber,
      };
      const newPersonRecord = await tx.insert(people).values(newPersonData).returning();
      const newPerson = newPersonRecord[0];

      if (!newPerson) {
        throw new Error('Falha ao criar registro de pessoa.');
      }

      console.log('🔑 Criando registro de usuário administrador...');
      const newAppUserData: InsertAppUser = {
        username: adminUsername,
        password: hashedPassword,
        type: adminType,
        personId: newPerson.id,
        isActive: true,
      };
      const newAppUserRecord = await tx.insert(appUsers).values(newAppUserData).returning();
      const newAppUser = newAppUserRecord[0];

      if (!newAppUser) {
        throw new Error('Falha ao criar registro de usuário administrador.');
      }

      console.log('');
      console.log('🎉 ===== USUÁRIO ADMINISTRADOR CRIADO COM SUCESSO! =====');
      console.log('');
      console.log('📋 CREDENCIAIS DE ACESSO:');
      console.log(`   👤 Username: ${adminUsername}`);
      console.log(`   🔐 Senha: ${adminPassword}`);
      console.log(`   📧 Email: ${adminEmail}`);
      console.log('');
      console.log('🔍 DETALHES TÉCNICOS:');
      console.log(`   🆔 ID do Usuário: ${newAppUser.userId}`);
      console.log(`   👥 ID da Pessoa: ${newPerson.id}`);
      console.log(`   🏷️  Tipo: ${adminType}`);
      console.log(`   ✅ Status: Ativo`);
      console.log('');
      console.log('💡 Use essas credenciais para fazer login no sistema!');
      console.log('');
    });
  } catch (error) {
    console.error('❌ Erro ao criar o usuário administrador inicial:', error);
    
    if (error instanceof Error) {
      if (error.message.includes('ECONNREFUSED') || error.message.includes('ETIMEDOUT')) {
        console.error('');
        console.error('💡 DICA: Problema de conexão com o banco de dados.');
        console.error('');
        console.error('🔧 PARA BANCO DO REPLIT:');
        console.error('1. Clique na aba "Database" na barra lateral');
        console.error('2. Clique em "Create a database"');
        console.error('3. Selecione PostgreSQL');
        console.error('4. Aguarde a criação e tente novamente');
        console.error('');
        console.error('🔧 PARA BANCO EXTERNO:');
        console.error('1. Verifique se as credenciais estão corretas');
        console.error('2. Verifique se o banco está acessível');
        console.error('3. Verifique as configurações de firewall');
      } else if (error.message.includes('does not exist')) {
        console.error('');
        console.error('💡 DICA: As tabelas do banco ainda não foram criadas.');
        console.error('Execute as migrações do Drizzle primeiro:');
        console.error('   npx drizzle-kit push');
        console.error('');
      }
    }
    
    process.exit(1);
  }
  
  console.log('🚀 Script de seed concluído com sucesso!');
  process.exit(0);
}

createInitialAdminUser();


#!/usr/bin/env tsx

import { dirname } from 'path';
import { fileURLToPath } from 'url';
import * as dotenv from 'dotenv';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Carrega as variáveis de ambiente
dotenv.config({ path: __dirname + '/../../.env' });

async function runSeed() {
  console.log('🌱 Iniciando processo de seed...');
  console.log('');
  
  // Verifica pré-requisitos
  if (!process.env.DATABASE_URL) {
    console.error('❌ DATABASE_URL não encontrada!');
    console.error('');
    console.error('🔧 PASSOS PARA RESOLVER:');
    console.error('1. Vá para a aba "Database" na barra lateral');
    console.error('2. Clique em "Create a database"');
    console.error('3. Selecione PostgreSQL');
    console.error('4. Execute este script novamente após a criação');
    process.exit(1);
  }

  try {
    // Importa e executa o seed
    const { default: seedFunction } = await import('./seed.js');
    if (typeof seedFunction === 'function') {
      await seedFunction();
    } else {
      // Se não exportar uma função, apenas importa o módulo
      await import('./seed.js');
    }
  } catch (error: any) {
    console.error('❌ Erro durante o seed:', error.message);
    
    if (error.message.includes('does not exist')) {
      console.error('');
      console.error('💡 Execute as migrações primeiro:');
      console.error('   npx drizzle-kit push');
    }
    
    process.exit(1);
  }
}

runSeed();

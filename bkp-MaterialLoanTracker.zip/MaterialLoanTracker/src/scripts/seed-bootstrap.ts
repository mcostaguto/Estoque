import { dirname } from 'path';
import { fileURLToPath } from 'url';
import * as dotenv from 'dotenv';

// Resolve __dirname em ES Modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Carrega .env ANTES de qualquer outro import!
dotenv.config({ path: __dirname + '/../../.env' });

// Agora, importe e execute o seed.ts
import('./seed');